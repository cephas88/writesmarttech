// Global variables for refresh functionality
let refreshCount = 0;
let refreshTimeout = null;
let maxRefreshes = 100; // Default value, will be updated from settings
let navigatingBack = false; // Flag to prevent duplicate navigation
let isFirstLoad = true; // Flag to handle initial page load differently
const REFRESH_INTERVAL = 0; // Changed from 1000ms to 0ms for immediate refresh

// Add a timer to force refresh if we get stuck
window.addEventListener('load', function() {
    // Record the current page load time
    sessionStorage.setItem('lastRefreshTime', Date.now().toString());
    
    // If we're in a monitoring session, set a backup timer
    if (sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
        console.log('TakeButtonDetector: Page fully loaded - setting backup timer for 3 seconds');
        
        // Get current refresh count from session storage
        const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
        console.log(`Current countdown during backup timer setup: ${currentCount} seconds remaining`);
        
        // If no refresh happens within 3 seconds, force one (reduced from 4s)
        setTimeout(() => {
            const lastRefreshTime = parseInt(sessionStorage.getItem('lastRefreshTime') || '0');
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - lastRefreshTime;
            
            // Get the current refresh count again to make sure it's up to date
            const updatedCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
            
            // Only force refresh if the count hasn't changed and is positive
            if (updatedCount === currentCount &&
                updatedCount > 0 &&
                timeSinceLastRefresh > 3000 && 
                sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
                console.log(`FORCED REFRESH: No refresh in ${timeSinceLastRefresh}ms, forcing reload`);
                
                // Decrement the counter before forced refresh
                const newCount = updatedCount - 1;
                sessionStorage.setItem('takeButtonRefreshCount', newCount.toString());
                console.log(`Continuing countdown: ${newCount} seconds remaining before forced refresh`);
                
                // If we're at zero now, navigate back instead of refreshing
                if (newCount <= 0) {
                    console.log(`Countdown reached zero. Navigating back to All Available instead of refreshing.`);
                    clearRefreshCycle();
                    window.navigateToAllAvailable();
                    return;
                }
                
                // Update last refresh time
                sessionStorage.setItem('lastRefreshTime', Date.now().toString());
                
                // Force refresh
                window.location.reload(true);
            } else {
                console.log(`Backup timer check: No force refresh needed. Count from ${currentCount} to ${updatedCount}`);
            }
        }, 3000); // Changed from 4000 to 3000
    }
});

// Function to refresh the page and look for Take button
window.refreshAndLookForTakeButton = function(_customInterval) {
    console.log('Starting Take button refresh and monitoring process with complete page refreshes...');
    
    // Record the current time as the last refresh time
    sessionStorage.setItem('lastRefreshTime', Date.now().toString());
    
    // Clear any existing refresh timeout
    if (refreshTimeout) {
        clearTimeout(refreshTimeout);
        refreshTimeout = null;
    }
    
    // Show visual indicator that monitoring is active
    let refreshProgressElement = document.getElementById('refreshProgressNotification');
    if (!refreshProgressElement) {
        refreshProgressElement = document.createElement('div');
        refreshProgressElement.id = 'refreshProgressNotification';
        refreshProgressElement.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        `;
        refreshProgressElement.textContent = 'Initializing take button monitoring...';
        document.body.appendChild(refreshProgressElement);
        console.log('Added visual monitoring indicator to the page');
    }
    
    // Only reset these flags on first load, not on refreshes
    if (isFirstLoad) {
        // Reset refresh count and navigation flag
        refreshCount = 0; // Initialize to 0, will be set to max shortly
        navigatingBack = false;
        
        // Store current refresh count in sessionStorage to persist across refreshes
        sessionStorage.setItem('takeButtonRefreshCount', '0');
        sessionStorage.setItem('takeButtonMonitoringActive', 'true');
        sessionStorage.setItem('takeButtonMonitoringStartTime', Date.now().toString());
        
        // Set next refresh time
        sessionStorage.setItem('nextRefreshTime', (Date.now() + 10).toString()); // 10ms instead of REFRESH_INTERVAL
        
        isFirstLoad = false;
    } else {
        console.log('This is a refresh during monitoring - preserving state');
    }
    
    // Get settings for refresh behavior
    chrome.storage.local.get(['waitForTakeButton'], function(data) {
        // Always use immediate refresh, ignoring any custom interval passed
        const intervalValue = 10; // Changed from REFRESH_INTERVAL to 10ms for immediate refresh
        
        // Calculate max refreshes based on wait time and interval
        const waitTime = data.waitForTakeButton || 30; // Default to 30 seconds if not set
        maxRefreshes = Math.ceil(waitTime); // Now 1 refresh = 1 second countdown (regardless of actual refresh speed)
        
        // Set the refresh counter to the max value to count down
        refreshCount = maxRefreshes;
        sessionStorage.setItem('takeButtonRefreshCount', maxRefreshes.toString());
        
        // Store max refreshes in sessionStorage
        sessionStorage.setItem('takeButtonMaxRefreshes', maxRefreshes.toString());
        
        console.log(`Will refresh up to ${maxRefreshes} times immediately after each check, for a total wait time of ${waitTime} seconds`);
        
        // Check for Take button first before starting refresh cycle
        const takeButtonFound = checkForTakeButton();
        
        if (takeButtonFound) {
            console.log('Take button found on initial check - no need for refresh cycle');
            return; // Take button found, no need to refresh
        }
        
        // IMMEDIATE REFRESH: Instead of waiting for the first interval, perform first refresh immediately
        console.log('Take button not found on initial check - IMMEDIATELY refreshing page');
        
        // Decrement refresh count for the immediate refresh
        refreshCount--;
        sessionStorage.setItem('takeButtonRefreshCount', refreshCount.toString());
        
        // Create or update progress notification for the first refresh
        displayRefreshProgress(refreshCount, maxRefreshes);
        
        // Update lastRefreshTime before reloading
        sessionStorage.setItem('lastRefreshTime', Date.now().toString());
        
        // Set next refresh time 
        const nextRefreshTime = Date.now() + 10; // 10ms delay instead of REFRESH_INTERVAL
        sessionStorage.setItem('nextRefreshTime', nextRefreshTime.toString());
        
        // Execute immediate refresh
        console.log(`🔄 EXECUTING IMMEDIATE FIRST REFRESH`);
        
        // Immediate refresh with minimal delay to ensure session storage is saved
        setTimeout(() => {
            window.location.reload(true);
        }, 10); // 10ms instead of 100ms for even faster refresh
    });
        
    // Function to check for and handle Take button
    function checkForTakeButton() {
        // Get current refresh count from sessionStorage
        const storedCount = sessionStorage.getItem('takeButtonRefreshCount');
        refreshCount = storedCount ? parseInt(storedCount) : maxRefreshes;
        const maxStoredRefreshes = sessionStorage.getItem('takeButtonMaxRefreshes');
        maxRefreshes = maxStoredRefreshes ? parseInt(maxStoredRefreshes) : maxRefreshes;
        
        // Calculate seconds remaining for logging
        const secondsRemaining = refreshCount;
        console.log(`Current countdown: ${secondsRemaining} seconds remaining`);
        
        if (refreshCount <= 0) {
            console.log(`Countdown reached zero. Stopping and returning to All Available.`);
            clearRefreshCycle();
            navigatingBack = true;
            window.navigateToAllAvailable();
            return false;
        }

        // Check for "already assigned" message first
        const alreadyAssignedDiv = document.querySelector('div.cabinet_content_empty');
        if (alreadyAssignedDiv && alreadyAssignedDiv.textContent.includes('Sorry, this order has already been assigned to another writer')) {
            console.log('Order already assigned to another writer. Returning to available orders...');
            clearRefreshCycle();
            navigatingBack = true;
            window.navigateToAllAvailable();
            return false;
        }

        // Single exact selector for take button
        const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');
            
        if (takeButton) {
            console.log('TAKE BUTTON FOUND! Clicking...');
            simulateFullClick(takeButton);
                
            // Calculate remaining seconds
            const secondsRemaining = maxRefreshes - refreshCount;
                
            // Create a visual notification that take button was found
            const takeButtonFoundElement = document.createElement('div');
            takeButtonFoundElement.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: #4361ee;
                color: white;
                padding: 20px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
                z-index: 10000;
                box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                text-align: center;
            `;
            takeButtonFoundElement.textContent = `TAKE BUTTON FOUND! (${secondsRemaining} seconds remaining)`;
            document.body.appendChild(takeButtonFoundElement);
            
            // Remove any refresh progress notification
            const progressElement = document.getElementById('refreshProgressNotification');
            if (progressElement) {
                progressElement.remove();
            }
                
            // Look for confirmation button with single exact selector
            setTimeout(() => {
                // Single exact selector for confirmation button
                const confirmButton = document.querySelector('button.btn.btn_green.confirm_button[type="button"]');
                    
                if (confirmButton) {
                    console.log('Confirmation button found! Clicking IMMEDIATELY...');
                    simulateFullClick(confirmButton);
                        
                    // Clear refresh cycle after successful confirmation
                    clearRefreshCycle();
                        
                    // Notify background script that Take button was found and clicked
                    chrome.runtime.sendMessage({ action: 'takeButtonFound' });
                    
                    // Return to all available after successful take
                    setTimeout(() => {
                        console.log('Successfully took order! Returning to all available orders...');
                        if (!navigatingBack) {
                            navigatingBack = true;
                            sessionStorage.setItem('takeButtonConfirmed', 'true');
                            window.navigateToAllAvailable();
                        }
                    }, 2000);
                }
            }, 0); // Immediate check for confirmation button
                
            return true;
        }
            
        console.log('Take button not found after page check');
        return false;
    }
        
    // Function to schedule the next refresh
    function scheduleNextRefresh() {
        // Get current refresh count from sessionStorage (to handle page refreshes)
        const storedCount = sessionStorage.getItem('takeButtonRefreshCount');
        refreshCount = storedCount ? parseInt(storedCount) : maxRefreshes;
        const maxStoredRefreshes = sessionStorage.getItem('takeButtonMaxRefreshes');
        maxRefreshes = maxStoredRefreshes ? parseInt(maxStoredRefreshes) : maxRefreshes;
            
        // STRICT CHECK: If we've already reached zero on our countdown, stop and go back
        if (refreshCount <= 0) {
            console.log(`Countdown has reached zero. Stopping refresh cycle.`);
            clearRefreshCycle();
            
            // Only navigate back if we're not already doing so
            if (!navigatingBack) {
                navigatingBack = true;
                console.log('Completed full monitoring period, now returning to all available orders');
                
                // Clear countdown flags
                sessionStorage.removeItem('takeCountdownActive');
                sessionStorage.removeItem('takingOrder');
                
                // Create notification element to show completion
                const completionElement = document.createElement('div');
                completionElement.style.cssText = `
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    background-color: #48bb78;
                    color: white;
                    padding: 20px;
                    border-radius: 8px;
                    font-size: 16px;
                    font-weight: bold;
                    z-index: 10000;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                    text-align: center;
                `;
                completionElement.textContent = `⏱️ TIME LIMIT REACHED: Wait time completed. No Take button found. Returning to available orders...`;
                document.body.appendChild(completionElement);
                
                // Add pulsing animation to make it more noticeable
                const keyframes = `
                    @keyframes pulse {
                        0% { transform: translate(-50%, -50%) scale(1); }
                        50% { transform: translate(-50%, -50%) scale(1.05); }
                        100% { transform: translate(-50%, -50%) scale(1); }
                    }
                `;
                
                const style = document.createElement('style');
                style.textContent = keyframes;
                document.head.appendChild(style);
                
                completionElement.style.animation = 'pulse 1s infinite';
                
                // Set a flag for navigation completion
                sessionStorage.setItem('monitoringCompleted', 'true');
                
                // Navigate after a short delay to allow the user to see the notification
                setTimeout(() => {
                    window.navigateToAllAvailable();
                }, 2000);
            }
            return;
        }
        
        // Decrement refresh count for next refresh
        refreshCount--;
        sessionStorage.setItem('takeButtonRefreshCount', refreshCount.toString());
        
        // Calculate proper time for next refresh (exactly 1 second from now)
        const currentTime = Date.now();
        const nextRefreshTime = currentTime + REFRESH_INTERVAL;
        sessionStorage.setItem('nextRefreshTime', nextRefreshTime.toString());
        
        // Format and log time details
        const currentTimeStr = new Date(currentTime).toLocaleTimeString() + '.' + (currentTime % 1000).toString().padStart(3, '0');
        const nextTimeStr = new Date(nextRefreshTime).toLocaleTimeString() + '.' + (nextRefreshTime % 1000).toString().padStart(3, '0');
        
        console.log(`⏱️ SCHEDULING REFRESH - ${refreshCount} seconds remaining`);
        console.log(`   Current time: ${currentTimeStr}`);
        console.log(`   Next refresh: ${nextTimeStr} (exact 1-second interval)`);
        
        // Create or update progress notification
        displayRefreshProgress(refreshCount, maxRefreshes);
        
        // Set timeout for next refresh with exact timing
        refreshTimeout = setTimeout(() => {
            const executeTime = Date.now();
            const executeTimeStr = new Date(executeTime).toLocaleTimeString() + '.' + (executeTime % 1000).toString().padStart(3, '0');
            const timingAccuracy = executeTime - nextRefreshTime;
            
            // IMPORTANT: Check again if we've reached max refreshes (additional safety check)
            const finalCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
            const maxFinalRefreshes = parseInt(sessionStorage.getItem('takeButtonMaxRefreshes') || maxRefreshes);
            
            if (finalCount >= maxFinalRefreshes) {
                console.log(`Max refreshes reached at execution time (${finalCount}/${maxFinalRefreshes}). Stopping execution and navigating back.`);
                clearRefreshCycle();
                window.navigateToAllAvailable();
                return;
            }
            
            console.log(`🔄 EXECUTING REFRESH #${refreshCount}/${maxRefreshes} (immediate refresh)`);
            console.log(`   Execute time: ${executeTimeStr} (${timingAccuracy > 0 ? '+' : ''}${timingAccuracy}ms from scheduled)`);
            
            // Update lastRefreshTime before reloading
            sessionStorage.setItem('lastRefreshTime', executeTime.toString());
            
            // Make sure we're still in active monitoring before reloading
            if (sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
                // Force a full refresh with no cache
                console.log(`🔄 Reloading page now...`);
                window.location.reload(true);
            } else {
                console.log('Monitoring was stopped, cancelling scheduled refresh');
            }
        }, 10); // Changed from REFRESH_INTERVAL to 10ms for immediate refresh
    }
};

// Helper function to display refresh progress
function displayRefreshProgress(current, max) {
    // Remove any existing notification
    let progressElement = document.getElementById('refreshProgressNotification');
    if (!progressElement) {
        progressElement = document.createElement('div');
        progressElement.id = 'refreshProgressNotification';
        progressElement.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        `;
        document.body.appendChild(progressElement);
    }
    
    // With our new countdown approach, the secondsRemaining is passed directly as the first parameter
    const secondsRemaining = current;
    
    // Calculate progress percentage based on time elapsed
    const percent = Math.floor(((max - secondsRemaining) / max) * 100);
    
    // Update notification content to show countdown
    progressElement.textContent = `Take Button Monitoring: ${secondsRemaining} seconds remaining (${percent}%)`;
}

// Function to get current refresh count
window.getCurrentRefreshCount = function() {
    const storedCount = sessionStorage.getItem('takeButtonRefreshCount');
    return storedCount ? parseInt(storedCount) : refreshCount;
};

// Function to clear refresh count and interval
window.clearRefreshCount = function() {
    clearRefreshCycle();
};

// Helper function to clear the refresh cycle
function clearRefreshCycle() {
    if (refreshTimeout) {
        clearTimeout(refreshTimeout);
        refreshTimeout = null;
    }
    refreshCount = 0;
    sessionStorage.removeItem('takeButtonRefreshCount');
    sessionStorage.removeItem('takeButtonMaxRefreshes');
    sessionStorage.removeItem('takeButtonMonitoringActive');
    sessionStorage.removeItem('takeButtonMonitoringStartTime');
    sessionStorage.removeItem('nextRefreshTime');
    
    // When clearing refresh cycle, if countdown has reached zero, also clear the flags
    const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
    if (currentCount <= 0) {
        console.log('Countdown complete - clearing countdown flags');
        sessionStorage.removeItem('takeCountdownActive');
        sessionStorage.removeItem('takingOrder');
    }
    
    console.log('Cleared refresh cycle and monitoring session flags');
}

// Function to navigate to All Available Orders page
window.navigateToAllAvailable = function() {
    // Check all relevant monitoring flags
    const isMonitoringActive = sessionStorage.getItem('takeButtonMonitoringActive') === 'true';
    const isCountdownActive = sessionStorage.getItem('takeCountdownActive') === 'true';
    const isTakingOrder = sessionStorage.getItem('takingOrder') === 'true';
    const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
    
    console.log(`Navigation check - Monitoring: ${isMonitoringActive}, Countdown: ${isCountdownActive}, Taking: ${isTakingOrder}, Count: ${currentCount}`);
    
    // If any active monitoring is happening, don't navigate unless the count is zero
    if (isMonitoringActive || isCountdownActive || isTakingOrder) {
        console.log('🛑 Preventing navigation during take button monitoring - staying on current page');
        
        // Only navigate when countdown is complete (reaches 0)
        if (currentCount <= 0) {
            console.log('✅ Countdown has reached zero, now navigating to All Available');
            // Clear all flags
            sessionStorage.removeItem('takeCountdownActive');
            sessionStorage.removeItem('takingOrder');
            sessionStorage.removeItem('takeButtonMonitoringActive');
            console.log('Navigating to All Available Orders page...');
            window.location.href = "/writer/orders/all_available";
        } else {
            console.log(`⏱️ Still in countdown (${currentCount} seconds remaining), staying on page`);
            return; // Important: return early to prevent navigation
        }
    } else {
        console.log('No active monitoring detected, navigating to All Available Orders page...');
        window.location.href = "/writer/orders/all_available";
    }
};

// Function to stop Take button monitoring
window.stopTakeButtonMonitoring = function() {
    console.log('Stopping Take button monitoring...');
    clearRefreshCycle();
};

// Add a simulateFullClick function if it doesn't exist
if (typeof window.simulateFullClick !== 'function') {
    window.simulateFullClick = function(element) {
        if (!element) {
            console.error('No element found to click on!');
            return false;
        }
    
        try {
            console.log('Simulating full click on element:', element);
            
            // Enable the element temporarily if it's disabled
            const wasDisabled = element.disabled;
            if (wasDisabled) {
                console.log('Element was disabled, temporarily enabling for click');
                element.disabled = false;
            }
            
            // First make the element visible and interactable if it's not
            const originalVisibility = element.style.visibility;
            const originalDisplay = element.style.display;
            const originalPointerEvents = element.style.pointerEvents;
            
            element.style.visibility = 'visible';
            element.style.display = 'inline-block';
            element.style.pointerEvents = 'auto';
            
            // Try standard click first as it's most reliable
            element.click();
            
            // Then do the full event simulation with multiple approaches
            try {
                // Approach 1: Standard MouseEvent
                ['mousedown', 'mouseup', 'click'].forEach(eventType => {
                    const event = new MouseEvent(eventType, {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        buttons: 1
                    });
                    element.dispatchEvent(event);
                });
                
                // Approach 2: Try with a more detailed MouseEvent if supported
                ['mousedown', 'mouseup', 'click'].forEach(eventType => {
                    try {
                        const event = new MouseEvent(eventType, {
                            view: window,
                            bubbles: true,
                            cancelable: true,
                            detail: 1,
                            screenX: 1,
                            screenY: 1,
                            clientX: 1,
                            clientY: 1,
                            buttons: 1
                        });
                        element.dispatchEvent(event);
                    } catch (e) {
                        // Ignore errors on this approach
                    }
                });
            } catch (e) {
                console.error(`Error in click event simulation:`, e);
            }
            
            // Restore element properties
            if (wasDisabled) {
                element.disabled = true;
            }
            
            element.style.visibility = originalVisibility;
            element.style.display = originalDisplay;
            element.style.pointerEvents = originalPointerEvents;
            
            console.log('Click simulation completed successfully');
            return true;
        } catch (e) {
            console.error('Error in click simulation:', e);
            return false;
        }
    };
} 

// Add a document ready handler to continue refresh cycle after page reload
document.addEventListener('DOMContentLoaded', function() {
    console.log('takeButtonDetector: Page loaded, checking for active monitoring session...');
    
    // Record the current page load time
    sessionStorage.setItem('lastRefreshTime', Date.now().toString());
    
    // Check if we're in the middle of a take button monitoring session
    if (sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
        console.log('🔍 Active take button monitoring detected after page reload');
        
        // Reset the isFirstLoad flag since we're resuming an existing session
        isFirstLoad = false; 
        
        // Get the monitoring details for logging
        const startTimeStr = sessionStorage.getItem('takeButtonMonitoringStartTime');
        const countdownStr = sessionStorage.getItem('takeButtonRefreshCount');
        const maxRefreshesStr = sessionStorage.getItem('takeButtonMaxRefreshes');
        
        if (startTimeStr && countdownStr && maxRefreshesStr) {
            const startTime = parseInt(startTimeStr);
            const secondsRemaining = parseInt(countdownStr);
            const maxTime = parseInt(maxRefreshesStr);
            const elapsedMs = Date.now() - startTime;
            const elapsedSec = Math.floor(elapsedMs / 1000);
            const percentComplete = Math.floor(((maxTime - secondsRemaining) / maxTime) * 100);
            
            console.log(`⏱️ Monitoring session details:
                - Started: ${new Date(startTime).toLocaleTimeString()}
                - Elapsed: ${elapsedSec} seconds
                - Remaining: ${secondsRemaining} seconds
                - Progress: ${percentComplete}%
            `);
            
            // CRITICAL CHECK: If the countdown is zero or negative, reset and navigate back IMMEDIATELY
            if (secondsRemaining <= 0) {
                console.log(`🛑 Countdown finished (${secondsRemaining} seconds). Stopping and navigating back IMMEDIATELY.`);
                clearRefreshCycle();
                navigatingBack = true;
                window.navigateToAllAvailable();
                return;
            }
        }
        
        // First priority: Check for take button immediately
        setTimeout(() => {
            // Define the checkForTakeButton function inside this scope
            // instead of relying on the global one which might not be accessible
            function checkForTakeButtonInDom() {
                console.log('Checking for Take button after page reload...');
                
                // Get current refresh count again to ensure accuracy
                const refreshCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
                const maxRefreshes = parseInt(sessionStorage.getItem('takeButtonMaxRefreshes') || '50');
                
                // CRITICAL CHECK: If the count is already at zero or below, reset and navigate back
                if (refreshCount <= 0) {
                    console.log(`🚨 CRITICAL: Countdown reached zero (${refreshCount}) during check. Stopping and returning to All Available IMMEDIATELY.`);
                    clearRefreshCycle();
                    navigatingBack = true;
                    window.navigateToAllAvailable();
                    return false;
                }
                
                // Single exact selector for take button
                const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');
                
                if (takeButton) {
                    console.log('TAKE BUTTON FOUND! Clicking...');
                    simulateFullClick(takeButton);
                    
                    // Calculate seconds remaining
                    const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
                    const maxCount = parseInt(sessionStorage.getItem('takeButtonMaxRefreshes') || '50');
                    const secondsRemaining = maxCount - currentCount;
                    
                    // Create a visual notification that take button was found
                    const takeButtonFoundElement = document.createElement('div');
                    takeButtonFoundElement.style.cssText = `
                        position: fixed;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        background-color: #4361ee;
                        color: white;
                        padding: 20px;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                        z-index: 10000;
                        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                        text-align: center;
                    `;
                    takeButtonFoundElement.textContent = `TAKE BUTTON FOUND! (${secondsRemaining} seconds remaining)`;
                    document.body.appendChild(takeButtonFoundElement);
                    
                    // Remove any refresh progress notification
                    const progressElement = document.getElementById('refreshProgressNotification');
                    if (progressElement) {
                        progressElement.remove();
                    }
                    
                    // Look for confirmation button after a short delay
                    setTimeout(() => {
                        // Single exact selector for confirmation button
                        const confirmButton = document.querySelector('button.btn.btn_green.confirm_button[type="button"]');
                        
                        if (confirmButton) {
                            console.log('Confirmation button found! Clicking IMMEDIATELY...');
                            simulateFullClick(confirmButton);
                            
                            // Clear refresh cycle after successful confirmation
                            clearRefreshCycle();
                            
                            // Notify background script that Take button was found and clicked
                            chrome.runtime.sendMessage({ action: 'takeButtonFound' });
                        
                            // Return to all available after successful take
                            setTimeout(() => {
                                console.log('Successfully took order! Returning to all available orders...');
                                if (!navigatingBack) {
                                    navigatingBack = true;
                                    sessionStorage.setItem('takeButtonConfirmed', 'true');
                                    window.navigateToAllAvailable();
                                }
                            }, 2000);
                        } else {
                            console.log('No confirmation button found after Take button.');
                        }
                    }, 0); // Changed from 500ms to 0ms for immediate execution
                    
                    return true;
                }
                
                console.log('Take button not found after page check');
                return false;
            }
            
            // Check for take button first before scheduling next refresh
            const buttonFound = checkForTakeButtonInDom();
            
            if (buttonFound) {
                console.log('✅ Take button found after page reload! Stopping refresh cycle.');
                return;
            } 
            
            // If button not found, continue with refresh cycle
            console.log('❌ Take button not found after page reload. Continuing refresh cycle.');
            
            // Get current refresh count and validate it
            const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
            const maxCount = parseInt(sessionStorage.getItem('takeButtonMaxRefreshes') || '50'); // Default to 50 for 1-second intervals
            
            // FINAL SAFETY CHECK: If we've reached zero on our countdown, STOP immediately and return to all available
            if (currentCount <= 0) {
                console.log(`❗ Countdown has reached zero after reload, returning to all available IMMEDIATELY`);
                clearRefreshCycle();
                navigatingBack = true;
                window.navigateToAllAvailable();
                return;
            }
            
            // Decrement the counter here to continue countdown
            const newCount = currentCount - 1;
            
            // ADDITIONAL SAFETY CHECK: Don't make negative
            if (newCount < 0) {
                console.log(`❗ Refusing to decrement counter below zero`);
                clearRefreshCycle();
                navigatingBack = true;
                window.navigateToAllAvailable();
                return;
            }
            
            sessionStorage.setItem('takeButtonRefreshCount', newCount.toString());
            console.log(`✓ Countdown continuing: ${newCount} seconds remaining`);
            
            // Display progress notification
            displayRefreshProgress(maxCount - newCount, maxCount);
            
            // Schedule next refresh with precise timing
            console.log(`✓ Scheduling next refresh #${newCount}/${maxCount}`);
            
            // Calculate and log seconds remaining
            const secondsRemaining = maxCount - newCount;
            console.log(`⏱️ Time remaining: ${secondsRemaining} seconds`);
            
            // Calculate time to next refresh based on stored nextRefreshTime
            const nextRefreshTime = parseInt(sessionStorage.getItem('nextRefreshTime') || '0');
            let timeToNextRefresh = 10; // Changed from REFRESH_INTERVAL to 10ms for immediate refresh
            
            if (nextRefreshTime > 0) {
                const now = Date.now();
                timeToNextRefresh = Math.min(10, nextRefreshTime - now); // Force 10ms max delay
                
                // If next refresh time is in the past or very soon, use a small delay
                if (timeToNextRefresh < 0) {
                    timeToNextRefresh = 10; // Minimum 10ms delay to ensure DOM is ready
                }
                
                console.log(`⏱️ Time to next refresh: ${timeToNextRefresh}ms (immediate refresh)`);
            } else {
                // No valid next refresh time found, create one now but use immediate refresh
                const newRefreshTime = Date.now() + 10; // 10ms delay
                sessionStorage.setItem('nextRefreshTime', newRefreshTime.toString());
                console.log(`⏱️ Created new refresh time for immediate refresh`);
            }
            
            // Execute refresh after calculated delay
            console.log(`⏲️ Scheduling page refresh in ${timeToNextRefresh}ms`);
            
            setTimeout(() => {
                // FINAL CHECK: Ensure we haven't reached zero countdown
                const finalCheck = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
                
                if (finalCheck <= 0) {
                    console.log(`🚨 FINAL CHECK: Countdown reached zero (${finalCheck}). Navigating back instead of refreshing.`);
                    clearRefreshCycle();
                    navigatingBack = true;
                    window.navigateToAllAvailable();
                    return;
                }
                
                // Set next refresh time (exactly 1 second from now)
                const nextRefresh = Date.now() + 10; // Changed from REFRESH_INTERVAL to 10ms
                sessionStorage.setItem('nextRefreshTime', nextRefresh.toString());
                
                // Update last refresh time
                sessionStorage.setItem('lastRefreshTime', Date.now().toString());
                
                // Execute refresh
                console.log(`🔄 Executing refresh #${newCount}/${maxCount} (immediate refresh)`);
                window.location.reload(true);
            }, timeToNextRefresh);
        }, 10); // Changed from 300ms to 10ms to ensure checks happen immediately
    }
}); 

// Add a message listener to directly handle startTakeButtonMonitoring
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // Only handle messages that are relevant to takeButtonDetector
    if (request.action === 'startTakeButtonMonitoring') {
        console.log('takeButtonDetector: Received startTakeButtonMonitoring message directly from recaptchaCheck');
        
        // Set monitoring flag in session storage
        sessionStorage.setItem('takeButtonMonitoringActive', 'true');
        
        // Start the monitoring process immediately
        window.refreshAndLookForTakeButton();
        
        // Acknowledge the message
        sendResponse({ success: true, message: 'Take button monitoring started in content script' });
        return true;
    }
    
    // Handle startTakeButtonRefresh message from background.js
    if (request.action === 'startTakeButtonRefresh') {
        console.log('takeButtonDetector: Received startTakeButtonRefresh message from background');
        
        // Configure refresh interval if provided
        const refreshInterval = request.refreshInterval || 1000;
        console.log(`Using configured refresh interval: ${refreshInterval}ms`);
        
        // Start the monitoring process
        window.refreshAndLookForTakeButton(refreshInterval);
        
        // Acknowledge the message
        sendResponse({ success: true, message: 'Take button refresh started in content script' });
        return true;
    }
    
    // Handle checkForTakeButton message
    if (request.action === 'checkForTakeButton') {
        console.log('takeButtonDetector: Received checkForTakeButton message');
        
        // If we're already monitoring, acknowledge and do nothing else
        if (sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
            console.log('Already monitoring for Take button, continuing with refresh cycle');
            sendResponse({ success: true, alreadyMonitoring: true });
            return true;
        }
        
        // Start monitoring if not already active
        window.refreshAndLookForTakeButton();
        
        // Acknowledge the message
        sendResponse({ success: true, message: 'Started Take button check' });
        return true;
    }
}); 

// Add a failsafe to ensure monitoring starts correctly
window.addEventListener('load', function() {
    // Check if we're supposed to be monitoring but no refresh has occurred
    setTimeout(() => {
        if (sessionStorage.getItem('takeButtonMonitoringActive') === 'true') {
            console.log('FAILSAFE CHECK: Verifying take button monitoring is active...');
            
            // Get the last refresh time
            const lastRefreshTime = parseInt(sessionStorage.getItem('lastRefreshTime') || '0');
            const currentTime = Date.now();
            const timeSinceLastRefresh = currentTime - lastRefreshTime;
            
            // If no refresh has occurred in the last 2 seconds, force one
            if (timeSinceLastRefresh > 2000) {
                console.log('FAILSAFE TRIGGERED: No recent refresh detected. Force starting monitoring...');
                
                // Get countdown value or set to default
                const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
                if (currentCount <= 0) {
                    // Get the configured wait time
                    chrome.storage.local.get(['waitForTakeButton'], function(data) {
                        const waitTime = data.waitForTakeButton || 30; // Default 30 seconds
                        sessionStorage.setItem('takeButtonRefreshCount', waitTime.toString());
                        sessionStorage.setItem('takeButtonMaxRefreshes', waitTime.toString());
                        
                        console.log(`FAILSAFE: Setting countdown to ${waitTime} seconds`);
                        
                        // Display progress and force reload
                        displayRefreshProgress(waitTime, waitTime);
                        
                        // Force immediate refresh
                        setTimeout(() => {
                            console.log('FAILSAFE: Forcing page refresh now...');
                            window.location.reload(true);
                        }, 500);
                    });
                } else {
                    // Continue with existing countdown
                    console.log(`FAILSAFE: Continuing with existing countdown: ${currentCount} seconds remaining`);
                    
                    // Get max value for display
                    const maxCount = parseInt(sessionStorage.getItem('takeButtonMaxRefreshes') || '30');
                    
                    // Display progress and force reload
                    displayRefreshProgress(currentCount, maxCount);
                    
                    // Force immediate refresh
                    setTimeout(() => {
                        console.log('FAILSAFE: Forcing page refresh with existing countdown...');
                        window.location.reload(true);
                    }, 500);
                }
            } else {
                console.log(`FAILSAFE CHECK: Recent refresh detected ${timeSinceLastRefresh}ms ago. Monitoring appears active.`);
            }
        }
    }, 3000); // Check 3 seconds after page load
});