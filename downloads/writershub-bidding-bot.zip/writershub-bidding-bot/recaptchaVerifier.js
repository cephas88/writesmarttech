/**
 * recaptchaVerifier.js - Handles all reCAPTCHA verification logic
 * This file contains functions to check if reCAPTCHA is verified
 */

/**
 * Comprehensive function to detect if reCAPTCHA is solved
 * @returns {boolean} True if verified, false otherwise
 */
function isRecaptchaVerified() {
  // Results from different detection methods
  const results = {
    methods: {},
    overallResult: false
  };
  
  try {
    // Method 1: Check status element text (works for reCAPTCHA v2 checkbox)
    const statusElements = document.querySelectorAll('[id^="recaptcha-accessible-status"], .recaptcha-accessible-status');
    if (statusElements.length > 0) {
      for (const statusElement of statusElements) {
        const isVerified = statusElement.innerText.includes('verified') || 
                          statusElement.innerText.includes('Verified') ||
                          !statusElement.innerText.includes('Recaptcha requires verification');
                          
        results.methods.statusElement = isVerified;
        if (isVerified) break;
      }
    }
    
    // Method 2: Check aria-checked attribute on checkbox
    const checkboxElements = document.querySelectorAll('[id^="recaptcha-anchor"], .recaptcha-checkbox');
    if (checkboxElements.length > 0) {
      for (const checkbox of checkboxElements) {
        const isChecked = checkbox.getAttribute('aria-checked') === 'true';
        results.methods.ariaChecked = isChecked;
        if (isChecked) break;
      }
    }
    
    // Method 3: Check for checked class on checkbox
    if (checkboxElements.length > 0) {
      for (const checkbox of checkboxElements) {
        const hasCheckedClass = checkbox.classList.contains('recaptcha-checkbox-checked');
        results.methods.checkedClass = hasCheckedClass;
        if (hasCheckedClass) break;
      }
    }
    
    // Method 4: Check visual elements (checkmark visible, border hidden)
    const checkmarks = document.querySelectorAll('.recaptcha-checkbox-checkmark');
    const borders = document.querySelectorAll('.recaptcha-checkbox-border');
    
    if (checkmarks.length > 0 && borders.length > 0) {
      for (let i = 0; i < Math.min(checkmarks.length, borders.length); i++) {
        const checkmarkVisible = getComputedStyle(checkmarks[i]).display !== 'none';
        const borderHidden = getComputedStyle(borders[i]).display === 'none';
        const visualVerified = checkmarkVisible && borderHidden;
        results.methods.visualElements = visualVerified;
        if (visualVerified) break;
      }
    }
    
    // Method 5: Check for g-recaptcha-response element with content
    const responseElements = document.querySelectorAll('[name="g-recaptcha-response"]');
    if (responseElements.length > 0) {
      for (const element of responseElements) {
        const hasResponse = element.value && element.value.length > 0;
        results.methods.responseElement = hasResponse;
        if (hasResponse) break;
      }
    }
    
    // Method 6: Check for data-response attribute on container
    const containers = document.querySelectorAll('[data-sitekey], .g-recaptcha');
    if (containers.length > 0) {
      for (const container of containers) {
        const hasDataResponse = container.dataset.response && container.dataset.response.length > 0;
        results.methods.dataAttribute = hasDataResponse;
        if (hasDataResponse) break;
      }
    }
    
    // Method 7: Check grecaptcha API response (most reliable for modern implementations)
    if (typeof window.grecaptcha !== 'undefined') {
      try {
        // Handle multiple reCAPTCHA widgets on the same page
        if (typeof window.grecaptcha.getResponse === 'function') {
          const response = window.grecaptcha.getResponse();
          results.methods.grecaptchaAPI = response && response.length > 0;
        } else if (typeof window.grecaptcha.enterprise === 'object' && 
                  typeof window.grecaptcha.enterprise.getResponse === 'function') {
          const response = window.grecaptcha.enterprise.getResponse();
          results.methods.grecaptchaEnterpriseAPI = response && response.length > 0;
        } else if (window.___grecaptcha_cfg && window.___grecaptcha_cfg.clients) {
          // Handle multiple widgets case
          const clients = window.___grecaptcha_cfg.clients;
          let multiWidgetResponse = false;
          
          Object.keys(clients).forEach(key => {
            const client = clients[key];
            Object.keys(client).forEach(widgetId => {
              if (typeof client[widgetId].responses === 'object') {
                const responses = Object.values(client[widgetId].responses);
                if (responses.some(response => response && response.length > 0)) {
                  multiWidgetResponse = true;
                }
              }
            });
          });
          
          results.methods.grecaptchaMultiWidget = multiWidgetResponse;
        }
      } catch (err) {
        console.warn('Error checking grecaptcha API:', err);
      }
    }
    
    // Method 8: Check for reCAPTCHA V3 token in forms
    const forms = document.querySelectorAll('form');
    let formTokenFound = false;
    forms.forEach(form => {
      const inputs = form.querySelectorAll('input[name^="recaptcha"], input[name^="g-recaptcha"]');
      inputs.forEach(input => {
        if (input.value && input.value.length > 0) {
          formTokenFound = true;
        }
      });
    });
    results.methods.formToken = formTokenFound;
    
    // Determine overall result - if ANY method indicates solved, consider it solved
    results.overallResult = Object.values(results.methods).some(result => result === true);
    
  } catch (error) {
    console.error('Error detecting reCAPTCHA status:', error);
    results.error = error.message;
  }
  
  return results.overallResult;
}

/**
 * Function to log detailed information about the current reCAPTCHA status
 * Useful for debugging verification issues
 */
function logRecaptchaStatus() {
  console.group('reCAPTCHA Status Check');
  
  const verified = isRecaptchaVerified();
  
  if (verified) {
    console.log('%c ✓ reCAPTCHA IS SOLVED', 'color: #0f9d58; font-weight: bold; font-size: 16px;');
  } else {
    console.log('%c ✗ reCAPTCHA IS NOT SOLVED', 'color: #db4437; font-weight: bold; font-size: 16px;');
  }
  
  // Log status element details
  const statusElements = document.querySelectorAll('[id^="recaptcha-accessible-status"], .recaptcha-accessible-status');
  if (statusElements.length > 0) {
    console.log('Status elements found:', statusElements.length);
    statusElements.forEach((el, i) => {
      console.log(`Status element #${i+1} text:`, el.innerText);
      console.log(`Status element #${i+1} HTML:`, el.outerHTML);
    });
  } else {
    console.log('No status elements found');
  }
  
  // Log checkbox elements details
  const checkboxElements = document.querySelectorAll('[id^="recaptcha-anchor"], .recaptcha-checkbox');
  if (checkboxElements.length > 0) {
    console.log('Checkbox elements found:', checkboxElements.length);
    checkboxElements.forEach((el, i) => {
      console.log(`Checkbox #${i+1} aria-checked:`, el.getAttribute('aria-checked'));
      console.log(`Checkbox #${i+1} classes:`, el.className);
    });
  } else {
    console.log('No checkbox elements found');
  }
  
  // Log visual elements details
  const checkmarks = document.querySelectorAll('.recaptcha-checkbox-checkmark');
  const borders = document.querySelectorAll('.recaptcha-checkbox-border');
  if (checkmarks.length > 0) {
    console.log('Checkmark elements found:', checkmarks.length);
    checkmarks.forEach((el, i) => {
      console.log(`Checkmark #${i+1} display:`, getComputedStyle(el).display);
    });
  } else {
    console.log('No checkmark elements found');
  }
  
  console.groupEnd();
  
  return verified;
}

/**
 * Function to wait for reCAPTCHA verification
 * @param {Function} callback - Function to call when verification completes
 * @param {number} interval - Check interval in milliseconds
 * @param {number} timeout - Maximum wait time in milliseconds
 * @returns {Object} Object with cancel method
 */
function waitForRecaptchaVerification(callback, interval = 1000, timeout = 60000) {
  const startTime = Date.now();
  console.log(`🔄 Starting reCAPTCHA verification check (timeout: ${timeout/1000}s, check interval: ${interval}ms)`);
  
  const checkInterval = setInterval(() => {
    // Check if reCAPTCHA is verified
    if (isRecaptchaVerified()) {
      clearInterval(checkInterval);
      console.log(`✅ reCAPTCHA verified after ${(Date.now() - startTime)/1000} seconds`);
      callback(true);
      return;
    }
    
    // Check if timeout has been reached
    if (Date.now() - startTime > timeout) {
      clearInterval(checkInterval);
      const timeoutError = `Timeout waiting for reCAPTCHA verification after ${timeout/1000} seconds`;
      console.log(`❌ ${timeoutError}`);
      callback(false, timeoutError);
      return;
    }
    
    // Log progress every few checks
    if ((Date.now() - startTime) % 5000 < interval) {
      console.log(`Still waiting for reCAPTCHA verification... (${Math.round((Date.now() - startTime)/1000)}s elapsed)`);
    }
  }, interval);
  
  return {
    cancel: () => {
      console.log('⚠️ reCAPTCHA verification check cancelled manually');
      clearInterval(checkInterval);
    }
  };
}

/**
 * Set up a monitor that checks for solved reCAPTCHA continuously
 * @param {Function} onSolved - Callback to execute when reCAPTCHA is solved
 * @param {number} checkInterval - How often to check (milliseconds)
 * @returns {Object} Object with stop method to stop monitoring
 */
function monitorRecaptchaStatus(onSolved, checkInterval = 2000) {
  console.log(`Starting reCAPTCHA monitor (checking every ${checkInterval/1000} seconds)`);
  
  const monitorId = setInterval(() => {
    const solved = isRecaptchaVerified();
    if (solved) {
      console.log('✓ reCAPTCHA was solved!');
      clearInterval(monitorId); // Stop monitoring once solved
      if (typeof onSolved === 'function') {
        onSolved();
      }
    }
  }, checkInterval);
  
  return {
    stop: () => {
      console.log('reCAPTCHA monitoring stopped');
      clearInterval(monitorId);
    }
  };
}

// Export functions for use in other files
window.recaptchaVerifier = {
  isVerified: isRecaptchaVerified,
  waitForVerification: waitForRecaptchaVerification,
  logStatus: logRecaptchaStatus,
  monitor: monitorRecaptchaStatus
}; 