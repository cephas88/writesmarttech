 = Get-Content -Path " content.js\; [2255] = \\; Set-Content -Path \content.js\ -Value 
