/**
 * Background script for the WritersHub extension
 * Handles monitoring, processing, and tracking of orders
 */

// Add service worker activation listener for Manifest V3
chrome.runtime.onInstalled.addListener(function(details) {
    console.log('Extension installed or updated:', details.reason);
    
    // Set initial installation flag if this is a fresh install
    if (details.reason === 'install') {
        chrome.storage.local.set({ 
            initialInstall: true,
            freeTrialActive: true // Set free trial active by default on installation
        });
    }
    
    // When extension is updated, check if we need to set the freeTrialActive flag for existing installs
    if (details.reason === 'update') {
        chrome.storage.local.get(['trialActivated', 'freeTrialActive'], function(data) {
            // If the user has an active trial but no freeTrialActive flag, set it
            if (data.trialActivated && data.freeTrialActive === undefined) {
                console.log('Setting freeTrialActive flag for existing active trial');
                chrome.storage.local.set({ freeTrialActive: true });
            }
        });
    }
    
    // Create necessary alarms
    chrome.alarms.create('refreshCheck', { periodInMinutes: 0.0667 }); // Check every 4 seconds for order monitoring
    
    // Create a more precise alarm for take button monitoring (every 1 second exactly)
    chrome.alarms.create('takeButtonCheck', { periodInMinutes: 0.0167 }); // 1 second = 0.0167 minutes
});

// Service worker activation listener for Manifest V3
chrome.runtime.onStartup.addListener(() => {
    console.log('Extension starting up...');
    // Create necessary alarms on startup
    chrome.alarms.create('refreshCheck', { periodInMinutes: 0.0667 }); // Check every 4 seconds
    
    // Create a more precise alarm for take button monitoring (every 1 second exactly)
    chrome.alarms.create('takeButtonCheck', { periodInMinutes: 0.0167 }); // 1 second = 0.0167 minutes
});

// Alarm listener to handle periodic tasks
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'refreshCheck') {
        // Only perform tasks if monitoring is active
        if (state.monitoringActive && !state.currentlyProcessingOrder && !state.redirecting) {
            performRefreshCheck();
        }
    } 
    else if (alarm.name === 'takeButtonCheck') {
        // Handle take button monitoring separately for more reliability
        if (state.monitoringForTakeButton && !state.takeButtonFound) {
            performTakeButtonCheck();
        }
    }
});

// Global state for the extension
const state = {
    botRunning: false,
    monitoringActive: false,
    refreshCount: 0,
    waitForTakeButtonSeconds: 30, // Default, will be updated from settings
    processedOrderUrls: new Set(), // Track orders that didn't meet criteria
    currentlyProcessingOrder: false,
    redirecting: false,
    lastRefreshTime: 0,
    refreshThrottleMs: 4000, // Minimum time between refreshes (4 seconds for order monitoring)
    monitoringForTakeButton: false, // Flag to indicate we're specifically waiting for Take button
    awaitingTakeButtonOn: null, // URL of the page where we're waiting for Take button
    takeButtonFound: false, // Flag to track if take button was found during monitoring
    lastNavigationTime: 0, // Track last navigation time to prevent rapid navigations
    navigationThrottleMs: 2000, // Minimum time between navigations
    // These properties replace refreshIntervalId
    takeButtonCheckStartTime: 0,
    takeButtonMaxWaitMs: 30000, // Default 30 seconds
    refreshInterval: 1000, // Default refresh interval in ms (1 second for take button monitoring)
    lastRefreshTimestamp: 0, // Added for the new take button check logic
    pendingTabIdForStartBidding: null, // NEW: Track tab waiting for startBidding
    processingOrderTimeout: null // NEW: Track processing timeout
};

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Background received message:', request.action, request);
    
    try {
        switch (request.action) {
            case 'startBot':
                console.log('Received startBot message with details:', request);
                // Always start the bot
                startBot(request.createTab);
                sendResponse({ success: true, message: 'Bot started' });
                break;
                
            case 'stopBot':
                stopBot();
                sendResponse({ success: true, message: 'Bot stopped' });
                break;
                
            case 'checkStatus':
                sendResponse({ 
                    botRunning: state.botRunning,
                    monitoringActive: state.monitoringActive,
                    refreshCount: state.refreshCount,
                    processedOrderCount: state.processedOrderUrls.size,
                    monitoringForTakeButton: state.monitoringForTakeButton
                });
                break;
                
            case 'ping':
                sendResponse({ status: 'alive' });
                break;
                
            case 'closeTab':
                // Close the tab that sent the message
                if (sender && sender.tab && sender.tab.id) {
                    console.log('Closing tab:', sender.tab.id);
                    try {
                        chrome.tabs.remove(sender.tab.id, function() {
                            if (chrome.runtime.lastError) {
                                console.error('Error closing tab:', chrome.runtime.lastError);
                            } else {
                                console.log('Tab closed successfully');
                            }
                        });
                    } catch (error) {
                        console.error('Exception during tab close:', error);
                    }
                    sendResponse({ success: true });
                } else {
                    console.error('Invalid sender information in closeTab message');
                    sendResponse({ success: false, error: 'Invalid sender' });
                }
                break;
                
            case 'clearProcessedOrders':
                console.log('Clearing all processed orders from memory and storage');
                // Clear the in-memory set
                state.processedOrderUrls.clear();
                
                // Clear the storage
                chrome.storage.local.set({
                    processedOrderUrls: [],
                    processedOrderIds: []
                }, function() {
                    console.log('All processed order history has been cleared');
                });
                
                sendResponse({ success: true, message: 'All processed orders cleared' });
                break;
                
            case 'orderFound':
                if (sender && sender.tab && sender.tab.id) {
                    handleOrderFound(sender.tab.id);
                    sendResponse({ success: true });
                } else {
                    console.error('Invalid sender information in orderFound message');
                    sendResponse({ success: false, error: 'Invalid sender' });
                }
                break;
                
            case 'contentScriptReady':
                // ADDED: Handle the content script ready message
                console.log('Content script is ready on tab:', sender.tab.id, 'URL:', request.url);
                
                // If bot is running and on the right page, tell content script to start bidding
                if (state.botRunning && request.url && 
                    request.url.includes('writershub.org') && 
                    sender && sender.tab) {
                    
                    console.log('Telling content script to start bidding since bot is running');
                    setTimeout(function() {
                        try {
                            chrome.tabs.sendMessage(sender.tab.id, { action: 'startBidding' });
                        } catch (error) {
                            console.error('Error sending startBidding to content script:', error);
                        }
                    }, 1000);
                }
                
                // ADDED: If the content script is requesting bot status, include it in the response
                if (request.requestBotStatus) {
                    console.log('Content script requested bot status, responding with:', state.botRunning);
                    sendResponse({ 
                        success: true, 
                        botRunning: state.botRunning 
                    });
                } else {
                    sendResponse({ success: true });
                }
                break;
                
            case 'orderProcessingComplete':
                handleOrderProcessingComplete(request.metCriteria, request.orderUrl, request.orderId, request.reasons);
                // Make sure to acknowledge the message
                sendResponse({ success: true });
                break;
                
            case 'navigateToAllAvailable':
                console.log('Received request to navigate to All Available page');
                // Check if we're already in the process of navigating
                if (!state.redirecting) {
                    forceNavigateToAllAvailable();
                    sendResponse({ success: true });
                } else {
                    console.log('Navigation already in progress, ignoring duplicate request');
                    sendResponse({ success: false, message: 'Navigation already in progress' });
                }
                break;
                
            case 'trialActivatedFromPopup':
                console.log('Trial activated from popup');
                sendResponse({ success: true });
                break;
                    
            case 'stopTakeButtonMonitoring':
                // Only stop if actually monitoring
                if (state.monitoringForTakeButton) {
                    stopTakeButtonMonitoring();
                    sendResponse({ success: true });
                } else {
                    console.log('Ignoring stopTakeButtonMonitoring - not currently monitoring');
                    sendResponse({ success: false, message: 'Not currently monitoring' });
                }
                break;
                
            case 'resetRefreshCount':
                state.refreshCount = 0;
                sendResponse({ success: true });
                break;
                    
            // Handle startTakeButtonMonitoring message from content.js
            case 'startTakeButtonMonitoring':
                if (!state.botRunning) {
                    console.log('Bot is not running, auto-starting bot for take button monitoring...');
                    startBot();
                }
                
                // Only start monitoring if not already monitoring
                if (!state.monitoringForTakeButton) {
                    console.log('Starting EXCLUSIVE take button monitoring...');
                    
                    // Stop any existing monitoring
                    stopMonitoring();
                    
                    // Set up monitoring exclusively for take button
                    state.monitoringForTakeButton = true;
                    state.awaitingTakeButtonOn = sender.tab.url;
                    state.takeButtonFound = false;
                    
                    // Use the refreshInterval if provided, otherwise default to 1000ms (1 second)
                    const refreshInterval = request.refreshInterval || 1000;
                    console.log(`Using refresh interval of ${refreshInterval/1000} seconds for Take button monitoring`);
                    
                    // Immediately refresh the tab to start monitoring
                    console.log(`Immediately refreshing tab ${sender.tab.id} to start take button monitoring`);
                    refreshTab(sender.tab.id);
                    
                    startTakeButtonRefresh(sender.tab.id, refreshInterval);
                    
                    sendResponse({ status: 'monitoringStarted' });
                } else {
                    console.log('Already monitoring for take button, ignoring duplicate request');
                    sendResponse({ status: 'alreadyMonitoring' });
                }
                break;
                
            case 'takeButtonFound':
                console.log('Take button was found and clicked!');
                handleTakeButtonFound();
                sendResponse({ success: true });
                break;
                
            case 'confirmationClicked':
                console.log('Confirmation button was clicked!');
                // This is handled by handleTakeButtonFound, but we acknowledge the message
                sendResponse({ success: true });
                break;
                
            case 'isManagingOwnRefreshes':
                // Content script is asking if it should manage its own refreshes
                sendResponse({ managingOwnRefreshes: false });
                break;
                
            case 'onOrderPage':
                console.log('Content script reports we are on an order page:', request.url);
                if (sender && sender.tab && sender.tab.id) {
                    // If we're currently processing an order, let the content script know
                    if (state.currentlyProcessingOrder) {
                        console.log('Already processing an order, sending processOrder message');
                        chrome.tabs.sendMessage(sender.tab.id, { action: 'processOrder' });
                    } else {
                        console.log('Setting currentlyProcessingOrder to true and sending processOrder');
                        state.currentlyProcessingOrder = true;
                        
                        // Set a safety timeout to reset the processing state if it gets stuck
                        if (state.processingOrderTimeout) {
                            clearTimeout(state.processingOrderTimeout);
                        }
                        
                        state.processingOrderTimeout = setTimeout(() => {
                            if (state.currentlyProcessingOrder) {
                                console.log('⚠️ WARNING: Order processing timed out after 30 seconds');
                                state.currentlyProcessingOrder = false;
                                
                                // Try to navigate back to all available
                                try {
                                    navigateToAllAvailable();
                                } catch (e) {
                                    console.error('Error navigating after timeout:', e);
                                }
                            }
                        }, 30000); // 30 second timeout
                        
                        chrome.tabs.sendMessage(sender.tab.id, { action: 'processOrder' });
                    }
                    sendResponse({ success: true });
                } else {
                    console.error('Invalid sender information in onOrderPage message');
                    sendResponse({ success: false, error: 'Invalid sender' });
                }
                break;
                
            default:
                console.log('Unknown message action:', request.action);
                sendResponse({ success: false, message: 'Unknown action' });
        }
    } catch (error) {
        console.error('Error handling message:', error, 'Action:', request.action);
        sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep the message channel open for async response
});

// Listen for tab updates to detect page changes
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    // Only handle WritersHub tabs
    if (tab.url && tab.url.includes("writershub.org")) {
        console.log(`Tab updated: ${tabId}, Status: ${changeInfo.status}, URL: ${tab.url}`);

        // Check if this is the tab we're waiting for to finish loading for startBidding
        if (state.pendingTabIdForStartBidding === tabId && changeInfo.status === 'complete') {
            console.log(`Target tab ${tabId} finished loading at URL: ${tab.url}`);
            
            if (tab.url.includes('/writer/orders/all_available')) {
                console.log(`✅ Correct URL loaded in pending tab ${tabId}, sending startBidding message...`);
                
                // Add a small delay to ensure content script is ready
                setTimeout(() => {
                    try {
                        chrome.tabs.sendMessage(tabId, {
                            action: 'startBidding',
                            timestamp: Date.now(),
                            fromBackground: true
                        }, function(response) {
                            if (chrome.runtime.lastError) {
                                console.error(`Error sending startBidding message to completed tab ${tabId}:`, chrome.runtime.lastError);
                                // Try a reload as fallback
                                chrome.tabs.reload(tabId);
                            } else if (response && response.success) {
                                console.log(`✅ Tab ${tabId} successfully received startBidding message after load.`);
                            } else {
                                console.log(`Tab ${tabId} responded to startBidding without success.`);
                            }
                        });
                    } catch (error) {
                        console.error(`Exception sending startBidding message to completed tab ${tabId}:`, error);
                        // Try a reload as fallback
                        chrome.tabs.reload(tabId);
                    }
                }, 1000);
                
                // Clear the pending tab ID
                state.pendingTabIdForStartBidding = null;
            } else {
                console.log(`❌ Tab ${tabId} finished loading, but not on the expected URL. Not sending startBidding.`);
                // Clear the pending tab ID as it loaded the wrong page
                state.pendingTabIdForStartBidding = null;
            }
        }

        // Original logic for general page updates
        if (changeInfo.status === 'complete') {
            console.log('WritersHub page completed loading:', tab.url);
            
            // Check if this is an individual order page by URL pattern
            const isIndividualOrderPage = tab.url.match(/\/writer\/orders\/\d+/) && 
                                         !tab.url.includes('/all_available') && 
                                         !tab.url.includes('/top_offers');
            
            // If it's an individual order page and bot is running, send processOrder message
            if (isIndividualOrderPage && state.botRunning) {
                console.log('📋 Individual order page detected, sending processOrder message...');
                setTimeout(() => {
                    try {
                        chrome.tabs.sendMessage(tabId, { 
                            action: 'processOrder',
                            url: tab.url,
                            timestamp: Date.now()
                        }, response => {
                            if (chrome.runtime.lastError) {
                                console.error('Error sending processOrder message:', chrome.runtime.lastError);
                            } else {
                                console.log('processOrder message sent successfully, response:', response);
                            }
                        });
                    } catch (error) {
                        console.error('Exception sending processOrder message:', error);
                    }
                }, 1000); // Short delay to ensure page is loaded
            }
            
            // Always send pageLoadComplete message
            try {
                chrome.tabs.sendMessage(tabId, {
                    action: 'pageLoadComplete',
                    url: tab.url
                });
            } catch (error) {
                console.error('Error sending pageLoadComplete message:', error);
            }

            // If we're on the All Available Orders page and bot is running, ensure monitoring starts
            if (tab.url.includes("/writer/orders/all_available") && state.botRunning && state.pendingTabIdForStartBidding !== tabId) {
                // Add a small delay to avoid race conditions with startBidding
                setTimeout(() => {
                    console.log('On All Available page, ensuring monitoring is active...');
                    startMonitoring();
                }, 1500);
            }
        }
    }
});

// Handle when take button is found and clicked
function handleTakeButtonFound() {
    console.log('Take button was found and confirmation clicked');
    state.takeButtonFound = true;
    
    // Let the process complete, wait 4 seconds before stopping monitoring
    setTimeout(() => {
        stopTakeButtonMonitoring();
        
        // Navigate back to all available after 4 seconds
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs.length > 0) {
                console.log('Successfully took order, returning to All Available after delay');
                try {
                    chrome.tabs.sendMessage(tabs[0].id, { 
                        action: 'navigateToAllAvailable',
                        reason: 'takeSuccess'
                    });
                } catch (error) {
                    console.error('Error sending navigation message:', error);
                    // Fallback to direct navigation
                    forceNavigateToAllAvailable();
                }
            }
        });
    }, 4000);
}

// Function to stop take button monitoring specifically
function stopTakeButtonMonitoring() {
    // Only log and process if actually monitoring
    if (state.monitoringForTakeButton) {
        console.log('Stopping take button monitoring...');
        state.monitoringForTakeButton = false;
        state.awaitingTakeButtonOn = null;
        // Don't reset takeButtonFound here - we need to know it was found
        
        // Notify content script that background is no longer monitoring
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs.length > 0) {
                try {
                    chrome.tabs.sendMessage(tabs[0].id, { action: 'backgroundMonitoringStopped' });
                } catch (error) {
                    console.error('Error sending backgroundMonitoringStopped message:', error);
                }
            }
        });
    } else {
        console.log('Ignoring stopTakeButtonMonitoring - not currently monitoring');
    }
}

// SIMPLIFIED: Start the bot function that only navigates to All Available and starts monitoring
function startBot(createTab = false) {
    console.log('Starting bot with simplified functionality...');
    
    // Set bot as running
    state.botRunning = true;
    
    // Navigate to All Available Orders page
    navigateToAllAvailable(createTab);
    
    // Storage is updated to reflect bot is running
    chrome.storage.local.set({ botRunning: true }, function() {
        console.log('Bot status saved as running');
    });
}

// Stop the bot function
function stopBot() {
    console.log('Stopping bot...');
    
    // Update bot status
    state.botRunning = false;
    
    // Stop monitoring
    stopMonitoring();
    
    // Stop take button monitoring if active
    if (state.monitoringForTakeButton) {
        stopTakeButtonMonitoring();
    }
    
    // Clear processing state
    state.currentlyProcessingOrder = false;
    
    // Save bot status
    chrome.storage.local.set({ botRunning: false }, function() {
        console.log('Bot status saved as stopped');
    });
}

// Navigate to All Available Orders page
function navigateToAllAvailable(createTab = false) {
    console.log('Navigating to All Available Orders page...');
    
    // Prevent rapid navigation requests
    const now = Date.now();
    if (now - state.lastNavigationTime < state.navigationThrottleMs) {
        console.log('Navigation throttled - too soon after last navigation');
        return;
    }
    
    state.lastNavigationTime = now;
    state.redirecting = true;
    
    // Direct navigation to the all available URL
    const baseUrl = "https://www.writershub.org";
    const allAvailableUrl = "/writer/orders/all_available";
    const fullUrl = baseUrl + allAvailableUrl;
    
    // First check if any WritersHub tabs already exist
    chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(hubTabs) {
        if (hubTabs.length > 0 && !createTab) {
            // If WritersHub tab exists, update it
            console.log('Existing WritersHub tab found, navigating to All Available');
            try {
                chrome.tabs.update(hubTabs[0].id, { url: fullUrl, active: true }, function(tab) {
                    // Store the tab ID as pending for startBidding
                    state.pendingTabIdForStartBidding = tab.id;
                    
                    // Reset redirecting flag after navigation
                    setTimeout(function() {
                        state.redirecting = false;
                        
                        // Start monitoring when page loads
                        console.log('Setting up monitoring to start when page loads');
                    }, 2000);
                });
            } catch (error) {
                console.error('Exception during existing tab navigation:', error);
                state.redirecting = false;
            }
        } else {
            // No WritersHub tab exists, create a new one
            console.log('Creating new WritersHub tab for All Available');
            try {
                chrome.tabs.create({ url: fullUrl, active: true }, function(tab) {
                    // Store the tab ID as pending for startBidding
                    state.pendingTabIdForStartBidding = tab.id;
                    
                    // Reset redirecting flag after navigation
                    setTimeout(function() {
                        state.redirecting = false;
                        
                        // Start monitoring when page loads
                        console.log('Setting up monitoring to start when page loads');
                    }, 2000);
                });
            } catch (error) {
                console.error('Exception during new tab creation:', error);
                state.redirecting = false;
            }
        }
    });
}

// Forcefully navigate to All Available Orders (direct implementation, no checks)
function forceNavigateToAllAvailable() {
    console.log('FORCING navigation to All Available Orders page...');
    
    // Prevent rapid navigation requests
    const now = Date.now();
    if (now - state.lastNavigationTime < state.navigationThrottleMs) {
        console.log('Navigation throttled - too soon after last navigation');
        return;
    }
    
    state.lastNavigationTime = now;
    state.redirecting = true;
    
    // Direct navigation to the all available URL - ensure it's a full URL
    const baseUrl = "https://www.writershub.org";
    const allAvailableUrl = "/writer/orders/all_available";
    const fullUrl = baseUrl + allAvailableUrl;
    
    // First check if any WritersHub tabs already exist
    chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(hubTabs) {
        if (hubTabs.length > 0) {
            // If WritersHub tab exists, update it
            console.log('Existing WritersHub tab found, navigating to All Available');
            try {
                chrome.tabs.update(hubTabs[0].id, { url: fullUrl, active: true }, function(tab) {
                    if (chrome.runtime.lastError) {
                        console.error('Error navigating existing tab:', chrome.runtime.lastError);
                        state.redirecting = false;
                        return;
                    }
                    
                    console.log('Navigation to All Available Orders initiated in existing tab');
                    
                    // Reset redirecting flag and restart monitoring after navigation
                    setTimeout(function() {
                        state.redirecting = false;
                        
                        // After navigation, restart monitoring if bot is running
                        if (state.botRunning) {
                            startMonitoring();
                        }
                    }, 3000);
                });
            } catch (error) {
                console.error('Exception during existing tab navigation:', error);
                state.redirecting = false;
            }
        } else {
            // No WritersHub tab exists, create a new one
            console.log('No WritersHub tab found, creating new tab');
            try {
                chrome.tabs.create({ url: fullUrl, active: true }, function(tab) {
                    if (chrome.runtime.lastError) {
                        console.error('Error creating new tab:', chrome.runtime.lastError);
                        state.redirecting = false;
                        return;
                    }
                    
                    console.log('New WritersHub tab created and navigated to All Available Orders');
                    
                    // Reset redirecting flag and start monitoring after navigation
                    setTimeout(function() {
                        state.redirecting = false;
                        
                        // After navigation, start monitoring if bot is running
                        if (state.botRunning) {
                            startMonitoring();
                        }
                    }, 3000);
                });
            } catch (error) {
                console.error('Exception during new tab creation:', error);
                state.redirecting = false;
            }
        }
    });
}

// Function to perform take button check
function performTakeButtonCheck() {
    if (!state.monitoringForTakeButton || state.takeButtonFound) {
        console.log('Take button monitoring no longer active or button was found');
        return;
    }
    
    const elapsed = Date.now() - state.takeButtonCheckStartTime;
    
    // Check if we've exceeded the maximum wait time
    if (elapsed >= state.takeButtonMaxWaitMs) {
        console.log(`Take button monitoring timed out after ${state.takeButtonMaxWaitMs / 1000} seconds`);
        state.monitoringForTakeButton = false;
        
        // Navigate back to all available orders
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs.length > 0) {
                console.log('Timeout reached - navigating back to All Available');
                try {
                    chrome.tabs.sendMessage(tabs[0].id, { 
                        action: 'navigateToAllAvailable',
                        reason: 'timeout'
                    });
                } catch (error) {
                    console.error('Error sending timeout navigation message:', error);
                    // Fallback to direct navigation
                    forceNavigateToAllAvailable();
                }
            } else {
                // Fallback to direct navigation
                forceNavigateToAllAvailable();
            }
        });
        
        return;
    }
    
    // Check if it's time for a refresh - now using 0ms interval
    const now = Date.now();
    const timeSinceLastRefresh = now - (state.lastRefreshTimestamp || 0);
    
    // Use immediate refresh - only check that at least 10ms has passed for stability
    if (timeSinceLastRefresh >= 10) {
        // Update the last refresh timestamp
        state.lastRefreshTimestamp = now;
        
        // Find and refresh the active tab immediately
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs.length > 0) {
                refreshTab(tabs[0].id);
            }
        });
    }
}

// Helper function to refresh a tab
function refreshTab(tabId) {
    try {
        chrome.tabs.reload(tabId, {}, () => {
            if (chrome.runtime.lastError) {
                console.error('Error reloading tab:', chrome.runtime.lastError);
            } else {
                console.log('Page refreshed successfully');
                
                // Send a message to check for the take button after reload
                setTimeout(() => {
                    try {
                        chrome.tabs.sendMessage(tabId, { action: 'checkForTakeButton' });
                    } catch (checkError) {
                        console.error('Error sending checkForTakeButton message:', checkError);
                    }
                }, 1000); // Give the page a second to load after refresh
            }
        });
    } catch (reloadError) {
        console.error('Exception during tab reload:', reloadError);
    }
}

// Function to set up page refresh specifically for take button monitoring
function startTakeButtonRefresh(tabId, refreshInterval = 1000) {
    console.log(`Setting up take button refresh every ${refreshInterval/1000} seconds`);
    
    // Store the start time and max wait time
    state.takeButtonCheckStartTime = Date.now();
    state.refreshInterval = refreshInterval;
    
    // Get configured max wait time from storage, or use default
    chrome.storage.local.get(['waitForTakeButtonSeconds'], function(result) {
        if (result.waitForTakeButtonSeconds) {
            state.takeButtonMaxWaitMs = result.waitForTakeButtonSeconds * 1000;
            console.log(`Using configured wait time: ${result.waitForTakeButtonSeconds} seconds`);
        } else {
            state.takeButtonMaxWaitMs = 30000; // Default to 30 seconds
            console.log('Using default wait time: 30 seconds');
        }
        
        // Immediately refresh the tab to start monitoring
        console.log(`Immediately refreshing tab ${tabId} to start take button monitoring`);
        refreshTab(tabId);
        
        // Set up the refresh interval
        chrome.tabs.sendMessage(tabId, { action: "startTakeButtonRefresh", refreshInterval: refreshInterval }, function(response) {
            console.log('Tab response to startTakeButtonRefresh:', response);
        });
    });
}

// Start monitoring function
function startMonitoring() {
    console.log('Starting order monitoring...');
    state.monitoringActive = true;
    state.refreshCount = 0;
}

// Stop monitoring function
function stopMonitoring() {
    console.log('Stopping order monitoring...');
    state.monitoringActive = false;
}

// Perform refresh check function (placeholder)
function performRefreshCheck() {
    // This function would contain the logic to check for new orders
    // and is called by the alarm listener
    console.log('Performing refresh check...');
    state.refreshCount++;
}

// Function to handle when an order is found
function handleOrderFound(tabId) {
    console.log('Order found, processing...');
    state.currentlyProcessingOrder = true;
}

// Function to handle when order processing is complete
function handleOrderProcessingComplete(metCriteria, orderUrl, orderId, reasons) {
    console.log('Order processing complete:', { 
        metCriteria, 
        orderId: orderId || 'unknown', 
        reasons: reasons || 'none provided' 
    });
    
    // Clear processing state
    state.currentlyProcessingOrder = false;
    
    // Clear processing timeout if it exists
    if (state.processingOrderTimeout) {
        clearTimeout(state.processingOrderTimeout);
        state.processingOrderTimeout = null;
    }
    
    // Add to processed list if order didn't meet criteria
    if (!metCriteria && orderUrl) {
        state.processedOrderUrls.add(orderUrl);
        console.log(`Added ${orderUrl} to processed orders list`);
        
        // Add order ID to processed set if available
        if (orderId) {
            if (!state.processedOrderIds) state.processedOrderIds = new Set();
            state.processedOrderIds.add(orderId);
            console.log(`Added order ID ${orderId} to processed IDs set`);
        }
        
        // Only navigate back for orders that don't meet criteria
        setTimeout(() => {
            // Navigate back to All Available Orders
            console.log('Navigating back to All Available Orders after rejected order');
            navigateToAllAvailable();
        }, 500);
    }
    // If order meets criteria, let the content script handle the bidding flow
    // It will call navigateToAllAvailable when appropriate
}