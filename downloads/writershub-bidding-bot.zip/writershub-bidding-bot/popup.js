document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded - initializing popup UI');
    
    // Get DOM elements and verify they exist
    const activationScreen = document.getElementById('activationScreen');
    const mainScreen = document.getElementById('mainScreen');
    const trialScreen = document.getElementById('trialScreen');
    const timerSection = document.getElementById('timerSection');
    const countdown = document.getElementById('countdown');
    const startButton = document.getElementById('startBidding');
    const stopButton = document.getElementById('stopBidding');
    const statusDiv = document.getElementById('botStatus');
    const waitTimeInput = document.getElementById('waitForTakeButton');
    const refreshIntervalInput = document.getElementById('refreshInterval');
    
    // Trial and license buttons
    const startTrialButton = document.getElementById('startTrial');
    const enterLicenseButton = document.getElementById('enterLicense');
    const activateButton = document.getElementById('activateButton');
    
    // Debug log to see which elements are found
    console.log('UI Elements found:', {
        activationScreen: !!activationScreen,
        mainScreen: !!mainScreen,
        trialScreen: !!trialScreen,
        timerSection: !!timerSection,
        countdown: !!countdown,
        startButton: !!startButton,
        stopButton: !!stopButton,
        statusDiv: !!statusDiv,
        waitTimeInput: !!waitTimeInput,
        refreshIntervalInput: !!refreshIntervalInput,
        startTrialButton: !!startTrialButton,
        enterLicenseButton: !!enterLicenseButton,
        activateButton: !!activateButton
    });
    
    // Check if CRITICAL elements exist - don't check for optional ones
    if (!activationScreen || !mainScreen || !trialScreen || !timerSection) {
        console.error('Critical UI elements missing:',
            !activationScreen ? 'activationScreen missing' : '',
            !mainScreen ? 'mainScreen missing' : '',
            !trialScreen ? 'trialScreen missing' : '',
            !timerSection ? 'timerSection missing' : '');
    } else {
        console.log('All critical UI elements found in DOM');
    }

    // Add event listeners for the buttons
    if (startButton) {
        startButton.addEventListener('click', function() {
            console.log('Start Bidding button clicked');
            startBotFunction();
        });
    } else {
        console.error('Start Bidding button not found in DOM');
    }

    if (stopButton) {
        stopButton.addEventListener('click', function() {
            console.log('Stop Bidding button clicked');
            stopBotFunction();
        });
    } else {
        console.error('Stop Bidding button not found in DOM');
    }

    // Style the contact details sections
    function styleContactDetails() {
        const contactSections = document.querySelectorAll('.contact-details');
        contactSections.forEach(section => {
            section.style.cssText = `
                margin-top: 20px;
                padding: 10px;
                border-top: 1px solid #ccc;
                text-align: center;
                font-size: 14px;
                color: #333;
            `;
            const heading = section.querySelector('h4');
            if (heading) {
                heading.style.cssText = `
                    margin: 0 0 10px 0;
                    font-size: 16px;
                    color: #555;
                `;
            }
            const links = section.querySelectorAll('a');
            links.forEach(link => {
                link.style.cssText = `
                    color: #007bff;
                    text-decoration: none;
                `;
                link.addEventListener('mouseover', () => {
                    link.style.textDecoration = 'underline';
                });
                link.addEventListener('mouseout', () => {
                    link.style.textDecoration = 'none';
                });
            });
        });
    }

    function showMainScreen() {
        console.log('Showing main screen');
        document.getElementById('mainScreen').style.display = 'block';
        document.getElementById('activationScreen').style.display = 'none';
        document.getElementById('trialScreen').style.display = 'none';
        document.getElementById('timerSection').style.display = 'block';
        
        console.log('Main screen display state:', 
            document.getElementById('mainScreen').style.display,
            'Trial screen:', document.getElementById('trialScreen').style.display,
            'Activation screen:', document.getElementById('activationScreen').style.display);
            
        startCountdownTimer();
        
        // Load saved settings when showing main screen
        loadSettings();

        // Direct DOM manipulation to ensure visibility
        document.getElementById('mainScreen').style.display = 'block';
        document.getElementById('activationScreen').style.display = 'none';
        document.getElementById('trialScreen').style.display = 'none';
        document.getElementById('timerSection').style.display = 'block';
        
        // Force a reflow to ensure display changes take effect
        document.body.offsetHeight;
    }

    function showTrialScreen() {
        console.log('Showing trial screen');
        document.getElementById('mainScreen').style.display = 'none';
        document.getElementById('activationScreen').style.display = 'none';
        document.getElementById('trialScreen').style.display = 'block';
        document.getElementById('timerSection').style.display = 'none';
    }

    function showActivationScreen() {
        console.log('Showing activation screen (explicit call)');
        document.getElementById('mainScreen').style.display = 'none';
        document.getElementById('activationScreen').style.display = 'block';
        document.getElementById('trialScreen').style.display = 'none';
        document.getElementById('timerSection').style.display = 'none';
    }

    function showToast(message, type = 'info', actionButton = null) {
        console.log('Showing toast:', message, 'type:', type);
        const existingToast = document.getElementById('toast');
        if (existingToast) {
            existingToast.remove();
        }

        const toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'toast';
        
        // Create message element
        const messageEl = document.createElement('div');
        messageEl.textContent = message;
        toast.appendChild(messageEl);
        
        // Add action button if provided
        if (actionButton) {
            const button = document.createElement('button');
            button.textContent = actionButton.text;
            button.style.marginTop = '8px';
            button.style.padding = '6px 12px';
            button.style.fontSize = '12px';
            button.style.backgroundColor = 'white';
            button.style.color = '#333';
            button.style.border = 'none';
            button.style.borderRadius = '4px';
            button.style.cursor = 'pointer';
            button.onclick = actionButton.action;
            toast.appendChild(button);
        }
        
        // Set background color based on type
        if (type === 'error') {
            toast.style.backgroundColor = 'var(--danger-color)';
        } else if (type === 'success') {
            toast.style.backgroundColor = 'var(--secondary-color)';
        } else {
            toast.style.backgroundColor = 'var(--primary-color)';
        }
        
        // Ensure toast is visible with explicit styling
        toast.style.opacity = '1';
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.padding = '12px 24px';
        toast.style.borderRadius = '8px';
        toast.style.color = 'white';
        toast.style.fontWeight = '500';
        toast.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
        toast.style.zIndex = '1000';
        toast.style.display = 'flex';
        toast.style.flexDirection = 'column';
        toast.style.alignItems = 'center';
        toast.style.textAlign = 'center';

        document.body.appendChild(toast);
        
        toast.offsetHeight; // Force reflow

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s ease-out';
            setTimeout(() => toast.remove(), 5000); // Extended display time for action buttons
        }, 5000);
    }

    function updateBotStatus(isRunning) {
        const botStatusElement = document.getElementById('botStatus');
        if (isRunning) {
            botStatusElement.textContent = 'Bot: Running';
            botStatusElement.classList.add('status-running');
            botStatusElement.classList.remove('status-stopped');
        } else {
            botStatusElement.textContent = 'Bot: Stopped';
            botStatusElement.classList.add('status-stopped');
            botStatusElement.classList.remove('status-running');
        }
    }

    function startCountdownTimer() {
        function updateTimer() {
            chrome.storage.local.get(['trialActivated', 'trialStartTime', 'trialDuration', 'trialExpired', 'activated', 'licenseExpiration'], (data) => {
                const now = Date.now();
                let timeLeft, label;
                
                if (data.trialActivated && !data.trialExpired && data.trialStartTime) {
                    timeLeft = (data.trialStartTime + data.trialDuration) - now;
                    label = 'Trial Time Remaining';
                } else if (data.activated && data.licenseExpiration) {
                    timeLeft = new Date(data.licenseExpiration) - new Date();
                    label = 'License Time Remaining';
                } else {
                    document.getElementById('timerDisplay').textContent = 'Time Expired';
                    if (countdown) countdown.textContent = '00:00:00';
                    
                    // Stop the bot and clear all states when time expires
                    chrome.storage.local.set({ 
                        trialExpired: true, 
                        trialActivated: false, 
                        activated: false,
                        botRunning: false 
                    }, () => {
                        // Stop the bot
                        chrome.runtime.sendMessage({ action: 'stopBot' }, function() {
                            // Find and close all WritersHub tabs
                            chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(tabs) {
                                if (tabs.length > 0) {
                                    tabs.forEach(tab => {
                                        // Clear console logs
                                        chrome.scripting.executeScript({
                                            target: { tabId: tab.id },
                                            function: () => { console.clear(); }
                                        });
                                        // Close the tab
                                        chrome.tabs.remove(tab.id);
                                    });
                                }
                            });
                            
                            // Update UI
                            updateBotStatus(false);
                            showActivationScreen();
                            showToast('Trial period has expired. Bot has been stopped.', 'error');
                        });
                    });
                    return;
                }

                if (timeLeft > 0) {
                    const hours = Math.floor(timeLeft / (1000 * 60 * 60));
                    const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                    const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
                    
                    // Format with leading zeros
                    const formattedHours = String(hours).padStart(2, '0');
                    const formattedMinutes = String(minutes).padStart(2, '0');
                    const formattedSeconds = String(seconds).padStart(2, '0');
                    
                    document.getElementById('timerDisplay').textContent = label;
                    if (countdown) countdown.textContent = `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
                } else {
                    document.getElementById('timerDisplay').textContent = 'Time Expired';
                    if (countdown) countdown.textContent = '00:00:00';
                    
                    // Stop the bot and clear all states when time expires
                    chrome.storage.local.set({ 
                        trialExpired: true, 
                        trialActivated: false, 
                        activated: false,
                        botRunning: false 
                    }, () => {
                        // Stop the bot
                        chrome.runtime.sendMessage({ action: 'stopBot' }, function() {
                            // Find and close all WritersHub tabs
                            chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(tabs) {
                                if (tabs.length > 0) {
                                    tabs.forEach(tab => {
                                        // Clear console logs
                                        chrome.scripting.executeScript({
                                            target: { tabId: tab.id },
                                            function: () => { console.clear(); }
                                        });
                                        // Close the tab
                                        chrome.tabs.remove(tab.id);
                                    });
                                }
                            });
                            
                            // Update UI
                            updateBotStatus(false);
                            showActivationScreen();
                            showToast('Trial period has expired. Bot has been stopped.', 'error');
                        });
                    });
                }
            });
        }
        updateTimer();
        setInterval(updateTimer, 1000);
    }

    function startTrialCountdown() {
        startCountdownTimer();
    }

    // Function to validate license key format
    function isValidLicenseKey(key) {
        // Format: WH- followed by 8 characters where:
        // - First 2 characters are uppercase letters (A-Z)
        // - Third character is a digit (0-9)
        // - Fourth character is an uppercase letter (A-Z)
        // - Fifth character is a digit (0-9)
        // - Sixth character is an uppercase letter (A-Z)
        // - Seventh character is a digit (0-9)
        // - Eighth character is an uppercase letter (A-Z)
        const licenseRegex = /^WH-[A-Z]{2}\d[A-Z]\d[A-Z]\d[A-Z]$/;
        return licenseRegex.test(key);
    }

    // Function to activate trial
    function activateTrial() {
        console.log('activateTrial function called!');
        
        // Set trial data (5 hours = 5 * 60 * 60 * 1000 ms)
        const trialData = {
            trialActivated: true,
            trialExpired: false,
            trialStartTime: Date.now(),
            trialDuration: 5 * 60 * 60 * 1000, // 5 hours in milliseconds
            initialInstall: false,
            freeTrialActive: true  // Add this flag for content.js to check
        };
        
        chrome.storage.local.set(trialData, function() {
            console.log('Trial data saved:', trialData);
            
            // Notify background script about trial activation
            chrome.runtime.sendMessage({ action: 'trialActivatedFromPopup' });
            
            // Show main screen and start countdown
            showMainScreen();
            startTrialCountdown();
            loadSettings();
            styleContactDetails();
            
            // Show success message
            showToast('5-hour trial activated successfully!', 'success');
        });
    }

    // Direct script loading - define the global functions immediately
    window.activateTrial = activateTrial;
    window.showActivationScreen = showActivationScreen;
    window.activateLicense = function() {
        console.log('activateLicense function called!');
        const licenseKey = document.getElementById('activationKey').value.trim();
        
        if (!licenseKey) {
            showToast('Please enter a valid license key', 'error');
            return;
        }
        
        // Validate license key format
        if (!isValidLicenseKey(licenseKey)) {
            showToast('Invalid license key format. Please enter a valid key.', 'error');
            return;
        }
        
        console.log('Attempting to activate license with key:', licenseKey);
        
        // For demo purposes, accept any valid format key and set an expiration 30 days from now
        const expirationDate = new Date();
        expirationDate.setDate(expirationDate.getDate() + 30);
        
        const licenseData = {
            activated: true,
            activationKey: licenseKey,
            licenseExpiration: expirationDate.toISOString(),
            trialActivated: false,
            trialExpired: true,
            initialInstall: false,
            freeTrialActive: false  // Ensure free trial flag is set to false when license is activated
        };
        
        chrome.storage.local.set(licenseData, function() {
            console.log('License data saved:', licenseData);
            showMainScreen();
            loadSettings();
            styleContactDetails();
            showToast('License activated successfully!', 'success');
        });
    };
    
    // Add event listeners for trial and license buttons - direct approach
    if (startTrialButton) {
        console.log('Setting up Start Trial button');
        startTrialButton.onclick = function(e) {
            e.preventDefault();
            console.log('Start Trial button clicked!');
            activateTrial();
            return false;
        };
    }
    
    if (enterLicenseButton) {
        console.log('Setting up Enter License button');
        enterLicenseButton.onclick = function(e) {
            e.preventDefault();
            console.log('Enter License button clicked!');
            showActivationScreen();
            return false;
        };
    }
    
    if (activateButton) {
        console.log('Setting up Activate License button');
        activateButton.onclick = function(e) {
            e.preventDefault();
            console.log('Activate License button clicked!');
            window.activateLicense();
            return false;
        };
    }

    function loadSettings() {
        console.log('Loading saved settings...');
        chrome.storage.local.get([
            'activated',
            'licenseExpiration',
            'activationKey',
            'recaptchaWaitTime',
            'waitForTakeButton',
            'refreshInterval',
            'botRunning',
            'minDeadlineHours',
            'maxSources',
            'maxPagesWords',
            'maxFiles',
            'excludedAssignmentTypes',
            'excludedSubjects',
            'allowedServices',
            'pageLimit',
            'condition'
        ], function(data) {
            console.log('Retrieved settings from storage:', data);
            
            // Apply settings to UI elements if they exist
            const elements = {
                recaptchaWaitTime: document.getElementById('recaptchaWaitTime'),
                waitForTakeButton: document.getElementById('waitForTakeButton'),
                refreshInterval: document.getElementById('refreshInterval'),
                minDeadlineHours: document.getElementById('minDeadlineHours'),
                maxSources: document.getElementById('maxSources'),
                maxPagesWords: document.getElementById('maxPagesWords'),
                maxFiles: document.getElementById('maxFiles'),
                serviceAcademic: document.getElementById('serviceAcademic'),
                serviceEditing: document.getElementById('serviceEditing')
            };
            
            // Set default values for any missing settings
            const defaultSettings = {
                recaptchaWaitTime: 25,
                waitForTakeButton: 30,
                refreshInterval: 3,
                minDeadlineHours: 3,
                maxSources: 30,
                maxPagesWords: 15,
                maxFiles: 20,
                allowedServices: ['Academic paper writing'],
                excludedAssignmentTypes: [],
                excludedSubjects: [],
                pageLimit: 100,
                condition: 'below'
            };
            
            // Apply values to form elements using a loop
            for (const [key, element] of Object.entries(elements)) {
                if (element) {
                    if (element.type === 'checkbox') {
                        // Handle checkboxes differently
                        if (key === 'serviceAcademic') {
                            const allowedServices = data.allowedServices || defaultSettings.allowedServices;
                            element.checked = allowedServices.includes('Academic paper writing');
                        } else if (key === 'serviceEditing') {
                            const allowedServices = data.allowedServices || defaultSettings.allowedServices;
                            element.checked = allowedServices.includes('Editing');
                        }
                    } else {
                        // For input fields - use the value from storage or default
                        element.value = data[key] !== undefined ? data[key] : defaultSettings[key];
                    }
                    console.log(`Applied setting ${key} to UI:`, element.type === 'checkbox' ? element.checked : element.value);
                }
            }
            
            // Set assignment type checkboxes
            const assignmentTypes = data.excludedAssignmentTypes || [];
            document.querySelectorAll('#assignmentTypesContainer input[type=checkbox]').forEach(checkbox => {
                checkbox.checked = assignmentTypes.includes(checkbox.value);
            });
            
            // Set subject checkboxes
            const subjects = data.excludedSubjects || [];
            document.querySelectorAll('#subjectsContainer input[type=checkbox]').forEach(checkbox => {
                checkbox.checked = subjects.includes(checkbox.value);
            });
            
            // Update bot status display
            updateBotStatus(data.botRunning || false);
            console.log('Settings loaded and applied to UI');
        });
    }
    
    // Call loadSettings when popup opens to restore previous settings
    loadSettings();

    chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
        if (chrome.runtime.lastError) {
            console.error('Background script not responding:', chrome.runtime.lastError);
            showToast('Error: Background script is not responding. Please reload the extension.', 'error');
        } else {
            console.log('Background script is active:', response);
        }
    });

    chrome.storage.local.get([
        'activated',
        'licenseExpiration',
        'activationKey',
        'trialActivated',
        'trialExpired',
        'trialStartTime',
        'trialDuration',
        'initialInstall',
        'freeTrialActive'
    ], function(data) {
        console.log('Retrieved data on popup load:', data);

        // If this is the very first install, show trial screen
        if (data.initialInstall === true) {
            console.log('New install detected, showing trial screen');
            showTrialScreen();
            return;
        }
        
        // Check initialInstall undefined (happens sometimes on fresh installs)
        if (data.initialInstall === undefined) {
            console.log('initialInstall is undefined, assuming new install');
            chrome.storage.local.set({ initialInstall: true }, () => {
                console.log('initialInstall flag set to true');
                showTrialScreen();
            });
            return;
        }

        // If we have an active trial, show main screen
        if (data.trialActivated && !data.trialExpired && data.trialStartTime) {
            const timeLeft = (data.trialStartTime + data.trialDuration) - Date.now();
            if (timeLeft > 0) {
                console.log('Valid trial found, showing main screen');
                
                // Ensure freeTrialActive flag is set for existing trials
                if (data.freeTrialActive === undefined) {
                    console.log('Setting freeTrialActive flag for existing trial');
                    chrome.storage.local.set({ freeTrialActive: true });
                }
                
                showMainScreen();
                startTrialCountdown();
                styleContactDetails();
                return;
            } else {
                console.log('Trial has expired, showing activation screen');
                chrome.storage.local.set({ trialExpired: true, activated: false, freeTrialActive: false });
                showActivationScreen();
                styleContactDetails();
                return;
            }
        }

        // If we have a valid license, show main screen
        if (data.activated && data.licenseExpiration && data.activationKey) {
            const expiryDate = new Date(data.licenseExpiration);
            const now = new Date();
            if (expiryDate > now) {
                console.log('Valid license found, showing main screen');
                showMainScreen();
                startCountdownTimer();
                styleContactDetails();
                return;
            } else {
                console.log('License expired, clearing state');
                chrome.storage.local.set({
                    activated: false,
                    licenseExpiration: null,
                    activationKey: null
                });
                showActivationScreen();
                styleContactDetails();
                return;
            }
        }

        // If neither trial nor license is active, show activation screen
        console.log('No valid license or trial, showing activation screen');
        showActivationScreen();
        styleContactDetails();
    });

    // Save settings
    function saveSettingsFunction(showToastMessage = true) {
        const settings = {};
        
        // Get all numeric input values
        const elements = {
            recaptchaWaitTime: document.getElementById('recaptchaWaitTime'),
            waitForTakeButton: document.getElementById('waitForTakeButton'),
            refreshInterval: document.getElementById('refreshInterval'),
            minDeadlineHours: document.getElementById('minDeadlineHours'),
            maxSources: document.getElementById('maxSources'),
            maxPagesWords: document.getElementById('maxPagesWords'),
            maxFiles: document.getElementById('maxFiles')
        };
        
        // Save all numeric settings
        for (const [key, element] of Object.entries(elements)) {
            if (element) {
                // IMPORTANT: Ensure waitForTakeButton has a proper value to prevent exceeding limits
                if (key === 'waitForTakeButton') {
                    const value = parseInt(element.value);
                    // Set a reasonable default/fallback and constrain within safe limits
                    if (isNaN(value) || value <= 0) {
                        settings[key] = 30; // Default to 30 seconds
                    } else {
                        // Cap at 300 seconds (5 minutes) to prevent extremely long monitoring sessions
                        settings[key] = Math.min(value, 300);
                    }
                    console.log(`Set waitForTakeButton to ${settings[key]} seconds (user input: ${element.value})`);
                } else {
                    // Handle other numeric inputs
                    const value = parseInt(element.value);
                    settings[key] = isNaN(value) ? getDefaultValue(key) : value;
                }
                console.log(`Saving setting ${key} = ${settings[key]}`);
            }
        }
        
        // Get allowed services
        const allowedServices = [];
        const serviceAcademic = document.getElementById('serviceAcademic');
        const serviceEditing = document.getElementById('serviceEditing');
        
        if (serviceAcademic && serviceAcademic.checked) {
            allowedServices.push('Academic paper writing');
        }
        if (serviceEditing && serviceEditing.checked) {
            allowedServices.push('Editing');
        }
        
        settings.allowedServices = allowedServices;
        
        // Get excluded assignment types
        const excludedAssignmentTypes = [];
        document.querySelectorAll('#assignmentTypesContainer input[type=checkbox]:checked').forEach(checkbox => {
            excludedAssignmentTypes.push(checkbox.value);
        });
        settings.excludedAssignmentTypes = excludedAssignmentTypes;
        
        // Get excluded subjects
        const excludedSubjects = [];
        document.querySelectorAll('#subjectsContainer input[type=checkbox]:checked').forEach(checkbox => {
            excludedSubjects.push(checkbox.value);
        });
        settings.excludedSubjects = excludedSubjects;
        
        // Add default values for pageLimit and condition if not already set
        // These might not have direct UI controls but are used by the bot
        chrome.storage.local.get(['pageLimit', 'condition'], function(data) {
            settings.pageLimit = data.pageLimit || 100;
            settings.condition = data.condition || 'below';
            
            console.log('Saving complete settings to storage:', settings);
            
            // Save to storage
            chrome.storage.local.set(settings, function() {
                console.log('Settings saved to local storage');
                if (showToastMessage) {
                    showToast('Settings saved successfully', 'success');
                }
            });
            
            // Also save to sync storage for backup
            chrome.storage.sync.set(settings, function() {
                console.log('Settings saved to sync storage');
            });
        });
        
        return settings;
    }
    
    // Helper function to get default values for settings
    function getDefaultValue(key) {
        const defaults = {
            recaptchaWaitTime: 25,
            waitForTakeButton: 30,
            refreshInterval: 3,
            minDeadlineHours: 3,
            maxSources: 30,
            maxPagesWords: 15,
            maxFiles: 20
        };
        return defaults[key] || 0;
    }

    // Update UI based on bot status
    function updateBotStatus(running) {
        console.log('Updating bot status UI to:', running ? 'running' : 'stopped');
        
        // Update status text and button states if the elements exist
        if (statusDiv) {
            statusDiv.textContent = running ? 'Bot: Running' : 'Bot: Stopped';
            statusDiv.classList.toggle('status-running', running);
            statusDiv.classList.toggle('status-stopped', !running);
        }
        
        if (startButton) {
            startButton.disabled = running;
        }
        
        if (stopButton) {
            stopButton.disabled = !running;
        }
    }
    
    // Start bot function should also include all settings
    function startBotFunction() {
        console.log('Starting bot - setting bot running and opening WritersHub...');
        showToast('Starting bot...', 'info'); // Show initial toast

        // Prevent multiple executions
        if (window.botStartInProgress) {
            console.log('Bot start already in progress, ignoring duplicate click');
            return;
        }
        window.botStartInProgress = true;
        
        // Clear flag after 5 seconds (safety timeout)
        setTimeout(() => { window.botStartInProgress = false; }, 5000);

        try {
            // Save settings first, but don't show toast
            saveSettingsFunction(false);

            // IMPORTANT: Set bot to running state BEFORE creating tab
            chrome.storage.local.set({ botRunning: true }, function() {
                console.log('Bot running state set to TRUE in chrome.storage');

                // Update UI immediately
                updateBotStatus(true);
                
                // Check if there's already a WritersHub tab open
                chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(tabs) {
                    if (tabs.length > 0) {
                        console.log('WritersHub tab already exists, updating and activating it:', tabs[0].id);
                        
                        // Use clean URL without parameters as requested
                        const cleanUrl = "https://www.writershub.org/writer/orders/all_available";
                        
                        // If tab exists, update it to all_available page with clean URL
                        chrome.tabs.update(tabs[0].id, { 
                            url: cleanUrl,
                            active: true 
                        }, function(tab) {
                            console.log('Existing tab updated:', tab ? tab.id : 'unknown');
                            showToast('Bot started! Using existing tab.', 'success');
                            window.botStartInProgress = false;
                        });
                        
                        return;
                    }
                    
                    // No tab exists, create a new one
                    console.log('No WritersHub tab exists, creating new one');
                    
                    // Use clean URL without parameters as requested
                    const cleanUrl = "https://www.writershub.org/writer/orders/all_available";
                    
                    chrome.tabs.create({ url: cleanUrl, active: true }, function(tab) {
                        if (chrome.runtime.lastError) {
                            console.error('Error creating tab:', chrome.runtime.lastError);
                            showToast('Error opening website: ' + chrome.runtime.lastError.message, 'error');
                            window.botStartInProgress = false;
                        } else {
                            console.log('Tab created:', tab.id);
                            showToast('Bot started! Website opened in new tab.', 'success');
                            
                            // Notify background script
                            chrome.runtime.sendMessage({ 
                                action: 'startBot',
                                tabId: tab.id,
                                timestamp: Date.now()
                            });
                            
                            window.botStartInProgress = false;
                        }
                    });
                });
            });
        } catch (err) {
            console.error('CRITICAL ERROR in startBotFunction:', err);
            showToast('Critical error starting bot: ' + err.message, 'error');
            window.botStartInProgress = false;
            
            // Emergency direct approach if everything else fails
            try {
                window.open("https://www.writershub.org/writer/orders/all_available", "_blank");
                chrome.storage.local.set({ botRunning: true });
                updateBotStatus(true);
            } catch (e) {
                console.error('Even emergency tab creation failed:', e);
                alert("Please click the OPEN WRITERSHUB SITE button to continue");
            }
        }
    }
    
    // Stop bot
    function stopBotFunction() {
        console.log('Stopping bot...');
        
        // Set bot state to stopped
        chrome.storage.local.set({ botRunning: false }, function() {
            // Update UI
            updateBotStatus(false);
            showToast('Bot stopped', 'info');
            
            // Send message to background script to stop the bot
            chrome.runtime.sendMessage({ action: 'stopBot' }, function(response) {
                console.log('Background script response to stopBot:', response);
                
                // Find all writershub.org tabs
                chrome.tabs.query({ url: "*://*.writershub.org/*" }, function(tabs) {
                    if (tabs.length > 0) {
                        // For each tab
                        tabs.forEach(tab => {
                            // First clear the console using the scripting API (Manifest V3)
                            chrome.scripting.executeScript({
                                target: { tabId: tab.id },
                                function: () => { console.clear(); }
                            }, function() {
                                // Then close the tab
                                chrome.tabs.remove(tab.id, function() {
                                    console.log('WritersHub tab closed');
                                });
                            });
                        });
                    } else {
                        console.log('No WritersHub tabs found to close');
                    }
                });
            });
        });
    }
    
    // Function to clear all processed orders
    function clearProcessedOrdersFunction() {
        console.log('Clearing all processed orders...');
        
        // Show confirmation message
        showToast('Clearing rejected orders...', 'info');
        
        // Get current counts to show success message
        chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
            const urlCount = data.processedOrderUrls ? data.processedOrderUrls.length : 0;
            const idCount = data.processedOrderIds ? data.processedOrderIds.length : 0;
            
            // Send message to background script to clear the orders
            chrome.runtime.sendMessage({ action: 'clearProcessedOrders' }, function(response) {
                console.log('Content script response to clearProcessedOrders:', response);
                showToast(`Cleared ${urlCount} rejected orders`, 'success');
            });
            
            // Also clear local storage values
            chrome.storage.local.set({
                processedOrderUrls: [],
                processedOrderIds: []
            }, function() {
                console.log('Local storage cleared of processed orders');
            });
        });
    }
    
    // Register global functions
    window.startBidding = startBotFunction;
    window.stopBidding = stopBotFunction;
    window.saveSettings = saveSettingsFunction;
    window.clearProcessedOrders = clearProcessedOrdersFunction;
    
    // Setup button click handlers with direct assignments
    if (startButton) {
        console.log('Setting up Start Bidding button');
        startButton.onclick = function(e) {
            e.preventDefault();
            console.log('Start Bidding button clicked!');
            startBotFunction();
            return false;
        };
    }
    
    if (stopButton) {
        console.log('Setting up Stop Bidding button');
        stopButton.onclick = function(e) {
            e.preventDefault();
            console.log('Stop Bidding button clicked!');
            stopBotFunction();
            return false;
        };
    }
    
    const saveSettingsButton = document.getElementById('saveSettings');
    if (saveSettingsButton) {
        console.log('Setting up Save Settings button');
        saveSettingsButton.onclick = function(e) {
            e.preventDefault();
            console.log('Save Settings button clicked!');
            saveSettingsFunction(true);
            return false;
        };
    }
    
    const clearProcessedButton = document.getElementById('clearProcessed');
    if (clearProcessedButton) {
        console.log('Setting up Clear Rejected Orders button');
        clearProcessedButton.onclick = function(e) {
            e.preventDefault();
            console.log('Clear Rejected Orders button clicked!');
            clearProcessedOrdersFunction();
            return false;
        };
    }

    // Listen for status updates from background script
    chrome.runtime.onMessage.addListener(function(request, _sender, sendResponse) {
        if (request.action === 'updateStatus') {
            updateBotStatus(request.running);
        }
    });

    const ASSIGNMENT_TYPES = [
        'Presentation', 'Dissertation', 'Thesis', 'Lab Report', 'Math Problem', 'Excel spreadsheet', 
        'Research Paper', 'Case Study', 'Programming Assignment', 'Technical Report', 'Data Analysis',
        'Database Design', 'System Design', 'Algorithm Implementation', 'Code Review', 'API Documentation',
        'Software Testing', 'UML Diagrams', 'Network Design', 'Security Analysis', 'Cloud Architecture'

    ];

    const SUBJECTS = [
        'Accounting', 'Mathematics', 'Physics', 'Chemistry', 'Statistics', 'Law',
        'Biology', 'Psychology', 'Sociology', 'Business', 'Economics',
        'Political Science', 'Philosophy', 'Literature', 'Computer Science',
        'Nursing', 'Engineering', 'Finance', 'Data Science', 'Information Technology',
        'Cybersecurity', 'Software Engineering', 'Database Management', 'Artificial Intelligence',
        'Machine Learning', 'Network Engineering', 'Cloud Computing', 'Web Development',
        'Mobile Development', 'Systems Architecture', 'DevOps', 'Robotics'
    ];

    function populateCheckboxes() {
        const assignmentContainer = document.getElementById('assignmentTypesContainer');
        const subjectsContainer = document.getElementById('subjectsContainer');

        ASSIGNMENT_TYPES.forEach(type => {
            const id = `assignment_${type.replace(/\s+/g, '_')}`;
            assignmentContainer.innerHTML += `
                <div class="checkbox-item">
                    <input type="checkbox" id="${id}" value="${type}">
                    <label for="${id}">${type}</label>
                </div>
            `;
        });

        SUBJECTS.forEach(subject => {
            const id = `subject_${subject.replace(/\s+/g, '_')}`;
            subjectsContainer.innerHTML += `
                <div class="checkbox-item">
                    <input type="checkbox" id="${id}" value="${subject}">
                    <label for="${id}">${subject}</label>
                </div>
            `;
        });
    }

    populateCheckboxes();

    // Add direct website opener function for emergency button 
    // Add direct website opener function
    function openWritersHubSite() {
        const url = "https://www.writershub.org/writer/orders/all_available";
        console.log("Attempting to directly open WritersHub without starting bot...");
        
        chrome.tabs.create({ url: url, active: true }, function(tab) {
            if (chrome.runtime.lastError) {
                console.error("Error creating tab:", chrome.runtime.lastError);
            } else {
                console.log("Successfully opened WritersHub site in tab:", tab.id);
                // DO NOT set bot running state here - this is just for opening the site
            }
        });
    }

    // Add direct open button to the DOM
    document.addEventListener('DOMContentLoaded', function() {
        // Add a special emergency button at the top of the page
        const container = document.querySelector('.button-group');
        
        if (container) {
            const emergencyButton = document.createElement('button');
            emergencyButton.textContent = 'OPEN WRITERSHUB SITE';
            emergencyButton.style.backgroundColor = '#ff6b6b';
            emergencyButton.style.color = 'white';
            emergencyButton.style.fontWeight = 'bold';
            emergencyButton.style.padding = '10px 15px';
            emergencyButton.onclick = function(e) {
                e.preventDefault();
                openWritersHubSite();
                return false;
            };
            
            // Insert as first child
            if (container.firstChild) {
                container.insertBefore(emergencyButton, container.firstChild);
            } else {
                container.appendChild(emergencyButton);
            }
        }
        
        // Check URL parameters to see if autoopen is needed
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('autoopen') === 'true') {
            console.log('Autoopen parameter detected, opening WritersHub automatically');
            openWritersHubSite();
        }
    });

    // CRITICAL FIX: Add an extra check at the very end of the file to ensure all needed listeners
    // are properly registered. This is in case the DOM is already loaded when our script runs.
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        console.log('Document already loaded, manually checking for Start Bidding button');
        
        // Recheck Start Bidding button
        const startButton = document.getElementById('startBidding');
        if (startButton) {
            console.log('Found Start Bidding button, ensuring click handler is attached');
            startButton.onclick = function(e) {
                if (e) e.preventDefault();
                console.log('Start Bidding button clicked (from manual handler)');
                
                // Run the normal start function
                startBotFunction();
                
                return false;
            };
        }
    }
});
