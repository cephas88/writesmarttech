// Function to stop all bot activities
function stopAllBotActivities() {
    console.log('Stopping all bot activities...');
    
    // Stop order monitoring if running
    if (typeof stopOrderMonitoring === 'function') {
        stopOrderMonitoring();
    }
    
    // Clear any watchdog timers
    if (typeof stopWatchdog === 'function') {
        stopWatchdog();
    }
    
    // Set bot status to not running
    chrome.storage.local.set({ botRunning: false }, function() {
        console.log('Bot status set to NOT running');
    });
    
    // Close any UI indicators that might be open
    const indicators = document.querySelectorAll('#evaluationIndicator, #resultIndicator, #navigationIndicator, #monitoringIndicator');
    indicators.forEach(indicator => {
        if (indicator) indicator.remove();
    });
    
    // Reset any state variables
    refreshCount = 0;
    
    console.log('All bot activities stopped successfully');
}

// reCAPTCHA verification handled by recaptchaVerifier.js

// Function to check license status and stop bot if license/trial has expired
function checkLicenseStatus() {
    chrome.storage.local.get([
        'activated', 
        'licenseExpiration', 
        'trialActivated', 
        'trialExpired', 
        'trialStartTime', 
        'trialDuration'
    ], function(data) {
        const now = Date.now();
        let isValid = false;
        
        // Check if we have a valid license
        if (data.activated && data.licenseExpiration) {
            const expiryDate = new Date(data.licenseExpiration);
            const currentDate = new Date();
            if (expiryDate > currentDate) {
                isValid = true;
            }
        }
        
        // Check if we have a valid trial
        if (data.trialActivated && !data.trialExpired && data.trialStartTime) {
            const timeLeft = (data.trialStartTime + data.trialDuration) - now;
            if (timeLeft > 0) {
                isValid = true;
            }
        }
        
        // If license/trial is not valid but bot is running, stop it
        if (!isValid) {
            chrome.storage.local.get(['botRunning'], function(runData) {
                if (runData.botRunning) {
                    console.log('License/Trial expired but bot is still running - stopping bot automatically');
                    
                    // First attempt to click the Stop Bidding button in the UI
                    chrome.runtime.sendMessage({ action: 'stopBot' });
                    
                    // Then stop all bot activities
                    stopAllBotActivities();
                }
            });
        }
    });
}

// Add order monitoring variables and constants
let orderMonitoringInterval = null;
let orderRefreshCount = 0;
const ORDER_REFRESH_INTERVAL = 4000; // 4 seconds between refreshes for order monitoring
const MAX_ORDER_REFRESH_COUNT = 100; // Maximum number of refreshes before reset

// Function to start the order monitoring process
function startOrderMonitoring() {
    console.log('Starting order monitoring with MutationObserver...');
    
    // Clear any existing monitoring intervals
        stopOrderMonitoring();
        
    // Initialize or reset refresh count
    orderRefreshCount = parseInt(sessionStorage.getItem('orderRefreshCount') || '0');
    
    // Update last refresh time
        sessionStorage.setItem('lastOrderRefreshTime', Date.now().toString());
        
    // Start watchdog timer to prevent getting stuck
    startWatchdog(180000, 'order monitoring');
    
    // Set monitoring flag
    sessionStorage.setItem('orderMonitoringActive', 'true');
    
    // IMMEDIATE ACTION: Try to find and click an order right away without waiting
    console.log('🔍 IMMEDIATE ACTION: Looking for available orders right now...');
    
    // First try direct DOM-based click methods - these are fastest
    let orderFound = false;
    
    // Promise chain to try multiple methods sequentially with minimal delay
    Promise.resolve()
        .then(() => {
            // First try clicking exact order row structure
            console.log('🎯 Immediate attempt: Trying exact order row click...');
            return clickExactOrderRow()
                .then(result => {
                    if (result) {
                        console.log('✅ Exact order row click succeeded!');
                        orderFound = true;
                    }
                    return orderFound;
                });
        })
        .then(found => {
            if (found) return true;
            
            // If first method failed, try direct DOM structure click
            console.log('🎯 Immediate attempt: Trying DOM structure click...');
            return clickOrderRowByDom()
                .then(result => {
                    if (result) {
                        console.log('✅ DOM structure click succeeded!');
                        orderFound = true;
                    }
                    return orderFound;
                });
        })
        .then(found => {
            if (found) return true;
            
            // If still no order found, try direct DOM inspection
            console.log('🎯 Immediate attempt: Trying direct DOM inspection...');
            return findAndProcessOrderByDirectDOMInspection()
                .then(result => {
                    if (result) {
                        console.log('✅ Direct DOM inspection succeeded!');
                        orderFound = true;
                    }
                    return orderFound;
                });
        })
        .then(found => {
            if (found) {
                console.log('✅ Successfully found and opened an order immediately!');
            } else {
                console.log('No orders found immediately, setting up continuous monitoring...');
                // Find the orders table container to observe
                findOrderContainer().then(container => {
                    if (container) {
                        startMonitoringWithContainer(container);
                    } else {
                        console.log('Could not find order container, using fallback monitoring');
                        setupRefreshMonitoring();
                    }
                });
            }
    });
}

// Function to continue the refresh cycle after a page reload
function continueOrderMonitoring() {
    // Check if monitoring was active before the reload
    if (sessionStorage.getItem('orderMonitoringActive') === 'true') {
        console.log('Order Monitoring: Checking bot status before continuing monitoring');
        
        // Verify bot is still running before continuing
        chrome.storage.local.get(['botRunning'], function(data) {
            if (!data.botRunning) {
                console.log('Bot is no longer running, stopping order monitoring');
                stopOrderMonitoring();
                return;
            }
            
            console.log('Order Monitoring: Continuing monitoring after page reload');
            
            // Get the current refresh count
            const storedCount = sessionStorage.getItem('orderRefreshCount');
            orderRefreshCount = storedCount ? parseInt(storedCount) : 1;
            orderRefreshCount++; // Increment for the next refresh
            
            // Update the count in session storage
            sessionStorage.setItem('orderRefreshCount', orderRefreshCount.toString());
            
            console.log(`Order Monitoring: Page reloaded, continuing with refresh #${orderRefreshCount}`);
            
            // Scan for available orders on this freshly loaded page
            scanForAvailableOrders(true);
            
            // Schedule the next page refresh
            console.log(`Order Monitoring: Scheduling next visible refresh in ${ORDER_REFRESH_INTERVAL/1000} seconds`);
            
            // Store the next refresh time
            const nextRefreshTime = Date.now() + ORDER_REFRESH_INTERVAL;
            sessionStorage.setItem('nextOrderRefreshTime', nextRefreshTime.toString());
            
            // Set up the next refresh
            orderMonitoringInterval = setTimeout(() => {
                // Check if we're still on the all available page
                if (!window.location.href.includes('/writer/orders/all_available')) {
                    console.log('No longer on All Available Orders page, stopping monitoring');
                    stopOrderMonitoring();
                    return;
                }
                
                // Double-check bot is still running before refresh
                chrome.storage.local.get(['botRunning'], function(runData) {
                    if (!runData.botRunning) {
                        console.log('Bot is no longer running, stopping refresh cycle');
                        stopOrderMonitoring();
                        return;
                    }
                    
                    console.log(`Order Monitoring: Performing visible refresh #${orderRefreshCount}`);
                    
                    // If we've reached the max refresh count, reset by navigating
                    if (orderRefreshCount >= MAX_ORDER_REFRESH_COUNT) {
                        console.log(`Reached max refresh count (${MAX_ORDER_REFRESH_COUNT}), refreshing page and resetting count`);
                        orderRefreshCount = 0;
                        sessionStorage.setItem('orderRefreshCount', '0');
                    }
                    
                    // Reset watchdog timer on each successful scan
                    resetWatchdog(180000, 'order monitoring');
                    
                    // Update last refresh time
                    sessionStorage.setItem('lastOrderRefreshTime', Date.now().toString());
                    
                    // Do a full page reload
                    window.location.reload();
                });
            }, ORDER_REFRESH_INTERVAL);
        });
    }
}

// Function to stop order monitoring
function stopOrderMonitoring() {
    if (orderMonitoringInterval) {
        console.log('Stopping order monitoring...');
        clearTimeout(orderMonitoringInterval);
        orderMonitoringInterval = null;
    }
    
    // Disconnect MutationObserver if exists
    if (window.orderObserver) {
        console.log('Disconnecting order MutationObserver');
        window.orderObserver.disconnect();
        window.orderObserver = null;
    }
    
    // Clear session storage flags
    sessionStorage.removeItem('orderMonitoringActive');
    sessionStorage.removeItem('orderRefreshCount');
    sessionStorage.removeItem('nextOrderRefreshTime');
    sessionStorage.removeItem('lastOrderRefreshTime');
    
    // Reset counters
    orderRefreshCount = 0;
    
    // Stop watchdog
    stopWatchdog();
}

// Initialize the bot when the page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded (DOMContentLoaded), initializing...');
    
    // Check license status first
    checkLicenseStatus();
    
    // Check for immediate start parameter in URL (keeping this for backward compatibility)
    const urlParams = new URLSearchParams(window.location.search);
    const shouldStartMonitoring = urlParams.has('startMonitoring') || urlParams.has('forceStart');
    
    // Check if we're on the all available orders page
    const isOnAllAvailablePage = window.location.href.includes('/writer/orders/all_available');
    
    // If on all available page, immediately try to open an order if available
    if (isOnAllAvailablePage) {
        console.log('🚀 On All Available Orders page, checking bot status before operations...');
        
        // Check if bot is running first - only perform actions if bot is running
        chrome.storage.local.get(['botRunning'], function(data) {
            if (!data.botRunning) {
                console.log('Bot is not running - no automatic actions will be taken');
                return;
            }
            
            console.log('Bot is running - proceeding with order monitoring');
            
            // First try the most direct method to click an order
            setTimeout(() => {
                // Double-check bot status before clicking
                chrome.storage.local.get(['botRunning'], function(checkData) {
                    if (!checkData.botRunning) {
                        console.log('Bot is no longer running, skipping order click');
                        return;
                    }
                    console.log('🎯 Trying ultra-direct order click first');
                    clickExactOrderRow();
                });
            }, 500); // Small delay to ensure DOM is fully loaded
            
            // Then try direct click on order row by DOM structure with a slightly longer delay
            setTimeout(() => {
                // Double-check bot status before clicking
                chrome.storage.local.get(['botRunning'], function(checkData) {
                    if (!checkData.botRunning) {
                        console.log('Bot is no longer running, skipping DOM order click');
                        return;
                    }
                    
                    console.log('🎯 Attempting to directly open an order immediately');
                    
                    // Try the most direct method first
                    const clickResult = clickOrderRowByDom();
                    
                    if (!clickResult) {
                        console.log('No orders found or unable to open directly on initial check');
                    }
                });
            }, 1000); // Small delay to ensure DOM is fully loaded
            
            // Set a flag to track that we are on the All Available page
            sessionStorage.setItem('onAllAvailablePage', 'true');
            
            // If URL has startMonitoring parameter, force start regardless of botRunning state
            if (shouldStartMonitoring) {
                console.log('🚀 URL parameter detected, starting bot immediately');
                // Set bot running state and start monitoring immediately
                chrome.storage.local.set({ botRunning: true }, function() {
                    console.log('Bot running state set to TRUE via URL parameter');
                    // Force stop any existing monitoring first
                    if (typeof stopOrderMonitoring === 'function') {
                        stopOrderMonitoring();
                    }
                    startOrderMonitoring();
                    // Show visual confirmation
                    showStartBiddingConfirmation();
                });
            } else {
                // Otherwise check if the bot is already running (for clean URL)
                console.log('Bot running flag detected in storage with clean URL, starting monitoring');
                // Force stop any existing monitoring first
                if (typeof stopOrderMonitoring === 'function') {
                    stopOrderMonitoring();
                }
                startOrderMonitoring();
                // Show visual confirmation
                showStartBiddingConfirmation();
            }
        });
    }
    
    // Let the background script know the content script is loaded and ready
    console.log('Notifying background script that content script is fully loaded');
    chrome.runtime.sendMessage({ 
        action: 'contentScriptReady', 
        url: window.location.href,
        requestBotStatus: true 
    }, function(response) {
        // Only start monitoring if explicitly confirmed by background and we're on the right page
        if (response && response.botRunning && isOnAllAvailablePage) {
            console.log('Background reports bot should be running, starting monitoring');
            // Force stop any existing monitoring first
            if (typeof stopOrderMonitoring === 'function') {
                stopOrderMonitoring();
            }
            startOrderMonitoring();
            showStartBiddingConfirmation();
        }
    });
    
    // Check if we're on an order page immediately when DOM is ready
    if (window.location.href.match(/\/writer\/orders\/\d+/)) {
        // Verify bot is running before processing order
        chrome.storage.local.get(['botRunning'], function(data) {
            if (data.botRunning) {
                console.log('Bot is running and we are on order page - proceeding with order processing');
                checkForOrderPage();
            } else {
                console.log('Bot is not running - skipping auto order processing');
            }
        });
    }
});

// Also check when the page is fully loaded
window.addEventListener('load', function() {
    console.log('Page fully loaded (window.load)');
    
    // Check license status first
    checkLicenseStatus();
    
    // Check if we're on the all available page
    if (window.location.href.includes('/writer/orders/all_available')) {
        console.log('On All Available page at window.load, checking if monitoring should start');
        
        // Try direct click on order row by DOM structure on window.load for maximum reliability
        chrome.storage.local.get(['botRunning'], function(data) {
            if (data.botRunning) {
                console.log('🎯 Attempting to directly open an order on window.load event');
                
                // Try direct DOM access to order links
                setTimeout(() => {
                    const clickResult = clickOrderRowByDom();
                    
                    if (!clickResult) {
                        console.log('No orders found or unable to open directly on window.load');
                    }
                }, 500); // Small delay to ensure everything is ready
                
                // Final check to ensure monitoring is started if bot is running
                console.log('Bot is running and page fully loaded, ensuring monitoring is active');
                
                // Check if monitoring is already active
                if (!orderMonitoringInterval && !window.orderObserver) {
                    console.log('No active monitoring detected, starting monitoring now');
                    // Force stop any existing monitoring first as a safety measure
                    if (typeof stopOrderMonitoring === 'function') {
                        stopOrderMonitoring();
                    }
                    startOrderMonitoring();
                    showStartBiddingConfirmation();
                } else {
                    console.log('Monitoring already appears to be active');
                }
            }
        });
    } else if (window.location.href.match(/\/writer\/orders\/\d+$/) && 
        !window.location.href.includes('/all_available') && 
        !window.location.href.includes('/top_offers')) {
        
        console.log('On order details page at window.load, checking for auto-processing');
        
        // Check if bot is running
        chrome.storage.local.get(['botRunning'], function(data) {
            if (data.botRunning) {
                console.log('🔄 window.load: Bot is running, ensuring order processing starts');
                
                // Process order if not already in progress
                setTimeout(() => {
                    console.log('Sending backup processOrder request');
                    // Signal background to process this order
                    chrome.runtime.sendMessage({ 
                        action: 'onOrderPage',
                        url: window.location.href
                    });
                }, 2000);
            }
        });
    }
});

// Process a single order element - this is a reusable function for order processing
function processSingleOrderElement(orderElement) {
    return new Promise((resolve) => {
        // Skip if element is invalid
        if (!orderElement) {
            console.log('Invalid order element, skipping');
            resolve(false);
            return;
        }

        // Extract the order URL
        let orderUrl = null;
        let orderId = null;

        // Handle different element formats
        if (orderElement.tagName === 'A' && orderElement.hasAttribute('href')) {
            // The element itself is the link
            orderUrl = orderElement.getAttribute('href');
            console.log(`Found link element with URL: ${orderUrl}`);
            
            // CRITICAL: Skip if this is the all_available or top_offers URL
            if (orderUrl.includes('/all_available') || orderUrl.includes('/top_offers')) {
                console.log(`Skipping navigation URL: ${orderUrl} - this is not an order`);
                resolve(false);
                return;
            }
            
            // Try to extract ID from URL
            const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
            if (idMatch && idMatch[1]) {
                orderId = idMatch[1];
                console.log(`Extracted order ID from URL: ${orderId}`);
            } else {
                // Try to find ID in element content
                const idSpan = orderElement.querySelector('.table_item_order_id span');
                if (idSpan) {
                    orderId = idSpan.textContent.trim();
                    console.log(`Extracted order ID from span: ${orderId}`);
                }
            }
        } else {
            // Look for a link inside the element
            const orderLink = orderElement.querySelector('a[href*="/writer/orders/"]');
            if (!orderLink || 
                orderLink.getAttribute('href').includes('/all_available') || 
                orderLink.getAttribute('href').includes('/top_offers')) {
                console.log('No valid order link found in element, skipping');
                resolve(false);
                return;
            }
            
            orderUrl = orderLink.getAttribute('href');
            console.log(`Found nested link with URL: ${orderUrl}`);
            
            // Try to extract ID from URL
            const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
            if (idMatch && idMatch[1]) {
                orderId = idMatch[1];
                console.log(`Extracted order ID from nested URL: ${orderId}`);
            }
        }
        
        // Ensure URL is valid and not a navigation page
        if (!orderUrl || 
            orderUrl.includes('/all_available') || 
            orderUrl.includes('/top_offers') ||
            !orderUrl.match(/\/writer\/orders\/\d+/)) {
            console.log('Could not extract valid order URL, skipping');
            resolve(false);
            return;
        }
        
        // Make sure orderUrl is absolute
        if (!orderUrl.startsWith('http')) {
            if (orderUrl.startsWith('/')) {
                orderUrl = window.location.origin + orderUrl;
            } else {
                orderUrl = window.location.origin + '/' + orderUrl;
            }
            console.log(`Converted to absolute URL: ${orderUrl}`);
        }
        
        // Check if already processed using storage
        chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
            const processedUrls = data.processedOrderUrls || [];
            const processedIds = data.processedOrderIds || [];
            
            // Check if already processed
            if (orderId && processedIds.includes(orderId)) {
                console.log(`Order ID ${orderId} already processed, skipping`);
                resolve(false);
                return;
            }
            
            if (processedUrls.includes(orderUrl)) {
                console.log(`Order URL ${orderUrl} already processed, skipping`);
                resolve(false);
                return;
            }
            
            // We found a new order to process!
            console.log(`🔔 NEW ORDER FOUND! ${orderId ? `ID: ${orderId}, ` : ''}URL: ${orderUrl}`);
            
            // CRITICAL: Stop any auto-refresh before processing the order
            console.log('⚠️ Stopping auto-refresh immediately to process this order');
            if (typeof stopOrderMonitoring === 'function') {
                stopOrderMonitoring();
            }
            
            // Highlight the order visually
            highlightSelectedOrder(orderElement);
            
            // Notify background script
            chrome.runtime.sendMessage({ 
                action: 'orderFound',
                orderId: orderId,
                orderUrl: orderUrl
            });
            
            // Log the navigation attempt clearly
            console.log(`🚀 NAVIGATING: Opening order ${orderId || ''} using direct URL: ${orderUrl}`);
            
            // Use a stronger click method with multiple approaches
            // ALWAYS pass the orderUrl as the fallback to ensure direct navigation is prioritized
            tryRobustClick(orderElement, orderUrl);
            
            // Mark as processed
            resolve(true);
        });
    });
}

// Function to scan for available orders on the page - modified to use processSingleOrderElement
function scanForAvailableOrders(isInitialScan = false) {
    console.log('Scanning for available orders...');
    
    // Add a visual indicator to show active monitoring
    showMonitoringIndicator(orderRefreshCount);
    
    // DIRECT DOM APPROACH: Start with the most reliable approach that handles unprocessed orders
    console.log("⚡ Starting with direct DOM access approach for random selection of unprocessed orders...");
    const directDomSuccess = clickOrderRowByDom();
    
    if (directDomSuccess) {
        console.log("✅ Successfully opened unprocessed order with direct DOM access");
        return true;
    }
    
    // IMPROVED APPROACH: Next try the table row click method that also handles unprocessed orders
    console.log("🔄 Direct DOM access failed, trying table row click method...");
    const directClickSuccess = clickOrderTableRow();
    
    if (directClickSuccess) {
        console.log("✅ Successfully opened unprocessed order with table row click method");
        return true;
    }
    
    // Try the exact order row approach, now properly updated to check for unprocessed orders
    console.log("⚡ Trying exact order row click with unprocessed order checking...");
    const exactClickSuccess = clickExactOrderRow();
    
    if (exactClickSuccess) {
        console.log("✅ Successfully opened unprocessed order with exact row click");
        return true;
    }
    
    // Log all selectors we find for debugging
    console.log('DEBUG: Looking for the following element types:');
    logElementCounts();
    
    // Process order elements with the new centralized function as final fallback
    return new Promise(async (resolve) => {
        // Try with multiple selectors to find orders
        const selectors = [
            'a.table_row.ng-scope',
            '.table_row[ng-repeat="order in orders"]',
            'a[href*="/writer/orders/"]',
            '.orders_table a',
            '.order-card, .order_card'
        ];
        
        // Get the list of processed orders first
        chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], async function(data) {
            const processedIds = data.processedOrderIds || [];
            const processedUrls = data.processedOrderUrls || [];
            
            // Collect all unprocessed elements first
            let allUnprocessedElements = [];
        
        for (const selector of selectors) {
            const elements = document.querySelectorAll(selector);
            if (!elements || elements.length === 0) continue;
            
            console.log(`Found ${elements.length} potential orders with selector: ${selector}`);
            
                // Filter to only unprocessed elements
            for (const element of elements) {
                    // Extract order info
                    let orderUrl = null;
                    let orderId = null;
                    
                    if (element.tagName === 'A' && element.hasAttribute('href')) {
                        orderUrl = element.getAttribute('href');
                    } else {
                        const link = element.querySelector('a[href*="/writer/orders/"]');
                        if (link) orderUrl = link.getAttribute('href');
                    }
                    
                    // Skip invalid URLs or navigation pages
                    if (!orderUrl || orderUrl.includes('/all_available') || orderUrl.includes('/top_offers')) {
                        continue;
                    }
                    
                    // Extract ID
                    const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
                    if (idMatch && idMatch[1]) {
                        orderId = idMatch[1];
                    }
                    
                    // Check if processed
                    const isProcessed = (orderId && processedIds.includes(orderId)) || 
                                       (orderUrl && processedUrls.includes(orderUrl));
                    
                    if (!isProcessed) {
                        allUnprocessedElements.push(element);
                    }
                }
            }
            
            console.log(`Found ${allUnprocessedElements.length} total unprocessed orders`);
            
            // If we have unprocessed elements, randomly select one
            if (allUnprocessedElements.length > 0) {
                // Select a random unprocessed element
                const randomIndex = Math.floor(Math.random() * allUnprocessedElements.length);
                const selectedElement = allUnprocessedElements[randomIndex];
                
                console.log(`Randomly selected element ${randomIndex+1} of ${allUnprocessedElements.length} for processing`);
                
                // Process it
                const processed = await processSingleOrderElement(selectedElement);
                resolve(processed);
            } else {
                console.log('No unprocessed orders found');
        resolve(false);
            }
        });
    });
}

// Function to directly click on order table rows using the specific selector
function clickOrderTableRow() {
    // Check if we're on the all available orders page
    if (!window.location.href.includes('/writer/orders/all_available')) {
        console.log("Not on the all available orders page. Current URL:", window.location.href);
        return false;
    }

    console.log("Collecting valid order rows from the available orders table");
    
    // Find all order rows and filter out navigation links
    const validOrderRows = [];
    const orderRows = document.querySelectorAll('tr[class*="OrderTable_row"]');
    
    orderRows.forEach(row => {
        const anchor = row.querySelector('a');
        if (anchor && anchor.href && anchor.href.includes('/writer/orders/') && !anchor.href.includes('/all_available')) {
            validOrderRows.push(row);
        }
    });
    
    // Check if we have any valid order rows
    if (validOrderRows.length === 0) {
        console.log("No valid order rows found.");
        return false;
    }
    
    // Create an array to store unprocessed rows
    const unprocessedRows = [];
    // Use a promise to ensure we filter out all previously processed orders before selecting
    return new Promise((finalResolve) => {
        // Process each row sequentially to check if it was already processed
        const checkNextRow = (index) => {
            if (index >= validOrderRows.length) {
                // All rows checked, now proceed with selection
                if (unprocessedRows.length === 0) {
                    console.log("All available orders have been processed already.");
                    finalResolve(false);
                    return;
                }
                
                // Randomly select an order from the unprocessed ones
                const randomIndex = Math.floor(Math.random() * unprocessedRows.length);
                const selectedRow = unprocessedRows[randomIndex];
                const orderLink = selectedRow.querySelector('a');
                
                if (!orderLink || !orderLink.href) {
                    console.log("Selected row doesn't contain a valid order link");
                    finalResolve(false);
                    return;
                }
                
                // Extract the order ID for tracking purposes
                const orderId = extractOrderId(orderLink.href);
                console.log(`Selected random order ${randomIndex + 1} of ${unprocessedRows.length}. Order ID: ${orderId}`);
                
                // Visually highlight the selected order
                highlightSelectedOrder(selectedRow);
                
                const startUrl = window.location.href;
                
                // Log the selection
                console.log(`Attempting to click on random order ${randomIndex + 1} of ${unprocessedRows.length}`);
                
                // First attempt: use our enhanced click simulation
                simulateFullClick(orderLink);
                
                // Wait to see if navigation occurs
                setTimeout(() => {
                    if (window.location.href === startUrl) {
                        console.log("Navigation failed. Trying direct href navigation.");
                        // If we're still on the same page, try direct navigation
                        window.location.href = orderLink.href;
                        
                        // Check again after a short delay
                        setTimeout(() => {
                            if (window.location.href === startUrl) {
                                console.log("Direct navigation failed. Trying window.open as last resort.");
                                // Last resort: try window.open
                                window.open(orderLink.href, '_self');
                            }
                            
                            // Record this order as processed
                            manageProcessedOrders(orderId, 'add').then(() => {
                                finalResolve(true);
                            });
                        }, 1000);
                    } else {
                        // Navigation was successful
                        manageProcessedOrders(orderId, 'add').then(() => {
                            finalResolve(true);
                        });
                    }
                }, 2000);
                
                return;
            }
            
            const row = validOrderRows[index];
            const anchor = row.querySelector('a');
            const orderId = extractOrderId(anchor.href);
            
            // Check both tracking mechanisms
            Promise.all([
                // Check using manageProcessedOrders function
                manageProcessedOrders(orderId, 'check'),
                // Check directly in storage to handle orders rejected by criteria
                new Promise(resolve => {
                    chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], function(data) {
                        const processedIds = data.processedOrderIds || [];
                        const processedUrls = data.processedOrderUrls || [];
                        const isProcessed = (orderId && processedIds.includes(orderId)) || 
                                           (anchor.href && processedUrls.includes(anchor.href));
                        resolve(isProcessed);
                    });
                })
            ]).then(results => {
                // If either check returns true, the order has been processed
                const isProcessed = results[0] || results[1];
                
                if (isProcessed) {
                    console.log(`Order ${orderId} was previously processed. Skipping.`);
                } else {
                    // This is an unprocessed order, add it to our candidates
                    unprocessedRows.push(row);
                }
                
                // Check the next row
                checkNextRow(index + 1);
            });
        };
        
        // Start the recursive checking process
        checkNextRow(0);
    });
}

// New function to check for orders using the exact format provided
function checkForOrdersExactFormat() {
    console.log("Checking for orders in the All Available Orders table...");
    
    // CRITICAL: First verify we're on the all_available page
    if (!window.location.href.includes('/writer/orders/all_available')) {
        console.log('⚠️ Not on all_available page, skipping order check');
        return false;
    }
    
    // Look specifically for the all_available_orders_table
    const allAvailableTable = document.querySelector('.orders_table.all_available_orders_table');
    if (!allAvailableTable) {
        console.log("⚠️ All Available Orders table not found on the page!");
        return false;
    }
    
    // Check if there are actually any orders (non-header rows) in the all_available table
    const tableBody = allAvailableTable.querySelector('.table_body');
    if (!tableBody) {
        console.log("Table body not found in All Available Orders table");
        return false;
    }
    
    // Use the exact Angular selectors for better precision
    const angularSelectors = [
        // First try with the exact renewed class as shown in the example
        'a.table_row.ng-scope.renewed[href*="/writer/orders/"]',
        // Then try without renewed class (for visited orders)
        'a.table_row.ng-scope[href*="/writer/orders/"]',
        // Then try with ng-repeat attribute
        'a.table_row.ng-scope[ng-repeat="order in orders"]',
        // Finally fall back to more basic selector
        'a.table_row[href*="/writer/orders/"]'
    ];
    
    // Try each selector in priority order
    for (const selector of angularSelectors) {
        const orderRows = tableBody.querySelectorAll(selector);
        console.log(`Found ${orderRows.length} order links using selector: ${selector}`);
        
        if (orderRows.length === 0) continue;
        
        // Create a list of unprocessed orders
        const unprocessedOrderRows = [];
        
        // Get the list of already processed orders
        return new Promise(resolve => {
            chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], function(data) {
                const processedIds = data.processedOrderIds || [];
                const processedUrls = data.processedOrderUrls || [];
                
                // Check each order row to see if it has been processed
        for (let i = 0; i < orderRows.length; i++) {
            const orderRow = orderRows[i];
            const href = orderRow.getAttribute('href');
            
            // Skip if this is not a valid order URL or points to other sections
            if (!href || href.includes('/all_available') || href.includes('/top_offers') || 
                href.includes('/pending') || href.includes('/in_process')) {
                console.log(`Skipping invalid order URL in All Available: ${href}`);
                continue;
            }
            
            // Extract order ID from URL
            const idMatch = href.match(/\/writer\/orders\/(\d+)/);
            if (!idMatch || !idMatch[1]) {
                console.log(`Could not extract order ID from URL in All Available: ${href}`);
                continue;
            }
            
            const orderId = idMatch[1];
                    
                    // Check if this order has been processed already
                    const isProcessed = processedIds.includes(orderId) || processedUrls.includes(href);
                    
                    if (!isProcessed) {
                        console.log(`Found unprocessed order in All Available with ID ${orderId}, URL: ${href}`);
                        unprocessedOrderRows.push({ row: orderRow, orderId: orderId });
                    } else {
                        console.log(`Skipping already processed order with ID ${orderId}`);
                    }
                }
                
                // If we have unprocessed orders, select one randomly
                if (unprocessedOrderRows.length > 0) {
                    // Randomly select an order from the unprocessed ones
                    const randomIndex = Math.floor(Math.random() * unprocessedOrderRows.length);
                    const selected = unprocessedOrderRows[randomIndex];
                    
                    console.log(`Selected random order ${randomIndex + 1} of ${unprocessedOrderRows.length}. Order ID: ${selected.orderId}`);
                    
                    // Process the selected order
                    resolve(processExactFormatOrder(selected.row, selected.orderId));
                } else {
                    console.log("No unprocessed orders found in All Available Orders table");
                    
                    // IMPROVED APPROACH: Use direct click approach as a fallback if Angular selectors didn't work
                    console.log("Angular selectors didn't find unprocessed orders, trying direct click approach");
                    const clickSuccess = clickOrderRowByDom();
                    
                    if (clickSuccess) {
                        console.log("Successfully opened order with direct click approach");
                        resolve(true);
                    } else {
                        console.log("No valid unprocessed orders found in All Available Orders table");
                        resolve(false);
                    }
                }
            });
        });
    }
    
    // If we reach here, we couldn't find any valid orders with the Angular selectors
    // IMPROVED APPROACH: Use direct click approach as a fallback if Angular selectors didn't work
    console.log("Angular selectors didn't find orders, trying direct click approach");
    const clickSuccess = clickOrderRowByDom();
    
    if (clickSuccess) {
        console.log("Successfully opened order with direct click approach");
        return true;
    }
    
    // If we get here, we couldn't find any valid orders in the All Available table
    console.log("No valid orders found in All Available Orders table");
    return false;
}

// Function to find and process orders by direct DOM inspection as a last resort
function findAndProcessOrderByDirectDOMInspection() {
    console.log('🔍 Attempting direct DOM inspection for orders in All Available...');
    
    // CRITICAL: First verify we're on the all_available page
    if (!window.location.href.includes('/writer/orders/all_available')) {
        console.log('⚠️ Not on all_available page, skipping direct DOM inspection');
        return Promise.resolve(false);
    }
    
    // Look specifically for the all_available_orders_table
    const allAvailableTable = document.querySelector('.orders_table.all_available_orders_table');
    if (!allAvailableTable) {
        console.log("⚠️ All Available Orders table not found for direct DOM inspection");
        return Promise.resolve(false);
    }
    
    // Attempt to find any links to orders in the All Available table
    const orderLinks = allAvailableTable.querySelectorAll('a[href*="/writer/orders/"]');
    console.log(`Found ${orderLinks.length} potential order links in All Available table via direct DOM inspection`);
    
    if (orderLinks.length === 0) {
        console.log('No order links found in All Available via direct DOM inspection');
        return Promise.resolve(false);
    }
    
    // Return a Promise to handle async operations
    return new Promise((resolve) => {
        // Get the currently processed orders
        chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], function(data) {
            const processedIds = data.processedOrderIds || [];
            const processedUrls = data.processedOrderUrls || [];
            
            console.log(`Checking against ${processedIds.length} processed IDs and ${processedUrls.length} processed URLs`);
            
            // Filter to valid unprocessed orders only
            const unprocessedOrders = [];
            
            // Process each link to find valid unprocessed orders
    for (let i = 0; i < orderLinks.length; i++) {
        const link = orderLinks[i];
        const href = link.getAttribute('href');
        
        // Skip navigation links or links to other sections
        if (!href || 
            href.includes('/all_available') || 
            href.includes('/top_offers') || 
            href.includes('/pending') || 
            href.includes('/in_process')) {
            continue;
        }
        
        // Try to extract order ID
        const idMatch = href.match(/\/writer\/orders\/(\d+)/);
        if (!idMatch || !idMatch[1]) {
            continue;
        }
        
        const orderId = idMatch[1];
                
                // Ensure URL is absolute
        const fullUrl = href.startsWith('http') ? href : 
                     (href.startsWith('/') ? window.location.origin + href : 
                     window.location.origin + '/' + href);
                     
                // Check if this order has been processed already
                const isProcessed = processedIds.includes(orderId) || 
                                    processedUrls.includes(fullUrl) || 
                                    processedUrls.includes(href);
                
                if (!isProcessed) {
                    console.log(`Found unprocessed order via direct DOM inspection: ID=${orderId}, URL=${fullUrl}`);
                    unprocessedOrders.push({ link, orderId, fullUrl });
                } else {
                    console.log(`Skipping already processed order with ID ${orderId}`);
                }
            }
            
            // If we have unprocessed orders, select one randomly
            if (unprocessedOrders.length > 0) {
                // Randomly select an order
                const randomIndex = Math.floor(Math.random() * unprocessedOrders.length);
                const selected = unprocessedOrders[randomIndex];
                
                console.log(`Randomly selected order ${randomIndex + 1} of ${unprocessedOrders.length}. Order ID: ${selected.orderId}`);
                
                // Mark as processed first
                manageProcessedOrders(selected.orderId, 'add');
                
                // Navigate directly to the selected order
                console.log(`📍 Direct navigation to randomly selected order: ${selected.fullUrl}`);
                window.location.href = selected.fullUrl;
                
                resolve(true);
            } else {
                console.log('No unprocessed orders found in All Available via direct DOM inspection');
                resolve(false);
            }
        });
    });
}

// Function to process an order in the exact format
function processExactFormatOrder(orderElement, orderId = null) {
    try {
        console.log("Processing order with element:", orderElement);
        
        // Extract info from the element
        const orderUrl = orderElement.getAttribute('href');
        
        // CRITICAL - Filter out the all_available page!
        if (orderUrl.includes('/all_available')) {
            console.log("SKIPPING - This is the all_available page, not an order!");
            return false;
        }
        
        const fullUrl = orderUrl.startsWith('/') ? 
            window.location.origin + orderUrl : 
            window.location.origin + '/' + orderUrl;
        
        // If orderId wasn't passed, try to extract it
        if (!orderId) {
            const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
            if (idMatch && idMatch[1]) {
                orderId = idMatch[1];
            } else {
                // Try to find ID in element content
                const idSpan = orderElement.querySelector('.table_item_order_id span');
                if (idSpan) {
                    orderId = idSpan.textContent.trim();
                }
            }
        }
        
        // FINAL CHECK - Ensure this is a valid order URL with numeric ID
        if (!orderId || !(/^\d+$/).test(orderId)) {
            console.log(`Invalid order ID: ${orderId}, URL: ${fullUrl}`);
            return false;
        }
        
        console.log(`Found valid order with ID ${orderId} and URL ${fullUrl}`);
        
        // Check if order has already been processed
        chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
            const processedUrls = data.processedOrderUrls || [];
            const processedIds = data.processedOrderIds || [];
            
            if ((orderId && processedIds.includes(orderId)) || processedUrls.includes(fullUrl)) {
                console.log(`Order ${orderId} has already been processed, skipping`);
                return false;
            }
            
            // Display the "Processing" overlay immediately
            const overlay = document.createElement('div');
            overlay.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0, 0, 0, 0.7);
                z-index: 10000;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                color: white;
                font-size: 24px;
                font-weight: bold;
            `;
            
            const spinner = document.createElement('div');
            spinner.style.cssText = `
                width: 50px;
                height: 50px;
                border: 5px solid rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                border-top-color: white;
                animation: spin 1s linear infinite;
                margin-bottom: 20px;
            `;
            
            // Make sure spin animation exists
            if (!document.getElementById('spin-animation')) {
                const style = document.createElement('style');
                style.id = 'spin-animation';
                style.textContent = `
                    @keyframes spin {
                        to { transform: rotate(360deg); }
                    }
                `;
                document.head.appendChild(style);
            }
            
            const text = document.createElement('div');
            text.textContent = `Opening Order #${orderId}...`;
            
            overlay.appendChild(spinner);
            overlay.appendChild(text);
            document.body.appendChild(overlay);
            
            // Notify that we've found an order
            chrome.runtime.sendMessage({ 
                action: 'orderFound',
                orderId: orderId,
                orderUrl: fullUrl
            });
            
            // Stop monitoring since we're navigating
            stopOrderMonitoring();
            
            // TRY THREE DIFFERENT METHODS TO OPEN THE ORDER
            
            // HIGHLIGHT THE ORDER BEING PROCESSED
            // Add a bright border around the order element
            try {
                orderElement.style.position = 'relative';
                orderElement.style.zIndex = '1000';
                orderElement.style.border = '3px solid #ff0000';
                orderElement.style.boxShadow = '0 0 10px rgba(255, 0, 0, 0.7)';
                orderElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } catch (e) {
                console.log("Error highlighting order:", e);
            }
            
            // Method 1: Try direct element click
            try {
                console.log("Method 1: Direct click on element:", orderElement);
                orderElement.click();
            } catch (e) {
                console.log("Method 1 failed:", e);
            }
            
            // Method 2: Force direct navigation after a short delay
            setTimeout(() => {
                // Check if we're still on the all available page (click didn't work)
                if (window.location.href.includes('/all_available')) {
                    console.log("Method 2: Direct navigation to:", fullUrl);
                    window.location.href = fullUrl;
                }
            }, 500);
            
            // Method 3: In case methods 1 and 2 fail, set a final fallback
            setTimeout(() => {
                // Check if we're still on the all available page (methods 1 and 2 didn't work)
                if (window.location.href.includes('/all_available')) {
                    console.log("Method 3: Fallback window.open navigation");
                    window.open(fullUrl, '_self');
                }
            }, 1500);
            
            return true;
        });
        
        return true; // Indicate we found and are processing an order
    } catch (e) {
        console.error("Error processing order:", e);
        return false;
    }
}

// Function to log counts of various element types for debugging
function logElementCounts() {
    console.log(`- Table rows (a.table_row): ${document.querySelectorAll('a.table_row').length}`);
    console.log(`- Table rows (ng-repeat): ${document.querySelectorAll('.table_row[ng-repeat="order in orders"]').length}`);
    console.log(`- Table rows (any): ${document.querySelectorAll('.table_row').length}`);
    console.log(`- Order links: ${document.querySelectorAll('a[href*="/writer/orders/"]').length}`);
    console.log(`- Orders table: ${document.querySelectorAll('.orders_table').length}`);
    console.log(`- Table body: ${document.querySelectorAll('.table_body').length}`);
    console.log(`- Order cards: ${document.querySelectorAll('.order-card, .order_card').length}`);
}

// Helper function to try finding and processing an order from a collection of elements
function tryToFindAndProcessOrder(elements, processedUrls, processedIds, isInitialScan) {
    if (!elements || elements.length === 0) {
        return false;
    }
    
    console.log(`Trying to process ${elements.length} potential order elements`);
    
    // Flag to track if we found an order to process
    let foundOrderToProcess = false;
    
    // Process each potential order element
    for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        
        // Skip navigation menu links that might appear in search results
        if (element.closest('nav') || element.closest('.navigation') || element.closest('header') || element.closest('.menu')) {
            console.log('Skipping menu/navigation link');
            continue;
        }
        
        // Try to extract order ID and URL
        let orderId = null;
        let orderUrl = null;
        
        // Handle different element formats
        if (element.tagName === 'A' && element.hasAttribute('href')) {
            // The element itself is the link
            orderUrl = element.getAttribute('href');
            console.log(`Found link element with URL: ${orderUrl}`);
            
            // CRITICAL: Skip if this is the all_available or top_offers URL
            if (orderUrl.includes('/all_available') || orderUrl.includes('/top_offers')) {
                console.log(`Skipping navigation URL: ${orderUrl} - this is not an order`);
                continue;
            }
            
            // Try to extract ID from URL
            const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
            if (idMatch && idMatch[1]) {
                orderId = idMatch[1];
                console.log(`Extracted order ID from URL: ${orderId}`);
            } else {
                // Try to find ID in element content
                const idSpan = element.querySelector('.table_item_order_id span');
                if (idSpan) {
                    orderId = idSpan.textContent.trim();
                    console.log(`Extracted order ID from span: ${orderId}`);
                }
            }
        } else {
            // Look for a link inside the element
            const orderLink = element.querySelector('a[href*="/writer/orders/"]');
            if (!orderLink || 
                orderLink.getAttribute('href').includes('/all_available') || 
                orderLink.getAttribute('href').includes('/top_offers')) {
                console.log('No valid order link found in element, skipping');
                continue;
            }
            
            orderUrl = orderLink.getAttribute('href');
            console.log(`Found nested link with URL: ${orderUrl}`);
            
            // Try to extract ID from URL
            const idMatch = orderUrl.match(/\/writer\/orders\/(\d+)/);
            if (idMatch && idMatch[1]) {
                orderId = idMatch[1];
                console.log(`Extracted order ID from nested URL: ${orderId}`);
            }
        }
        
        // Ensure URL is valid and not a navigation page
        if (!orderUrl || 
            orderUrl.includes('/all_available') || 
            orderUrl.includes('/top_offers') ||
            !orderUrl.match(/\/writer\/orders\/\d+/)) {
            console.log('Could not extract valid order URL, skipping');
            continue;
        }
        
        // Make sure orderUrl is absolute
        if (!orderUrl.startsWith('http')) {
            if (orderUrl.startsWith('/')) {
                orderUrl = window.location.origin + orderUrl;
            } else {
                orderUrl = window.location.origin + '/' + orderUrl;
            }
            console.log(`Converted to absolute URL: ${orderUrl}`);
        }
        
        // Check if already processed
        if (orderId && processedIds.includes(orderId)) {
            console.log(`Order ID ${orderId} already processed, skipping`);
            continue;
        }
        
        if (processedUrls.includes(orderUrl)) {
            console.log(`Order URL ${orderUrl} already processed, skipping`);
            continue;
        }
        
        // We found a new order to process!
        console.log(`🔔 NEW ORDER FOUND! ${orderId ? `ID: ${orderId}, ` : ''}URL: ${orderUrl}`);
        foundOrderToProcess = true;
        
        // If initial scan, wait for refresh
        if (isInitialScan) {
            console.log('Initial scan detected, waiting for refresh cycle before processing order');
            showOrderFoundIndicator(orderUrl);
            return true;
        }
        
        // Highlight the order visually
        highlightSelectedOrder(element);
        
        // Notify background script
        chrome.runtime.sendMessage({ 
            action: 'orderFound',
            orderId: orderId,
            orderUrl: orderUrl
        });
        
        // Try a direct click first (most reliable on table rows)
        console.log('Attempting to directly click the order element...');
        
        // Use a stronger click method with multiple approaches
        tryRobustClick(element, orderUrl);
        break;
    }
    
    if (!foundOrderToProcess) {
        console.log('No new orders found in this set of elements');
    }
    
    return foundOrderToProcess;
}

// Function to try multiple ways to open an order - prioritizing direct navigation for speed and reliability
function tryRobustClick(element, fallbackUrl) {
    console.log('Enhanced tryRobustClick: Attempting to navigate with prioritized direct URL method');
    
    // Ensure the fallback URL is absolute
    if (fallbackUrl && !fallbackUrl.startsWith('http')) {
        fallbackUrl = fallbackUrl.startsWith('/') 
            ? window.location.origin + fallbackUrl 
            : window.location.origin + '/' + fallbackUrl;
    }
    
    // Show navigation indicator
    showNavigationIndicator('Opening order...');
    
    // Store starting URL to compare later
    const startingUrl = window.location.href;
    
    // CRITICAL: Set a watchdog timer for the overall navigation attempt
    const navigationWatchdog = setTimeout(() => {
        if (window.location.href.includes('/all_available')) {
            console.error('⚠️ CRITICAL: Navigation watchdog timeout triggered - all methods failed');
            
            // Force a final attempt with window.open and form submit
            try {
                // Create a form for the most forceful navigation method
                const form = document.createElement('form');
                form.method = 'GET';
                form.action = fallbackUrl;
                form.target = '_self';
                document.body.appendChild(form);
                form.submit();
                
                setTimeout(() => {
                    // If still on all_available, give up and return to monitoring
                    if (window.location.href.includes('/all_available')) {
                        // Notify background script of failure
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: false,
                            orderUrl: fallbackUrl,
                            reasons: 'Navigation failed after all attempts'
                        });
                        
                        // Reset the page state
                        window.location.reload();
                    }
                }, 500);
            } catch (e) {
                console.error('Final navigation attempt failed:', e);
                window.location.reload();
            }
        }
    }, 5000); // 5 second watchdog timeout
    
    // METHOD 1: Direct URL navigation - fastest and most reliable
    if (fallbackUrl && fallbackUrl.includes('/writer/orders/')) {
        console.log('METHOD 1: Direct URL navigation to:', fallbackUrl);
        
        try {
            window.location.href = fallbackUrl;
            
            // Set a timeout to check if navigation succeeded
            setTimeout(() => {
                if (window.location.href === startingUrl) {
                    console.log('METHOD 1 failed, trying window.open...');
                    
                    // METHOD 2: window.open
                    try {
                        window.open(fallbackUrl, '_self');
                        
                        // Check if that worked
                        setTimeout(() => {
                            if (window.location.href === startingUrl) {
                                console.log('METHOD 2 failed, trying location.replace...');
                                
                                // METHOD 3: location.replace
                                try {
                                    window.location.replace(fallbackUrl);
                                } catch (e) {
                                    console.error('METHOD 3 failed:', e);
                                }
                            } else {
                                // Navigation succeeded, clear watchdog
                                clearTimeout(navigationWatchdog);
                            }
                        }, 300);
                    } catch (e) {
                        console.error('METHOD 2 failed:', e);
                    }
                } else {
                    // Navigation succeeded, clear watchdog
                    clearTimeout(navigationWatchdog);
                }
            }, 300);
            
            return true;
        } catch (e) {
            console.error('ERROR in METHOD 1:', e);
            // Fall through to try more methods
        }
    }
    
    // METHOD 4: Element click approach
    if (element) {
        // For link elements, extract href
        const href = element.tagName === 'A' && element.hasAttribute('href') 
            ? element.getAttribute('href') 
            : null;
            
        const orderUrl = href && href.includes('/writer/orders/') 
            ? (href.startsWith('http') ? href : window.location.origin + (href.startsWith('/') ? href : '/' + href)) 
            : fallbackUrl;
            
        console.log('METHOD 4: Element click with orderUrl:', orderUrl);
        
        try {
            // Try clicking the element
            if (typeof window.simulateFullClick === 'function') {
                window.simulateFullClick(element);
            } else {
                element.click();
            }
            
            // Check if navigation worked
            setTimeout(() => {
                if (window.location.href === startingUrl) {
                    console.log('METHOD 4 failed, trying direct navigation with orderUrl');
                    
                    // If we have a valid URL from the element or fallback, use it
                    if (orderUrl) {
                        window.location.href = orderUrl;
                    }
                } else {
                    // Navigation succeeded, clear watchdog
                    clearTimeout(navigationWatchdog);
                }
            }, 300);
            
            return true;
        } catch (e) {
            console.error('METHOD 4 failed:', e);
            
            // If we have a valid URL from the element or fallback, use it as final attempt
            if (orderUrl) {
                try {
                    window.location.href = orderUrl;
                } catch (e2) {
                    console.error('Final navigation attempt failed:', e2);
                }
            }
        }
    }
    
    return false;
}

// Helper function to show navigation indicator
function showNavigationIndicator(message) {
    // Empty implementation
}

// Function to visually highlight an order that's being processed
function highlightSelectedOrder(orderElement) {
    // Empty implementation
}

// Function to display a visual indicator for monitoring activity
function showMonitoringIndicator(refreshCount) {
    // Empty implementation
}

// Function to show an indicator when an order is found but waiting for refresh
function showOrderFoundIndicator(orderUrl) {
    // Empty implementation
}

// Add these declarations after the hostname check
let watchdogTimer = null;
const DEFAULT_WATCHDOG_TIMEOUT = 120 * 1000; // 120 seconds default timeout

// Also make sure you have a stopWatchdog function
function stopWatchdog() {
    if (watchdogTimer) {
        clearTimeout(watchdogTimer);
        watchdogTimer = null;
        console.log('Watchdog timer stopped');
    }
}

// Function to navigate to the "All Available Orders" page
function navigateToAllAvailableOrders() {
    console.log('Navigating to All Available Orders using standardized function');
    
    // Check if bot is running before performing navigation
    chrome.storage.local.get(['botRunning'], function(data) {
        // If bot is not running, skip forced navigation to allow normal website usage
        if (!data.botRunning) {
            console.log('Bot is not running, skipping forced navigation to allow normal website usage');
            return;
        }
        
        // Rest of the navigation logic only executes when bot is running
        // Stop any ongoing processes
        if (typeof stopWatchdog === 'function') {
            stopWatchdog();
        }
        
        if (typeof window.stopTakeButtonMonitoring === 'function') {
            window.stopTakeButtonMonitoring();
        }
        
        if (typeof stopOrderMonitoring === 'function') {
            stopOrderMonitoring();
        }
        
        // Create an overlay to indicate we're navigating
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 10000;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 20px;
            font-weight: bold;
        `;
        
        const text = document.createElement('div');
        text.textContent = 'Returning to All Available Orders...';
        overlay.appendChild(text);
        document.body.appendChild(overlay);
        
        // Check if we're already on the all_available page
        if (window.location.href.includes('/writer/orders/all_available')) {
            console.log('Already on All Available Orders page, refreshing instead');
            
            // Update the overlay text
            text.textContent = 'Refreshing All Available Orders...';
            
            // Add a slight delay then reload
            setTimeout(() => {
                window.location.reload();
            }, 500);
            return;
        }
        
        // First try: Use the standard function from background.js if available
        if (typeof window.navigateToAllAvailable === 'function') {
            try {
                window.navigateToAllAvailable();
                return;
            } catch (e) {
                console.error('Error using navigateToAllAvailable:', e);
                // Continue to fallback methods
            }
        }
        
        // Second try: Always navigate directly to all_available (not top_offers or any other page)
        try {
            // We specifically only want the all_available page, not top_offers or pending
            const allAvailableUrl = "/writer/orders/all_available";
            const fullUrl = window.location.origin + allAvailableUrl;
            console.log('Navigating directly to All Available Orders page:', fullUrl);
            window.location.href = fullUrl;
            
            // Add a verification check
            setTimeout(() => {
                if (!window.location.href.includes('/all_available')) {
                    // Third try: If still not on all_available, try window.open
                    console.log('Navigation failed, trying with window.open');
                    window.open(fullUrl, '_self');
                }
            }, 1000);
        } catch (e) {
            console.error('Error navigating to All Available Orders:', e);
            
            // Final try: Most aggressive approach with location.replace
            try {
                // We explicitly target only the all_available page
                window.location.replace(window.location.origin + '/writer/orders/all_available');
            } catch (e2) {
                console.error('All navigation methods failed:', e2);
                // As absolute last resort, force a page reload
                window.location.reload();
            }
        }
    });
}

// Function to start the watchdog timer
function startWatchdog(timeout = DEFAULT_WATCHDOG_TIMEOUT, description = 'operation') {
    // Clear any existing watchdog timer
    stopWatchdog();
    
    // Check if bot is running before setting up watchdog
    chrome.storage.local.get(['botRunning'], function(data) {
        // Only start watchdog if bot is running
        if (!data.botRunning) {
            console.log('Bot is not running, skipping watchdog setup for: ' + description);
            return;
        }
        
        console.log(`Starting watchdog timer for ${description} (${timeout/1000} seconds)`);
        
        // Don't start a watchdog if we're in a refresh cycle
        if (typeof window.getCurrentRefreshCount === 'function' && window.getCurrentRefreshCount() > 0) {
            console.log('Skipping watchdog timer since we are in refresh cycle');
            return;
        }
        
        // Set a new timer
        watchdogTimer = setTimeout(() => {
            console.log(`WATCHDOG ALERT: Bot appears to be stuck during ${description}. Navigating back to All Available.`);
            // Navigate back to the all available page
            window.navigateToAllAvailableOrders();
        }, timeout);
    });
}

// Function to reset the watchdog timer (stop and start again)
function resetWatchdog(timeout = DEFAULT_WATCHDOG_TIMEOUT, description = 'operation') {
    stopWatchdog();
    startWatchdog(timeout, description);
}

// Function to stop the script and display a message
function stopScript(reason) {
    console.error('Process stopped: ' + reason);
}

// Function to simulate a full mouse event sequence on an element
function simulateFullClick(element) {
    if (!element) {
        console.error('No element found to click on!');
        return false;
    }

    try {
        console.log('Simulating full click on element:', element);
        
        // Try standard click first as it's most reliable
        element.click();
        
        // Then do the full event simulation
        ['mousedown', 'mouseup', 'click'].forEach(eventType => {
            try {
                const event = new MouseEvent(eventType, {
                    view: window,
                    bubbles: true,
                    cancelable: true
                });
                element.dispatchEvent(event);
            } catch (e) {
                console.error(`Error dispatching ${eventType} event:`, e);
            }
        });
        
        console.log('Click simulation completed');
        return true;
    } catch (e) {
        console.error('Error in click simulation:', e);
        return false;
    }
}

// Utility function for sleep
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Function to evaluate order criteria
function evaluateOrderCriteria() {
    return new Promise((resolve, reject) => {
        console.log('Starting order criteria evaluation...');
        
        // PRIORITY CHECK: Always look for a take button first before any criteria evaluation
        const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');
        if (takeButton) {
            console.log('TAKE BUTTON FOUND! Skipping criteria evaluation and clicking take button immediately!');
            // Resolve with valid=true to proceed directly to the bidding flow which will prioritize the take button
            return resolve({
                valid: true,
                reason: 'Take button available, skipping evaluation'
            });
        }
        
        // Get order criteria settings
        chrome.storage.local.get([
            'minDeadlineHours',
            'allowedServices',
            'maxSources',
            'maxPagesWords',
            'maxFiles',
            'excludedAssignmentTypes',
            'excludedSubjects'
        ], (settings) => {
            try {
                // Set default values according to user specifications
                settings.minDeadlineHours = settings.minDeadlineHours || 3; // Default: 3 hours
                settings.maxSources = settings.maxSources || 30; // Default: 30 sources
                settings.maxPagesWords = settings.maxPagesWords || 15; // Default: 15 pages
                settings.maxFiles = settings.maxFiles || 20; // Default: 20 files
                settings.allowedServices = settings.allowedServices || ['Academic paper writing'];
                settings.excludedAssignmentTypes = settings.excludedAssignmentTypes || [];
                settings.excludedSubjects = settings.excludedSubjects || [];

                console.log('⚙️ User settings:', settings);

                // Extract order details from DOM using the updated selectors

                // Service type - updated selector based on provided HTML
                const serviceEl = document.querySelector('div.order_inform_row[data-key="service_title"] .order_inform_value span');
                const serviceTitle = serviceEl ? serviceEl.textContent.trim() : null;
                console.log('📄 Service Title:', serviceTitle);

                // Assignment Type - updated selector to match assignment_type_title
                const assignmentTypeEl = document.querySelector('div.order_inform_row[data-key="assignment_type_title"] .order_inform_value span');
                const assignmentType = assignmentTypeEl ? assignmentTypeEl.textContent.trim() : null;
                console.log('📄 Assignment Type:', assignmentType);

                // Subject - updated selector to match skill_title
                const subjectEl = document.querySelector('div.order_inform_row[data-key="skill_title"] .order_inform_value span');
                const subject = subjectEl ? subjectEl.textContent.trim() : null;
                console.log('📄 Subject:', subject);

                // Pages/Words - selector already correct
                const pagesWordsEl = document.querySelector('div.order_inform_row[data-key="pages_words_num"] .order_inform_value span');
                const pagesText = pagesWordsEl ? pagesWordsEl.textContent.trim() : "0";
                // Parse both pages and words from format "11 / 3025"
                const pagesWordsMatch = pagesText.match(/(\d+)\s*\/\s*(\d+)/);
                const pages = pagesWordsMatch ? parseInt(pagesWordsMatch[1], 10) : 0;
                const words = pagesWordsMatch ? parseInt(pagesWordsMatch[2], 10) : 0;
                console.log('📄 Pages/Words:', pagesText, 'Parsed Pages:', pages, 'Words:', words);

                // Sources - selector already correct
                const sourcesEl = document.querySelector('div.order_inform_row[data-key="sources_num"] .order_inform_value span');
                const sourcesText = sourcesEl ? sourcesEl.textContent.trim() : "0";
                const sources = parseInt(sourcesText, 10) || 0;
                console.log('📄 Sources:', sources);

                // Files - updated to use the tabs_item with data-tab-anchor="files"
                const filesTabEl = document.querySelector('li.tabs_item[data-tab-anchor="files"] span');
                const filesCount = filesTabEl ? parseInt(filesTabEl.textContent.trim(), 10) : 0;
                console.log('📄 Attached Files:', filesCount);

                // Deadline - updated to use order_deadline_final
                const deadlineEl = document.querySelector('div.order_deadline_item.order_deadline_final p[ng-time]');
                let deadlineHours = 24; // Default
                
                if (deadlineEl) {
                    const deadlineText = deadlineEl.textContent.trim();
                    console.log('📄 Deadline Text:', deadlineText);
                    
                    // Try to extract deadline from ng-time attribute (more reliable)
                    const ngTimeAttr = deadlineEl.getAttribute('ng-time');
                    if (ngTimeAttr) {
                        try {
                            const deadlineDate = new Date(ngTimeAttr);
                            const now = new Date();
                            const diffMs = deadlineDate - now;
                            deadlineHours = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60)));
                            console.log('📄 Deadline from ng-time:', deadlineDate, 'Hours remaining:', deadlineHours);
                        } catch (e) {
                            console.error('Error parsing deadline date:', e);
                        }
                    }
                }

                // Evaluate against settings
                let isValid = true;
                let reason = "";

                // Check service type
                if (settings.allowedServices.length > 0 && (!serviceTitle || !settings.allowedServices.includes(serviceTitle))) {
                    isValid = false;
                    reason = `Service '${serviceTitle || "Unknown"}' not allowed`;
                    console.log('❌ Service type check failed:', reason);
                } 
                // Check deadline
                else if (deadlineHours < settings.minDeadlineHours) {
                    isValid = false;
                    reason = `Deadline (${deadlineHours}h) < min (${settings.minDeadlineHours}h)`;
                    console.log('❌ Deadline check failed:', reason);
                } 
                // Check pages/words
                else if (pages > settings.maxPagesWords) {
                    isValid = false;
                    reason = `Pages (${pages}) > max (${settings.maxPagesWords})`;
                    console.log('❌ Pages check failed:', reason);
                }
                // Check sources
                else if (sources > settings.maxSources) {
                    isValid = false;
                    reason = `Sources (${sources}) > max (${settings.maxSources})`;
                    console.log('❌ Sources check failed:', reason);
                }
                // Check files
                else if (filesCount > settings.maxFiles) {
                    isValid = false;
                    reason = `Files (${filesCount}) > max (${settings.maxFiles})`;
                    console.log('❌ Files check failed:', reason);
                }
                // Check assignment type
                else if (settings.excludedAssignmentTypes.length > 0 && assignmentType && 
                         settings.excludedAssignmentTypes.includes(assignmentType)) {
                    isValid = false;
                    reason = `Assignment type '${assignmentType}' is excluded`;
                    console.log('❌ Assignment type check failed:', reason);
                }
                // Check subject
                else if (settings.excludedSubjects.length > 0 && subject && 
                         settings.excludedSubjects.includes(subject)) {
                    isValid = false;
                    reason = `Subject '${subject}' is excluded`;
                    console.log('❌ Subject check failed:', reason);
                }

                console.log(`📊 Final evaluation result: ${isValid ? '✅ Valid' : '❌ Rejected'} - ${reason || 'All criteria met'}`);
                resolve({ valid: isValid, reason: reason || 'All criteria met' });
            } catch (error) {
                console.error('❌ Error in evaluation:', error);
                reject(error);
            }
        });
    });
}

// Function to check if Take button is present before proceeding with bidding flow
function checkForTakeButtonBeforeBiddingFlow() {
    // First check if we're on an actual order page (not all_available)
    if (!window.location.href.match(/\/writer\/orders\/\d+/) || 
        window.location.href.includes('/all_available') || 
        window.location.href.includes('/top_offers')) {
        console.log('Not on an individual order page, skipping take button check');
        return false;
    }
    
    console.log('Checking if Take button is available...');
    
    // Use the precise selector for the Take button
    const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');
    
    if (takeButton) {
        console.log('Take button found! Clicking it immediately...');
        // Show success indicator
        showResultIndicator(true, 'Take button found!');
        
        // Extract order ID
        const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
        const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
        
        // Click the button
        clickElementWithMultipleMethods(takeButton);
        
        // Look for confirmation button
        console.log('Starting confirmation button detection...');
        
        // Use single exact selector for confirmation button
        const confirmButtonSelectors = [
            'button.btn.btn_green.confirm_button[type="button"]'
        ];
        
        // Use recursion for active polling
        function checkForConfirmationButton(attempts = 0, maxAttempts = 50) {
            for (const selector of confirmButtonSelectors) {
                const confirmButton = document.querySelector(selector);
                if (confirmButton) {
                    console.log(`Confirmation button found! Clicking immediately...`);
                    clickElementWithMultipleMethods(confirmButton);
                    
                    // Wait 4 seconds before navigating back
                    setTimeout(() => {
                        console.log('Order taken successfully!');
                        showResultIndicator(true, 'Order successfully taken!');
                        
                        // Notify background
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: true,
                            orderUrl: window.location.href,
                            orderId: orderId,
                            reasons: 'Order successfully taken'
                        });
                        
                        // Navigate back after 4 seconds
                        setTimeout(() => {
                            console.log('Returning to All Available...');
                            window.navigateToAllAvailableOrders();
                        }, 4000);
                    }, 1000);
                    
                    return; // Exit after finding and clicking confirmation
                }
            }
            
            // Continue checking if we haven't found the button yet and haven't exceeded max attempts
            if (attempts < maxAttempts) {
                setTimeout(() => {
                    checkForConfirmationButton(attempts + 1, maxAttempts);
                }, 10);
            }
        }
        
        // Start checking for confirmation button
        checkForConfirmationButton();
        return true;
    }
    
    return false; // No take button found
}

// Helper function to click an element using multiple methods for maximum reliability
function clickElementWithMultipleMethods(element) {
    if (!element) {
        console.error('No element provided to click');
        return false;
    }
    
    console.log('Using multiple methods to ensure element is clicked reliably');
    
    // Method 1: Direct click()
    try {
        element.click();
        console.log('Method 1: Direct click() executed');
    } catch (e) {
        console.error('Method 1 failed:', e);
    }
    
    // Method 2: simulateFullClick
    try {
        simulateFullClick(element);
        console.log('Method 2: simulateFullClick executed');
    } catch (e) {
        console.error('Method 2 failed:', e);
    }
    
    // Method 3: Direct DOM events
    try {
        ['mousedown', 'mouseup', 'click'].forEach(eventType => {
            const event = new MouseEvent(eventType, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1
            });
            element.dispatchEvent(event);
        });
        console.log('Method 3: Direct DOM events executed');
    } catch (e) {
        console.error('Method 3 failed:', e);
    }
    
    // Method 4: Focus and Enter key
    try {
        element.focus();
        const keyEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
        });
        element.dispatchEvent(keyEvent);
        console.log('Method 4: Focus and Enter key executed');
    } catch (e) {
        console.error('Method 4 failed:', e);
    }
    
    return true;
}

// Function to show a visual indicator during order evaluation
function showOrderEvaluationIndicator() {
    // Empty implementation
}

// Function to show result indicator for order evaluation
function showResultIndicator(accepted, message) {
    // Empty implementation
}

// Make the message handler more robust for the startBidding action
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Content script received message:', request.action, request);
    
    // First handle the startBidding action (which explicitly starts the bot)
    if (request.action === 'startBidding') {
        console.log('📢 Received startBidding command from background/popup script', request);
        console.log('Current URL:', window.location.href);
        
        // Immediately acknowledge receipt of message to prevent communication errors
        sendResponse({ status: 'Message received, starting bidding process immediately', success: true });
        
        // IMPORTANT: Force stop any existing monitoring first to avoid duplicates
        if (typeof stopOrderMonitoring === 'function') {
            stopOrderMonitoring();
        }
        
        // Set botRunning to true BEFORE starting monitoring
        chrome.storage.local.set({ botRunning: true }, function() {
            console.log('✅ Set botRunning to TRUE');
            
            if (window.location.href.includes('/writer/orders/all_available')) {
                // Start monitoring immediately - no delay
                console.log('🚀 STARTING ORDER MONITORING NOW!');
                startOrderMonitoring();
                console.log('✅ Order monitoring started successfully');
                
                
                // Add visual confirmation for user
                showStartBiddingConfirmation();
            } else {
                console.log('⚠️ Not on All Available Orders page, navigating there...');
                
                // Navigate to all_available with URL parameters to trigger immediate start
                // Add timestamp to prevent caching
                window.location.href = 'https://www.writershub.org/writer/orders/all_available?startMonitoring=true&source=startBidding&t=' + Date.now();
            }
        });
        
        return true; // Keep message port open for async response
    }
    // For stopBot, always process it
    else if (request.action === 'stopBot') {
        console.log('Received stopBot command from popup/background');
        stopAllBotActivities();
        sendResponse({ status: 'stopped' });
        return true;
    }
    // For most other commands, check if bot is running before processing
    else {
        // Special cases that should always be processed
        const alwaysProcessActions = ['checkForTakeButton', 'isManagingOwnRefreshes', 'pageLoadComplete'];
        
        if (!alwaysProcessActions.includes(request.action)) {
            // Check bot status before processing other commands
            chrome.storage.local.get(['botRunning'], function(data) {
                // If bot is not running, skip most actions to avoid interfering with normal website usage
                if (!data.botRunning) {
                    console.log(`Bot is not running, skipping action: ${request.action}`);
                    sendResponse({ status: 'ignored', message: 'Bot is not running' });
                    return;
                }
                
                // Process the message since bot is running
                processMessage(request, sendResponse);
            });
        } else {
            // Process special actions that should always run
            processMessage(request, sendResponse);
        }
        
        return true; // Keep message port open for async response
    }
    
    // Helper function to process messages based on action
    function processMessage(request, sendResponse) {
        switch (request.action) {
            case 'processOrder':
                console.log('📣 Received processOrder command from background script');
                console.log('Current URL when processOrder received:', window.location.href);
                console.log('Current DOM ready state:', document.readyState);
                
                // Check if we're on an order page
                if (!window.location.href.match(/\/writer\/orders\/\d+/)) {
                    console.error('⚠️ Not on an order page! URL:', window.location.href);
                    sendResponse({ status: 'Error: Not on an order page' });
                    // Notify background about failed processing to reset state
                    chrome.runtime.sendMessage({
                        action: 'orderProcessingComplete',
                        metCriteria: false,
                        orderUrl: window.location.href,
                        orderId: null,
                        reasons: 'Not on a valid order page'
                    });
                    return;
                }

                // Process order code continues... (unchanged)
                break;
                
            case 'navigateToAllAvailable':
                console.log('Received navigation command from background script');
                window.navigateToAllAvailableOrders();
                sendResponse({ status: 'navigating' });
                break;
                
            case 'checkForTakeButton':
                // This is time-sensitive and should always be processed
                console.log('Received checkForTakeButton command');
                if (typeof checkForTakeButtonBeforeBiddingFlow === 'function') {
                    checkForTakeButtonBeforeBiddingFlow();
                    sendResponse({ status: 'checking' });
                } else {
                    sendResponse({ status: 'function not available' });
                }
                break;
            
            case 'pageLoadComplete':
                console.log('Page load complete notification received');
                sendResponse({ status: 'acknowledged' });
                break;
            
            case 'isManagingOwnRefreshes':
                // Always respond to this configuration query
                sendResponse({ managingOwnRefreshes: false });
                break;
            
            case 'backgroundMonitoringStopped':
                console.log('Background monitoring stopped notification received');
                sendResponse({ status: 'acknowledged' });
                break;
            
            case 'startTakeButtonMonitoring':
                console.log('Received startTakeButtonMonitoring from recaptchaCheck, delegating to takeButtonDetector');
                // Simply forward this to the takeButtonDetector which should handle it via its own message listener
                sessionStorage.setItem('takeButtonMonitoringActive', 'true');
                if (typeof window.refreshAndLookForTakeButton === 'function') {
                    window.refreshAndLookForTakeButton();
                    sendResponse({ success: true, message: 'Take button monitoring started via content.js' });
                } else {
                    console.error('refreshAndLookForTakeButton function not available in window object');
                    sendResponse({ success: false, error: 'refreshAndLookForTakeButton function not available' });
                }
                break;
            
            default:
                console.log('Unknown message action:', request.action);
                sendResponse({ status: 'unknown action' });
        }
    }
});

// Helper function to show a visual confirmation that bidding has started
function showStartBiddingConfirmation() {
    // Create a notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #28a745;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        z-index: 10001;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
        animation: fade-in-out 5s forwards;
    `;
    
    // Add animation keyframes
    if (!document.getElementById('notification-animation')) {
        const style = document.createElement('style');
        style.id = 'notification-animation';
        style.textContent = `
            @keyframes fade-in-out {
                0% { opacity: 0; transform: translate(-50%, -20px); }
                10% { opacity: 1; transform: translate(-50%, 0); }
                80% { opacity: 1; }
                100% { opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
    
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 24px;">🚀</span>
            <span>Bidding Started! Monitoring for available orders...</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after animation completes
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Improved version of clickOrderRowByDom with more aggressive order detection
function clickOrderRowByDom() {
    console.log('🎯 Attempting direct click on order table row by DOM structure');
    
    // CRITICAL: First verify we're on the all_available page
    if (!window.location.href.includes('/writer/orders/all_available')) {
        console.log('⚠️ Not on all_available page, skipping order click');
        return Promise.resolve(false);
    }
    
    // Extra verification: check for the "All Available Orders" table
    const allAvailableTable = document.querySelector('.orders_table.all_available_orders_table');
    if (!allAvailableTable) {
        console.log('⚠️ Could not find the All Available Orders table on the page');
        return Promise.resolve(false);
    }
    
    console.log('✅ Confirmed we are on the all_available page with the correct table');
    
    // Extended list of selectors to catch more order formats
    const orderSelectors = [
        // Main Angular selectors
        'a.table_row.ng-scope.renewed[href*="/writer/orders/"]',
        'a.table_row.ng-scope[href*="/writer/orders/"]',
        'a.table_row.ng-scope[ng-repeat="order in orders"]',
        // Additional selectors to catch more order formats
        'a[href*="/writer/orders/"][class*="table_row"]',
        'a[href*="/writer/orders/"]:not([href*="all_available"]):not([href*="top_offers"])',
        // Generic but filtered to only include valid order links
        'a[href*="/writer/orders/"]'
    ];
    
    // Try each selector and collect all potential orders - only from the All Available table
    let allOrderRows = [];
    
    // Test all selectors and collect results
    for (const selector of orderSelectors) {
        try {
        const rows = allAvailableTable.querySelectorAll(selector);
            if (rows && rows.length > 0) {
                console.log(`Found ${rows.length} potential order rows with selector: ${selector}`);
                // Convert NodeList to Array and filter out navigation links
                Array.from(rows).forEach(row => {
                const href = row.getAttribute('href');
                    if (href && 
                        !href.includes('/all_available') && 
                        !href.includes('/top_offers') && 
                        !href.includes('/pending') && 
                        !href.includes('/in_process')) {
                        allOrderRows.push(row);
                    }
                });
            }
        } catch (error) {
            console.error(`Error with selector ${selector}:`, error);
        }
    }
    
    // Log the total count after filtering
    console.log(`Found ${allOrderRows.length} valid order rows after filtering duplicates and navigation links`);
    
    if (allOrderRows.length === 0) {
        console.log('❌ No order rows found in the all_available table with any selector');
        return Promise.resolve(false);
    }
    
    // Return a Promise to handle async operations
    return new Promise((resolve) => {
        // Get the currently processed orders
        chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], function(data) {
            const processedIds = data.processedOrderIds || [];
            const processedUrls = data.processedOrderUrls || [];
            
            console.log(`Checking against ${processedIds.length} processed IDs and ${processedUrls.length} processed URLs`);
            
            // Filter to only unprocessed orders
            const unprocessedRows = [];
            
            for (let i = 0; i < allOrderRows.length; i++) {
                const row = allOrderRows[i];
                const href = row.getAttribute('href');
                
                // Skip navigation links - we only want actual order links
                if (!href || 
                    href.includes('/all_available') || 
                    href.includes('/top_offers') || 
                    href.includes('/pending') || 
                    href.includes('/in_process')) {
                    continue;
                }
                
                // Extract order ID
                const idMatch = href.match(/\/writer\/orders\/(\d+)/);
                if (!idMatch || !idMatch[1]) {
                    console.log(`Could not extract order ID from URL: ${href}`);
                    continue;
                }
                
                const orderId = idMatch[1];
                
                // Make the URL absolute for consistent checking
                const absoluteUrl = href.startsWith('http') ? href : 
                     (href.startsWith('/') ? window.location.origin + href : 
                     window.location.origin + '/' + href);
        
                // Check if this order has been processed already
                const isProcessed = processedIds.includes(orderId) || 
                                   processedUrls.includes(href) || 
                                   processedUrls.includes(absoluteUrl);
                
                if (!isProcessed) {
                    console.log(`Found unprocessed order with ID ${orderId}`);
                    unprocessedRows.push({ 
                        row, 
                        orderId, 
                        href: absoluteUrl 
                    });
                }
            }
            
            if (unprocessedRows.length === 0) {
                console.log('No unprocessed orders found');
                resolve(false);
                return;
            }
            
            console.log(`Found ${unprocessedRows.length} unprocessed orders, selecting one...`);
            
            // Randomly select an order
            const randomIndex = Math.floor(Math.random() * unprocessedRows.length);
            const selected = unprocessedRows[randomIndex];
            
            console.log(`Selected order ${randomIndex + 1} of ${unprocessedRows.length}: ID=${selected.orderId}`);
            
            // Execute a click on the element with multiple fallbacks for reliability
            try {
                console.log(`Clicking order with ID: ${selected.orderId}`);
                
                // First mark this order as processed to prevent reopening
                manageProcessedOrders(selected.orderId, 'add');
                
                // More reliable click approach using both methods
                simulateFullClick(selected.row);
                
                // Also use direct location change as backup
                setTimeout(() => {
                    if (window.location.href.includes('/all_available')) {
                        console.log('First click attempt didn\'t navigate, trying direct navigation');
                        window.location.href = selected.href;
                    }
                    resolve(true);
                }, 300);  // Reduced timeout for faster response
            } catch (error) {
                console.error('Error clicking order row:', error);
                
                // Fallback: try direct navigation
                console.log('Error in click, using direct navigation fallback');
                window.location.href = selected.href;
                resolve(true);
            }
        });
    });
}

// Helper function to visually highlight an element for debugging
function highlightElementForDebug(element) {
    // Empty implementation
}

// Direct click function targeting the exact order structure
function clickExactOrderRow() {
    console.log('🎯 DIRECT ORDER CLICK: Targeting exact order row structure');
    
    // CRITICAL: First verify we're on the all_available page, not pending/top_offers/etc.
    if (!window.location.href.includes('/writer/orders/all_available')) {
        console.log('⚠️ Not on all_available page, currently on: ' + window.location.href);
        console.log('⚠️ Will not attempt to click order - only process from all_available page');
        return Promise.resolve(false);
    }
    
    // Target the exact Angular structure provided
    const selectors = [
        // First try with the exact renewed class as shown in the example
        'a.table_row.ng-scope.renewed[href*="/writer/orders/"]',
        // Then try without renewed class (for visited orders)
        'a.table_row.ng-scope[href*="/writer/orders/"]',
        // Then try with ng-repeat attribute
        'a.table_row.ng-scope[ng-repeat="order in orders"]',
        // Finally fall back to basic selector
        'a.table_row[href*="/writer/orders/"]'
    ];
    
    // Find the All Available Orders table specifically
    const allAvailableTable = document.querySelector('.orders_table.all_available_orders_table');
    if (!allAvailableTable) {
        console.log('⚠️ Could not find the All Available Orders table');
        return Promise.resolve(false);
    }
    
    console.log('✅ Found the All Available Orders table');
    
    let validOrderRows = [];
    
    // Try each selector in order until we find matches - target only orders in the All Available table
    for (const selector of selectors) {
        const elements = allAvailableTable.querySelectorAll(selector);
        if (elements && elements.length > 0) {
            console.log(`✅ DIRECT ORDER CLICK: Found ${elements.length} orders with selector: ${selector}`);
            
            // Filter out navigation links - only include actual order links
            for (const element of elements) {
                const href = element.getAttribute('href');
                // Skip navigation links - we only want actual order links
                // This avoids clicking on links to all_available, top_offers, pending, in_process
                if (href && !href.includes('/all_available') && !href.includes('/top_offers') &&
                    !href.includes('/pending') && !href.includes('/in_process')) {
                    validOrderRows.push(element);
                } else {
                    console.log(`Skipping navigation link: ${href || 'unknown'} - this is not an order`);
                }
            }
            
            if (validOrderRows.length > 0) {
                console.log(`Found ${validOrderRows.length} valid order rows to check for unprocessed orders`);
                break;
            }
        }
    }
    
    if (validOrderRows.length === 0) {
        console.log('❌ DIRECT ORDER CLICK: No matching order row found');
        return Promise.resolve(false);
    }
    
    // Return a Promise to handle async operations
    return new Promise((resolve) => {
        // Get the currently processed orders
        chrome.storage.local.get(['processedOrderIds', 'processedOrderUrls'], function(data) {
            const processedIds = data.processedOrderIds || [];
            const processedUrls = data.processedOrderUrls || [];
            
            console.log(`Checking against ${processedIds.length} processed IDs and ${processedUrls.length} processed URLs`);
            
            // Filter to only unprocessed orders
            const unprocessedRows = [];
            
            for (let i = 0; i < validOrderRows.length; i++) {
                const row = validOrderRows[i];
                const href = row.getAttribute('href');
                
                // Extract order ID from URL
                const idMatch = href.match(/\/writer\/orders\/(\d+)/);
                if (!idMatch || !idMatch[1]) {
                    console.log(`Could not extract order ID from URL: ${href}`);
                    continue;
                }
                
                const orderId = idMatch[1];
                
                // Make URL absolute for consistent checking
                const absoluteUrl = href.startsWith('http') ? href : 
                    (href.startsWith('/') ? window.location.origin + href : 
                    window.location.origin + '/' + href);
                
                // Check if this order has been processed already
                const isProcessed = processedIds.includes(orderId) || 
                                   processedUrls.includes(href) || 
                                   processedUrls.includes(absoluteUrl);
                
                if (!isProcessed) {
                    console.log(`Found unprocessed order with ID ${orderId}, URL: ${absoluteUrl}`);
                    unprocessedRows.push({ 
                        row, 
                        orderId, 
                        href: absoluteUrl 
                    });
                } else {
                    console.log(`Skipping already processed order with ID ${orderId}`);
                }
            }
            
            // If no unprocessed orders found, return false
            if (unprocessedRows.length === 0) {
                console.log('❌ No unprocessed order rows found - all orders have been processed');
                resolve(false);
                return;
            }
            
            // Randomly select an order from the unprocessed ones
            const randomIndex = Math.floor(Math.random() * unprocessedRows.length);
            const selected = unprocessedRows[randomIndex];
            
            // Get the href and ID
            console.log(`✅ DIRECT ORDER CLICK: Randomly selected order ${randomIndex+1} of ${unprocessedRows.length} with ID: ${selected.orderId}`);
            
            // First mark as processed to prevent reopening
            manageProcessedOrders(selected.orderId, 'add');
            
            // Click the order row with a forced click
            simulateFullClick(selected.row);
            
            // Add a fallback in case the click doesn't navigate
            setTimeout(() => {
                // If we're still on the all_available page, try direct navigation
                if (window.location.href.includes('/all_available')) {
                    console.log('Click did not navigate, trying direct URL navigation');
                    window.location.href = selected.href;
                }
                resolve(true);
            }, 300); // Use 300ms timeout for faster response
        });
    });
}

// Function to check for and handle order page detection
function checkForOrderPage() {
    // First check if we're on an actual order page (not all_available)
    if (!window.location.href.match(/\/writer\/orders\/\d+/) || 
        window.location.href.includes('/all_available') || 
        window.location.href.includes('/top_offers')) {
        console.log('Not on an individual order page, skipping take button checks and evaluation');
        return false;
    }
    
    console.log('On individual order page, checking for take button and evaluating criteria');
    
    // First, always check if a take button is present - this has highest priority
    const takeButtonFound = checkForTakeButtonBeforeBiddingFlow();
    
    if (takeButtonFound) {
        console.log('Take button found and clicked immediately on page load');
        return true; // Exit early if take button was found and clicked
    }
    
    // If no take button initially, start monitoring for it continuously
    console.log('No take button found initially, starting continuous monitoring...');
    
    // Start continuous monitoring for take button
    startContinuousTakeButtonMonitoring();
    
    // Extract the order ID if available
    const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
    const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
    
    // Check if bot is running
        chrome.storage.local.get(['botRunning'], function(data) {
            if (!data.botRunning) {
            console.log('Bot is not running, skipping order evaluation');
                return;
            }
            
        console.log('Bot is running, proceeding with order evaluation');
            showOrderEvaluationIndicator();

        // Set a timeout to prevent being stuck on the order page
            const evaluationTimeout = setTimeout(() => {
                console.error('⚠️ Timeout during order evaluation, aborting and returning to All Available');
            // Stop the continuous monitoring
            stopContinuousTakeButtonMonitoring();

            // Add order to processed list to prevent reopening
                chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
                    const processedUrls = data.processedOrderUrls || [];
                    const processedIds = data.processedOrderIds || [];
                    
                    // Add current URL to processed list if not already there
                    if (!processedUrls.includes(window.location.href)) {
                        processedUrls.push(window.location.href);
                    }
                    
                    // Add order ID to processed list if available and not already there
                    if (orderId && !processedIds.includes(orderId)) {
                        processedIds.push(orderId);
                    }
                    
                    // Save the updated lists
                    chrome.storage.local.set({
                        processedOrderUrls: processedUrls,
                        processedOrderIds: processedIds
                    }, function() {
                        console.log(`✅ Added timed out order to tracked list - URL: ${window.location.href}, ID: ${orderId || 'unknown'}`);
                        console.log(`✅ Total tracked orders: URLs=${processedUrls.length}, IDs=${processedIds.length}`);
                        
                        // Notify background about timeout
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: false,
                            orderUrl: window.location.href,
                            orderId: orderId,
                            reasons: 'Evaluation timeout'
                        });

                        // Navigate back to all available
                        window.navigateToAllAvailableOrders();
                    });
                });
        }, 20000);

        // Process to check order criteria
            const proceedWithEvaluation = () => {
            // Evaluate the order against criteria
                evaluateOrderCriteria().then(result => {
                    // Clear timeout since evaluation completed
                    clearTimeout(evaluationTimeout);

                    if (result.valid) {
                    console.log('✅ Order meets criteria, proceeding with bid');
                    
                    // Always check for take button again before proceeding - in case it appeared during evaluation
                    if (checkForTakeButtonBeforeBiddingFlow()) {
                        // If take button was found and clicked, we're done
                        console.log('Take button appeared during evaluation and was clicked');
                        // Stop the continuous monitoring since we clicked the take button
                        stopContinuousTakeButtonMonitoring();
                        return;
                    }
                    
                    // Continue continuous monitoring for take button while proceeding with normal bidding flow
                    console.log('No take button found, continuing with normal bidding flow while monitoring');
                    
                    // Show success indicator
                    showResultIndicator(true, result.reason || 'Order meets criteria!');
                    
                    // Check for Black Place Bid button
                    const blackPlaceBidButton = document.querySelector('a.btn.btn_black.place_bid.dialog[href="#place_bid_popup"]');
                    
                    if (blackPlaceBidButton) {
                        // Click the black Place Bid button
                        console.log('Clicking black Place Bid button...');
                        simulateFullClick(blackPlaceBidButton);
                        
                        // Use the recaptchaCheck module to handle verification and bidding
                        window.recaptchaCheck.checkAndProceed();
                    } else {
                        console.error('Black Place Bid button not found!');
                        
                        // Notify background about error
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: false,
                            orderUrl: window.location.href,
                            orderId: orderId,
                            reasons: 'Black Place Bid button not found'
                        });
                        
                        // Stop the continuous monitoring since we're returning to All Available
                        stopContinuousTakeButtonMonitoring();
                        
                        // Return to all available orders
                        setTimeout(() => {
                            window.navigateToAllAvailableOrders();
                        }, 1500);
                    }
                    } else {
                        console.log('❌ Order does not meet criteria, returning to all available');

                        // Show rejection indicator
                        showResultIndicator(false, result.reason);

                        // Add the rejected order to the processedOrderUrls list to prevent reopening
                        chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
                            const processedUrls = data.processedOrderUrls || [];
                            const processedIds = data.processedOrderIds || [];
                            
                            // Add current URL to processed list if not already there
                            if (!processedUrls.includes(window.location.href)) {
                                processedUrls.push(window.location.href);
                            }
                            
                            // Add order ID to processed list if available and not already there
                            if (orderId && !processedIds.includes(orderId)) {
                                processedIds.push(orderId);
                            }
                            
                            // Save the updated lists
                            chrome.storage.local.set({
                                processedOrderUrls: processedUrls,
                                processedOrderIds: processedIds
                            }, function() {
                                console.log(`✅ Added rejected order to tracked list - URL: ${window.location.href}, ID: ${orderId || 'unknown'}`);
                                console.log(`✅ Total tracked orders: URLs=${processedUrls.length}, IDs=${processedIds.length}`);
                            });
                        });

                    // Notify background about rejection
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: false,
                            orderUrl: window.location.href,
                            orderId: orderId,
                            reasons: result.reason
                        });

                    // Stop the continuous monitoring since we're returning to All Available
                    stopContinuousTakeButtonMonitoring();

                        // Wait a moment to let the user see the rejection reason
                        setTimeout(() => {
                            window.navigateToAllAvailableOrders();
                        }, 2000);
                    }
                }).catch(error => {
                    console.error('Error during order evaluation:', error);
                    clearTimeout(evaluationTimeout);
                
                // Stop the continuous monitoring since there was an error
                stopContinuousTakeButtonMonitoring();

                    // Add order with error to the processedOrderUrls list to prevent reopening
                    chrome.storage.local.get(['processedOrderUrls', 'processedOrderIds'], function(data) {
                        const processedUrls = data.processedOrderUrls || [];
                        const processedIds = data.processedOrderIds || [];
                        
                        // Add current URL to processed list if not already there
                        if (!processedUrls.includes(window.location.href)) {
                            processedUrls.push(window.location.href);
                        }
                        
                        // Add order ID to processed list if available and not already there
                        if (orderId && !processedIds.includes(orderId)) {
                            processedIds.push(orderId);
                        }
                        
                        // Save the updated lists
                        chrome.storage.local.set({
                            processedOrderUrls: processedUrls,
                            processedOrderIds: processedIds
                        }, function() {
                            console.log(`✅ Added failed order to tracked list - URL: ${window.location.href}, ID: ${orderId || 'unknown'}`);
                            console.log(`✅ Total tracked orders: URLs=${processedUrls.length}, IDs=${processedIds.length}`);
                        });
                    });

                    // Notify background about error
                    chrome.runtime.sendMessage({
                        action: 'orderProcessingComplete',
                        metCriteria: false,
                        orderUrl: window.location.href,
                        orderId: orderId,
                        reasons: 'Error evaluating order: ' + error.message
                    });

                    // Navigate back on error
                    window.navigateToAllAvailableOrders();
                });
            };

        // Allow a short delay to give UI time to render before evaluation
        setTimeout(proceedWithEvaluation, 1000);
    });
}

// Run the check immediately for cases where the page is already loaded
checkForOrderPage();

// Listen for URL changes (Single Page Apps sometimes change URL without full page load)
const urlChangeObserver = new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        console.log('URL changed to:', currentUrl);
        checkForOrderPage();
    }
});

let lastUrl = window.location.href;
urlChangeObserver.observe(document, {subtree: true, childList: true});

// Handle different element formats
// ... existing code...

// Function to navigate to All Available Orders page
window.navigateToAllAvailableOrders = function() {
    // First check if bot is running - only navigate if bot is running
    chrome.storage.local.get(['botRunning'], function(data) {
        if (!data.botRunning) {
            console.log('Bot is stopped - will not perform automatic navigation');
            return;
        }
        
        // Check all relevant monitoring flags
        const isMonitoringActive = sessionStorage.getItem('takeButtonMonitoringActive') === 'true';
        const isCountdownActive = sessionStorage.getItem('takeCountdownActive') === 'true';
        const isTakingOrder = sessionStorage.getItem('takingOrder') === 'true';
        const currentCount = parseInt(sessionStorage.getItem('takeButtonRefreshCount') || '0');
        
        console.log(`Navigation check - Monitoring: ${isMonitoringActive}, Countdown: ${isCountdownActive}, Taking: ${isTakingOrder}, Count: ${currentCount}`);
        
        // If any active monitoring is happening, don't navigate unless the count is zero
        if (isMonitoringActive || isCountdownActive || isTakingOrder) {
            console.log('🛑 Preventing navigation during take button monitoring - staying on current page');
            
            // Only navigate when countdown is complete (reaches 0)
            if (currentCount <= 0) {
                console.log('✅ Countdown has reached zero, now navigating to All Available');
                // Clear all flags
                sessionStorage.removeItem('takeCountdownActive');
                sessionStorage.removeItem('takingOrder');
                sessionStorage.removeItem('takeButtonMonitoringActive');
                console.log('Navigating to All Available Orders page...');
                window.location.href = "/writer/orders/all_available";
            } else {
                console.log(`⏱️ Still in countdown (${currentCount} seconds remaining), staying on page`);
                return; // Important: return early to prevent navigation
            }
        } else {
            console.log('No active monitoring detected, navigating to All Available Orders page...');
            window.location.href = "/writer/orders/all_available";
        }
    });
};

// Helper function to find the order container (moved to global scope to fix reference error)
function findOrderContainer() {
    console.log('Looking for order container...');
    return new Promise((resolve) => {
    const selectors = [
        '.table_body',
            '.orders_table.all_available_orders_table',
        '.orders_table',
        '.table-body',
        'table.orders_table tbody',
        'div[ng-repeat="order in orders"]',
        'div[ng-repeat="order in filteredOrders"]'
    ];
    
        // Try each selector
    for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
            console.log('Found order container with selector:', selector);
                return resolve(element);
            }
        }
        
        // If element not found immediately, try again after a short delay
        // This helps with slower page loads
        setTimeout(() => {
            for (const selector of selectors) {
                const element = document.querySelector(selector);
                if (element) {
                    console.log('Found order container with selector (delayed):', selector);
                    return resolve(element);
                }
            }
            console.log('Could not find order container after retry');
            resolve(null);
        }, 500);
    });
}

// Helper function to start monitoring once container is found (moved to global scope)
function startMonitoringWithContainer(tableBody) {
    if (!tableBody) {
        console.error('Could not find order container, falling back to interval-based monitoring');
        setupRefreshMonitoring();
        return;
    }
    
    // Create an observer instance
    const observer = new MutationObserver(async (mutations) => {
        for (const mutation of mutations) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        console.log('New element detected in order list:', node);
                        
                        // If the element itself is an order row
                        if (node.matches('a.table_row.ng-scope') || 
                            node.matches('.table_row[ng-repeat="order in orders"]') ||
                            node.matches('a[href*="/writer/orders/"]')) {
                            const processed = await processSingleOrderElement(node);
                            if (processed) {
                                // Disconnect the observer if we processed an order
                                observer.disconnect();
                                return;
                            }
                        }
                        
                        // Check for order elements inside the added node
                        const orderElements = node.querySelectorAll('a.table_row.ng-scope, .table_row[ng-repeat="order in orders"], a[href*="/writer/orders/"]');
                        for (const orderElement of orderElements) {
                            const processed = await processSingleOrderElement(orderElement);
                            if (processed) {
                                // Disconnect the observer if we processed an order
                                observer.disconnect();
                                return;
                            }
                        }
                    }
                }
            }
        }
    });
    
    // Start observing the target node for configured mutations
    observer.observe(tableBody, { 
        childList: true,
        subtree: true 
    });
    
    console.log('MutationObserver set up to watch for new orders in', tableBody);
    
    // Store the observer in a global variable so we can disconnect it later
    window.orderObserver = observer;
    
    // Still set up refresh monitoring as a fallback
    setupRefreshMonitoring();
}

// Helper function to set up refresh-based monitoring (moved to global scope)
function setupRefreshMonitoring() {
    console.log('Setting up refresh-based monitoring as fallback');
    
    // Schedule the next refresh
    orderMonitoringInterval = setTimeout(() => {
        // Check if we're still on the all available page
        if (!window.location.href.includes('/writer/orders/all_available')) {
            console.log('No longer on All Available Orders page, stopping monitoring');
            stopOrderMonitoring();
            return;
        }
        
        orderRefreshCount++;
        console.log(`Order Monitoring: Performing visible refresh #${orderRefreshCount}`);
        
        // If we've reached the max refresh count, reset by navigating
        if (orderRefreshCount >= MAX_ORDER_REFRESH_COUNT) {
            console.log(`Reached max refresh count (${MAX_ORDER_REFRESH_COUNT}), refreshing page and resetting count`);
            orderRefreshCount = 0;
            sessionStorage.setItem('orderRefreshCount', '0');
        }
        
        // Update count in session storage
        sessionStorage.setItem('orderRefreshCount', orderRefreshCount.toString());
        
        // Reset watchdog timer on each successful scan
        resetWatchdog(180000, 'order monitoring');
        
        // Update last refresh time
        sessionStorage.setItem('lastOrderRefreshTime', Date.now().toString());
        
        // Do a full page reload
        window.location.reload();
    }, ORDER_REFRESH_INTERVAL);
}

// Helper function to highlight the selected order visually
function highlightSelectedOrder(element) {
    if (!element) return;
    
    // Store original styles
    const originalBorder = element.style.border;
    const originalBackground = element.style.background;
    
    // Apply highlight
    element.style.border = '3px solid #ff9900';
    element.style.background = 'rgba(255, 153, 0, 0.1)';
    
    // Add a floating label to show this is being clicked
    const label = document.createElement('div');
    label.textContent = '🎯 SELECTED ORDER';
    label.style.position = 'absolute';
    label.style.top = '-25px';
    label.style.right = '10px';
    label.style.background = '#ff9900';
    label.style.color = 'white';
    label.style.padding = '3px 6px';
    label.style.borderRadius = '4px';
    label.style.fontWeight = 'bold';
    label.style.zIndex = '9999';
    
    // Make sure the element has position relative for proper label positioning
    if (window.getComputedStyle(element).position === 'static') {
        element.style.position = 'relative';
    }
    
    element.appendChild(label);
    
    // Reset after a timeout
    setTimeout(() => {
        element.style.border = originalBorder;
        element.style.background = originalBackground;
        try {
            element.removeChild(label);
        } catch (e) {
            // Ignore if label already removed
        }
    }, 5000);
}

// Function to simulate a full mouse event sequence on an element with random delays
function simulateFullClick(element) {
    if (!element) {
        console.error('No element found to click on!');
        return false;
    }

    try {
        console.log('Simulating full click sequence on element:', element);
        
        // Define mouse event sequence with realistic random delays
        const events = [
            { type: 'mouseover', delay: Math.floor(Math.random() * 50 + 30) },
            { type: 'mousedown', delay: Math.floor(Math.random() * 70 + 50) },
            { type: 'mouseup', delay: Math.floor(Math.random() * 50 + 30) },
            { type: 'click', delay: 0 }
        ];
        
        // Dispatch each event in sequence with random delays
        let totalDelay = 0;
        
        events.forEach(event => {
            totalDelay += event.delay;
            
            setTimeout(() => {
                try {
                    const mouseEvent = new MouseEvent(event.type, {
                        view: window,
                        bubbles: true,
                        cancelable: true,
                        clientX: Math.floor(Math.random() * 10) + element.getBoundingClientRect().left + 5,
                        clientY: Math.floor(Math.random() * 10) + element.getBoundingClientRect().top + 5
                    });
                    element.dispatchEvent(mouseEvent);
                    console.log(`Dispatched ${event.type} event`);
                } catch (e) {
                    console.error(`Error dispatching ${event.type} event:`, e);
                }
            }, totalDelay);
        });
        
        console.log('Click simulation sequence initiated');
        return true;
    } catch (e) {
        console.error('Error in click simulation:', e);
        return false;
    }
}

// Function to manage processed orders
function manageProcessedOrders(orderId, action) {
    return new Promise((resolve) => {
        // Get the current list of processed orders
        chrome.storage.local.get(['processedOrderIds'], function(data) {
            let processedOrders = data.processedOrderIds || [];
            
            // Perform the requested action
            switch (action) {
                case 'add':
                    // Add the order ID if it doesn't already exist
                    if (orderId && !processedOrders.includes(orderId)) {
                        processedOrders.push(orderId);
                        // Keep only the last 50 orders to prevent excessive storage
                        if (processedOrders.length > 50) {
                            processedOrders = processedOrders.slice(-50);
                        }
                        // Save the updated list
                        chrome.storage.local.set({ processedOrderIds: processedOrders }, function() {
                            console.log(`Added order ${orderId} to processed orders. Total: ${processedOrders.length}`);
                            resolve(true);
                        });
                    } else {
                        console.log(`Order ${orderId} already in processed list or invalid ID`);
                        resolve(false);
                    }
                    break;
                    
                case 'check':
                    // Check if the order ID exists in the processed list
                    const isProcessed = orderId && processedOrders.includes(orderId);
                    console.log(`Checking if order ${orderId} was processed: ${isProcessed}`);
                    resolve(isProcessed);
                    break;
                    
                case 'clear':
                    // Clear all processed orders
                    chrome.storage.local.set({ processedOrderIds: [] }, function() {
                        console.log('Cleared all processed orders');
                        resolve(true);
                    });
                    break;
                    
                case 'list':
                    // Return the list of processed orders
                    console.log(`Current processed orders: ${processedOrders.join(', ')}`);
                    resolve(processedOrders);
                    break;
                    
                default:
                    console.log(`Unknown action: ${action}`);
                    resolve(false);
            }
        });
    });
}

// Function to extract order ID from URL
function extractOrderId(url) {
    if (!url) return null;
    const match = url.match(/\/writer\/orders\/([^/]+)/);
    return match ? match[1] : null;
}

// Function to highlight the selected order row
function highlightSelectedOrder(row) {
    if (!row) return;
    
    // Remove any previous highlights
    document.querySelectorAll('.hub-selected-order').forEach(el => {
        el.classList.remove('hub-selected-order');
    });
    
    // Create a style for the highlight if it doesn't exist
    if (!document.getElementById('hub-highlight-style')) {
        const style = document.createElement('style');
        style.id = 'hub-highlight-style';
        style.innerHTML = ``;
        document.head.appendChild(style);
    }
    
    // Add the highlight class
    row.classList.add('hub-selected-order');
    
    // Scroll the row into view if needed
}

// Function to simulate a more realistic click
function simulateFullClick(element) {
    if (!element) return false;
    
    try {
        // Create mouse events for hover, mousedown, mouseup, and click
        const mouseoverEvent = new MouseEvent('mouseover', {
            bubbles: true,
            cancelable: true,
            view: window
        });
        
        const mousedownEvent = new MouseEvent('mousedown', {
            bubbles: true,
            cancelable: true,
            view: window
        });
        
        const mouseupEvent = new MouseEvent('mouseup', {
            bubbles: true,
            cancelable: true,
            view: window
        });
        
        const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
        });
        
        // Dispatch events in sequence with slight delays to mimic human behavior
        element.dispatchEvent(mouseoverEvent);
        
        setTimeout(() => {
            element.dispatchEvent(mousedownEvent);
            
            setTimeout(() => {
                element.dispatchEvent(mouseupEvent);
                element.dispatchEvent(clickEvent);
            }, 50 + Math.random() * 30);
        }, 50 + Math.random() * 50);
        
        return true;
    } catch (error) {
        console.error("Error in simulateFullClick:", error);
        return false;
    }
}

// Function to continuously monitor for a take button on the page without refreshing
function startContinuousTakeButtonMonitoring() {
    // First check if we're on an actual order page (not all_available)
    if (!window.location.href.match(/\/writer\/orders\/\d+/) || 
        window.location.href.includes('/all_available') || 
        window.location.href.includes('/top_offers')) {
        console.log('Not on an individual order page, skipping take button monitoring');
        return false;
    }
    
    console.log('Starting continuous take button monitoring on this page (checking every 500ms)...');
    
    // Show indicator
    showResultIndicator(true, 'Monitoring for Take button appearance on this page...');
    
    // Create a flag to track if monitoring is active
    window.continuousTakeButtonMonitoringActive = true;
    
    // Store a reference to the interval so we can clear it later
    window.continuousTakeButtonInterval = setInterval(() => {
        // Check if monitoring was stopped
        if (!window.continuousTakeButtonMonitoringActive) {
            clearInterval(window.continuousTakeButtonInterval);
            console.log('Continuous take button monitoring stopped');
            return;
        }
        
        console.log('Checking for take button appearance on the page...');
        
        // Look for the take button
        const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');
        
        if (takeButton) {
            console.log('TAKE BUTTON APPEARED! Clicking it immediately...');
            // Update the indicator
            showResultIndicator(true, 'Take button appeared! Clicking now...');
            
            // Clear the interval to prevent multiple clicks
            clearInterval(window.continuousTakeButtonInterval);
            window.continuousTakeButtonMonitoringActive = false;
            
            // Click the button using multiple methods for reliability
            clickElementWithMultipleMethods(takeButton);
            
            // Use the same improved confirmation button detection from checkForTakeButtonBeforeBiddingFlow
            console.log('Starting IMMEDIATE confirmation button detection...');
            
            // Create array of possible confirmation button selectors
            const confirmButtonSelectors = [
                'button.btn.btn_green.confirm_button[type="button"]',
                'button.btn.btn_green[type="submit"]',
                'button.btn.btn_green.confirm',
                '.btn_green.confirm_button',
                '.confirm_button',
                'button.dialog-confirm',
                'button[data-dialog-confirm="true"]'
            ];
            
            // Use recursion for active polling - much more reliable than setTimeout
            function checkForConfirmationButton(attempts = 0, maxAttempts = 50) {
                // Try each selector
                for (const selector of confirmButtonSelectors) {
                    const confirmButton = document.querySelector(selector);
                    if (confirmButton) {
                        console.log(`CONFIRMATION BUTTON FOUND with selector "${selector}"! Clicking IMMEDIATELY...`);
                        // Use multiple click methods to ensure it works
                        clickElementWithMultipleMethods(confirmButton);
                        
                        // Extract order ID if possible
                        const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
                        const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
                        
                        // Wait longer before notifying background of success and navigate back
                        setTimeout(() => {
                            console.log('Order taken successfully!');
                            showResultIndicator(true, 'Order successfully taken!');
                            
                            // Notify background that we successfully took the order
                            chrome.runtime.sendMessage({
                                action: 'orderProcessingComplete',
                                metCriteria: true,
                                orderUrl: window.location.href,
                                orderId: orderId,
                                reasons: 'Order successfully taken'
                            });
                            
                            // Wait even longer before returning to All Available to prevent interrupting the take process
                            setTimeout(() => {
                                console.log('Returning to All Available...');
                                window.navigateToAllAvailableOrders();
                            }, 3000);
                        }, 2000);
                        
                        return; // Exit the recursion once button is found and clicked
                    }
                }
                
                // If we've exceeded max attempts, give up
                if (attempts >= maxAttempts) {
                    console.log('Failed to find confirmation button after maximum attempts, switching to interval monitoring...');
                    startConfirmationButtonMonitoring();
                    return;
                }
                
                // Recursively check again after a very short delay (10ms)
                setTimeout(() => {
                    checkForConfirmationButton(attempts + 1, maxAttempts);
                }, 10);
            }
            
            // Start the immediate confirmation button check
            checkForConfirmationButton();
        }
    }, 500); // Check every 500ms
}

// Function to specifically monitor for confirmation button after take button was clicked
function startConfirmationButtonMonitoring() {
    console.log('Starting confirmation button monitoring (checking every 50ms)...');
    
    // Create a flag to track if monitoring is active
    window.confirmationButtonMonitoringActive = true;
    
    // Create array of possible confirmation button selectors
    const confirmButtonSelectors = [
        'button.btn.btn_green.confirm_button[type="button"]',
        'button.btn.btn_green[type="submit"]',
        'button.btn.btn_green.confirm',
        '.btn_green.confirm_button',
        '.confirm_button',
        'button.dialog-confirm',
        'button[data-dialog-confirm="true"]'
    ];
    
    // Store a reference to the interval so we can clear it later
    window.confirmationButtonInterval = setInterval(() => {
        // Check if monitoring was stopped
        if (!window.confirmationButtonMonitoringActive) {
            clearInterval(window.confirmationButtonInterval);
            console.log('Confirmation button monitoring stopped');
            return;
        }
        
        console.log('Checking for confirmation button appearance...');
        
        // Try each selector for the confirmation button
        for (const selector of confirmButtonSelectors) {
            const confirmButton = document.querySelector(selector);
            if (confirmButton) {
                console.log(`CONFIRMATION BUTTON FOUND with selector "${selector}"! Clicking IMMEDIATELY...`);
                
                // Clear the interval to prevent multiple clicks
                clearInterval(window.confirmationButtonInterval);
                window.confirmationButtonMonitoringActive = false;
                
                // Click the button using multiple methods
                clickElementWithMultipleMethods(confirmButton);
                
                // Extract order ID if possible
                const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
                const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
                
                // Wait longer before notifying background of success and navigate back
                setTimeout(() => {
                    console.log('Order taken successfully!');
                    showResultIndicator(true, 'Order successfully taken!');
                    
                    // Notify background that we successfully took the order
                    chrome.runtime.sendMessage({
                        action: 'orderProcessingComplete',
                        metCriteria: true,
                        orderUrl: window.location.href,
                        orderId: orderId,
                        reasons: 'Order successfully taken'
                    });
                    
                    // Wait even longer before returning to All Available
                    setTimeout(() => {
                        console.log('Returning to All Available...');
                        window.navigateToAllAvailableOrders();
                    }, 3000);
                }, 2000);
                
                return; // Exit once button is found and clicked
            }
        }
    }, 50); // Check every 50ms for faster response
}

// Function to stop continuous take button monitoring
function stopContinuousTakeButtonMonitoring() {
    if (window.continuousTakeButtonInterval) {
        clearInterval(window.continuousTakeButtonInterval);
        window.continuousTakeButtonMonitoringActive = false;
        console.log('Continuous take button monitoring stopped');
    }
    
    if (window.confirmationButtonInterval) {
        clearInterval(window.confirmationButtonInterval);
        window.confirmationButtonMonitoringActive = false;
        console.log('Confirmation button monitoring stopped');
    }
}

// Variable to store the take button monitoring interval
let takeButtonMonitorInterval = null;

// Function to continuously monitor for Take button appearance
function continuouslyMonitorForTakeButton() {
    // First check if we're on an actual order page
    if (!window.location.href.match(/\/writer\/orders\/\d+/) || 
        window.location.href.includes('/all_available') || 
        window.location.href.includes('/top_offers')) {
        console.log('Not on an individual order page, skipping take button monitoring');
        return false;
    }

    // Clear any existing monitoring interval
    if (takeButtonMonitorInterval) {
        clearInterval(takeButtonMonitorInterval);
        takeButtonMonitorInterval = null;
    }

    console.log('Starting continuous monitoring for Take button...');

    // Set up an interval that frequently checks for the Take button
    takeButtonMonitorInterval = setInterval(() => {
        // Single exact selector for take button
        const takeButton = document.querySelector('a.btn.btn_green.take_bid.dialog[data-confirm="Are you sure you want to take this order?"]');

        if (takeButton) {
            console.log('TAKE BUTTON FOUND! Clicking it immediately...');
            showResultIndicator(true, 'Take button found! Taking order...');

            // Clear the monitoring interval
            clearInterval(takeButtonMonitorInterval);
            takeButtonMonitorInterval = null;

            // Click the take button
            simulateFullClick(takeButton);

            // Look for confirmation button
            const checkForConfirmation = setInterval(() => {
                // Single exact selector for confirmation button
                const confirmButton = document.querySelector('button.btn.btn_green.confirm_button[type="button"]');
                if (confirmButton) {
                    console.log('Confirmation button found! Clicking IMMEDIATELY...');
                    simulateFullClick(confirmButton);
                    clearInterval(checkForConfirmation);

                    // Get order ID if available
                    const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
                    const orderId = idMatch && idMatch[1] ? idMatch[1] : null;

                    setTimeout(() => {
                        console.log('Order taken successfully!');
                        showResultIndicator(true, 'Order successfully taken!');

                        // Notify background that we successfully took the order
                        chrome.runtime.sendMessage({
                            action: 'orderProcessingComplete',
                            metCriteria: true,
                            orderUrl: window.location.href,
                            orderId: orderId,
                            reasons: 'Order successfully taken'
                        });

                        // Return to all available after delay
                        setTimeout(() => {
                            console.log('Returning to All Available...');
                            window.navigateToAllAvailableOrders();
                        }, 3000);
                    }, 2000);
                }
            }, 100); // Check every 100ms

            // Safety timeout to clear confirmation check
            setTimeout(() => {
                clearInterval(checkForConfirmation);
            }, 10000); // 10 second safety timeout
        }
    }, 200); // Check for Take button every 200ms

    // Safety timeout to stop monitoring after a reasonable time
    setTimeout(() => {
        if (takeButtonMonitorInterval) {
            console.log('Stopping Take button monitoring after timeout period');
            clearInterval(takeButtonMonitorInterval);
            takeButtonMonitorInterval = null;
        }
    }, 120000); // 2 minute safety timeout
}

// Function to stop take button monitoring
function stopTakeButtonMonitoring() {
    if (takeButtonMonitorInterval) {
        console.log('Stopping Take button monitoring');
        clearInterval(takeButtonMonitorInterval);
        takeButtonMonitorInterval = null;
    }
}
