/**
 * recaptchaCheck.js
 * Handles reCAPTCHA verification and green place bid button click sequence
 */

// Function to continuously check for reCAPTCHA verification and proceed with button clicks
function checkRecaptchaAndProceedWithBid() {
    console.log('Starting reCAPTCHA verification check...');
    
    // Get recaptcha wait time from settings
    chrome.storage.local.get(['recaptchaWaitTime'], function(data) {
        const recaptchaWaitTime = data.recaptchaWaitTime || 25; // Default 25 seconds
        console.log(`Using reCAPTCHA wait timeout of ${recaptchaWaitTime} seconds`);
        
        // Extract order ID if possible
        const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
        const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
        
        // Show status indicator
        if (typeof showResultIndicator === 'function') {
            showResultIndicator(true, 'Waiting for reCAPTCHA verification...');
        }
        
        // Use the waitForRecaptchaVerification function from recaptchaVerifier.js
        window.recaptchaVerifier.waitForVerification(
            (verified, error) => {
                if (verified) {
                    console.log('✅ reCAPTCHA VERIFIED! Proceeding with green place bid button...');
                    if (typeof showResultIndicator === 'function') {
                        showResultIndicator(true, 'reCAPTCHA verified! Placing bid...');
                    }
                    
                    // Click the green Place Bid button
                    clickGreenPlaceBidButton(orderId);
                } else {
                    // reCAPTCHA verification failed or timed out
                    console.log(`❌ reCAPTCHA verification failed or timed out after ${recaptchaWaitTime} seconds`);
                    console.log('Error:', error || 'No specific error provided');
                    
                    // Log detailed status for debugging
                    window.recaptchaVerifier.logStatus();
                    
                    if (typeof showResultIndicator === 'function') {
                        showResultIndicator(false, 'reCAPTCHA not verified. Refreshing...');
                    }
                    
                    // Notify background about retry
                    chrome.runtime.sendMessage({
                        action: 'orderProcessingComplete',
                        metCriteria: false,
                        orderUrl: window.location.href,
                        orderId: orderId,
                        reasons: 'reCAPTCHA not verified - retrying'
                    });
                    
                    // Add a small delay before refreshing
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                }
            },
            1000, // Check every second
            recaptchaWaitTime * 1000 // Total timeout in milliseconds
        );
    });
}

// Alternative method to monitor reCAPTCHA continuously
function monitorRecaptchaAndProceedWithBid() {
    console.log('Starting continuous reCAPTCHA monitoring...');
    
    // Extract order ID if possible
    const idMatch = window.location.href.match(/\/writer\/orders\/(\d+)/);
    const orderId = idMatch && idMatch[1] ? idMatch[1] : null;
    
    // Show status indicator
    if (typeof showResultIndicator === 'function') {
        showResultIndicator(true, 'Monitoring for reCAPTCHA verification...');
    }
    
    // Start monitoring for reCAPTCHA verification
    window.recaptchaVerifier.monitor(() => {
        console.log('✅ reCAPTCHA VERIFIED (from monitor)! Proceeding with green place bid button...');
        
        if (typeof showResultIndicator === 'function') {
            showResultIndicator(true, 'reCAPTCHA verified! Placing bid...');
        }
        
        // Click the green Place Bid button
        clickGreenPlaceBidButton(orderId);
    }, 1000); // Check every second
}

// Function to find and click the green Place Bid button
function clickGreenPlaceBidButton(orderId) {
    // Single exact selector for the green place bid button
    const greenPlaceBidButton = document.querySelector('button.btn.btn_green[data-disable-with="loading..."][type="submit"]');
    
    if (!greenPlaceBidButton) {
        console.error('Green Place Bid button not found!');
    
        // Notify background of failure
        chrome.runtime.sendMessage({
            action: 'orderProcessingComplete',
            metCriteria: false,
            orderUrl: window.location.href,
            orderId: orderId,
            reasons: 'Green Place Bid button not found'
        });
        
        // Return to all available orders
        setTimeout(() => {
            if (typeof window.navigateToAllAvailableOrders === 'function') {
                window.navigateToAllAvailableOrders();
            } else {
                window.location.href = 'https://www.writershub.org/writer/orders/all_available';
            }
        }, 1500);
        
        return;
    }
    
    // Click the green Place Bid button
    console.log('Clicking green Place Bid button...');
    if (typeof simulateFullClick === 'function') {
        simulateFullClick(greenPlaceBidButton);
    } else {
        greenPlaceBidButton.click();
    }
    
    if (typeof showResultIndicator === 'function') {
        showResultIndicator(true, 'Bid placed! Looking for confirmation...');
    }
    
    // Wait for the popup and click the OK button
    setTimeout(clickOkButtonInPopup, 2000, orderId);
}

// Function to find and click the OK button in the popup
function clickOkButtonInPopup(orderId) {
    // Single exact selector for OK button in success popup
    const okButton = document.querySelector('button.btn.btn_green.popup_close[type="button"]');

    if (okButton) {
        console.log('OK button found in success popup! Clicking...');
        if (typeof simulateFullClick === 'function') {
            simulateFullClick(okButton);
        } else {
            okButton.click();
        }
        
        // Start monitoring for Take button
        console.log('Starting Take button monitoring after successful bid...');
        
        // DIRECT START: Immediately start the monitoring locally first
        console.log('DIRECTLY starting take button monitoring in content script...');
        
        // Set the monitoring flag
        sessionStorage.setItem('takeButtonMonitoringActive', 'true');
        
        // Directly call the function if available
        if (typeof window.refreshAndLookForTakeButton === 'function') {
            console.log('Calling refreshAndLookForTakeButton() directly...');
            try {
                window.refreshAndLookForTakeButton();
                console.log('Successfully started monitoring locally!');
            } catch (e) {
                console.error('Error starting monitoring locally:', e);
            }
        } else {
            console.error('refreshAndLookForTakeButton function not available directly, will try via messages');
        }
        
        // Also notify background script as a fallback
        chrome.runtime.sendMessage({
            action: 'startTakeButtonMonitoring',
            orderUrl: window.location.href
        }, function(response) {
            console.log('Background response to startTakeButtonMonitoring:', response);
        });
    } else {
        console.log('No OK button found in success popup. Starting take button monitoring anyway...');
        
        // Still start monitoring even if no button was found
        // Set the monitoring flag
        sessionStorage.setItem('takeButtonMonitoringActive', 'true');
        
        // Directly call the function if available
        if (typeof window.refreshAndLookForTakeButton === 'function') {
            console.log('Calling refreshAndLookForTakeButton() directly...');
            try {
                window.refreshAndLookForTakeButton();
                console.log('Successfully started monitoring locally!');
            } catch (e) {
                console.error('Error starting monitoring locally:', e);
            }
        } else {
            console.error('refreshAndLookForTakeButton function not available directly, will try via messages');
        }
        
        // Also notify background script as a fallback
        chrome.runtime.sendMessage({
            action: 'startTakeButtonMonitoring',
            orderUrl: window.location.href
        }, function(response) {
            console.log('Background response to startTakeButtonMonitoring:', response);
        });
    }
}

// Export functions for use in other files
window.recaptchaCheck = {
    checkAndProceed: checkRecaptchaAndProceedWithBid,
    monitorAndProceed: monitorRecaptchaAndProceedWithBid,
    clickGreenButton: clickGreenPlaceBidButton,
    clickOkButton: clickOkButtonInPopup
};