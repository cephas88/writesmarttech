/* Initialize variables in window scope to avoid conflicts */
window.writedomBot = window.writedomBot || {};
window.writedomBot.processedOrderIds = window.writedomBot.processedOrderIds || new Set();
window.writedomBot.processedUrlsSet = window.writedomBot.processedUrlsSet || new Set();
window.writedomBot.currentPageOrderIds = window.writedomBot.currentPageOrderIds || [];
window.writedomBot.isScanning = window.writedomBot.isScanning || false;
window.writedomBot.currentPage = window.writedomBot.currentPage || 1;
window.writedomBot.totalPages = window.writedomBot.totalPages || 1;
window.writedomBot.isNavigatingPages = window.writedomBot.isNavigatingPages || false;
window.writedomBot.currentlyProcessingOrders = window.writedomBot.currentlyProcessingOrders || new Set();
window.writedomBot.orderQueue = window.writedomBot.orderQueue || [];
window.writedomBot.isProcessingQueue = window.writedomBot.isProcessingQueue || false;
window.writedomBot.refreshIntervalSet = window.writedomBot.refreshIntervalSet || false;
window.writedomBot.allOrderUrls = window.writedomBot.allOrderUrls || [];
window.writedomBot.lastRefreshTime = window.writedomBot.lastRefreshTime || 0;
window.writedomBot.isCollectingUrls = window.writedomBot.isCollectingUrls || false;
window.writedomBot.refreshIntervalId = window.writedomBot.refreshIntervalId || null;
window.writedomBot.REFRESH_INTERVAL = 10000; // Refresh every 10 seconds when idle
window.writedomBot.MAX_CONCURRENT_PROCESSING = 5; // Process up to 5 orders concurrently
window.writedomBot.isCollectorTab = window.writedomBot.isCollectorTab || false;
window.writedomBot.isProcessorTab = window.writedomBot.isProcessorTab || false;
window.writedomBot.lastProcessorCheckTime = window.writedomBot.lastProcessorCheckTime || 0;
window.writedomBot.PROCESSOR_CHECK_INTERVAL = 2000; // Check every 2 seconds

/* Initialize the extension */
function initializeExtension() {
    console.log('Writedom Bidding Bot: Single Tab System initialized');
    chrome.storage.local.get(['isRunning', 'isBidding'], (data) => {
        console.log('Checking if bot is running:', data.isBidding);
        if (data.isBidding) {
            setTimeout(startUrlCollectionCycle, 2000);
        }
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Received message:', message);
    if (message.action === 'stop_bidding' || message.action === 'stop_bot') {
        stopAllBotActivities();
        if (sendResponse) sendResponse({ status: 'stopped' });
    } else if (message.action === 'start_collector_tab') {
        window.writedomBot.isCollectorTab = true;
        window.writedomBot.isProcessorTab = false;
        startUrlCollectionCycle();
        sendResponse({ status: 'success' });
    } else if (message.action === 'start_processor_tab') {
        window.writedomBot.isCollectorTab = false;
        window.writedomBot.isProcessorTab = true;
        startOrderProcessingCycle();
        sendResponse({ status: 'success' });
    } else if (message.action === 'clear_processed_orders') {
        clearProcessedOrdersData();
        sendResponse({ status: 'success' });
    } else if (message.action === 'order_processed' || message.action === 'order_complete') {
        const orderId = message.orderId;
        if (orderId) {
            window.writedomBot.processedOrderIds.add(orderId);
            if (message.url) window.writedomBot.processedUrlsSet.add(message.url);
            window.writedomBot.currentlyProcessingOrders.delete(orderId);
            console.log(`Order ${orderId} processed`);
            updateProcessedOrdersInStorage();
            checkQueueAndRefresh();
        }
        sendResponse({ status: 'success' });
    } else if (message.action === 'order_processing_started') {
        const orderId = message.orderId;
        if (orderId) {
            window.writedomBot.currentlyProcessingOrders.add(orderId);
            console.log(`Order ${orderId} processing started`);
        }
        sendResponse({ status: 'success' });
    } else if (message.action === 'check_for_new_orders') {
        if (window.writedomBot.isProcessorTab) {
            checkForNewOrdersToProcess().then(result => sendResponse(result));
        } else {
            sendResponse({ status: 'not_processor_tab' });
        }
    } else if (message.action === 'start_immediate_scan') {
        // Only scan if bot is running
        chrome.storage.local.get(['isBidding'], (data) => {
            if (data.isBidding) {
                startUrlCollectionCycle().then(response => {
                    if (sendResponse) sendResponse(response);
                });
            } else {
                if (sendResponse) sendResponse({ status: 'not_running' });
            }
        });
        return true;
    }
    return true;
});

/* Stop all bot activities */
function stopAllBotActivities() {
    if (window.writedomBot.refreshIntervalId) {
        clearInterval(window.writedomBot.refreshIntervalId);
        window.writedomBot.refreshIntervalId = null;
    }
    window.writedomBot.refreshIntervalSet = false;
    window.writedomBot.processedOrderIds.clear();
    window.writedomBot.processedUrlsSet.clear();
    window.writedomBot.currentPageOrderIds = [];
    window.writedomBot.isScanning = false;
    window.writedomBot.isNavigatingPages = false;
    window.writedomBot.currentPage = 1;
    window.writedomBot.totalPages = 1;
    window.writedomBot.currentlyProcessingOrders.clear();
    window.writedomBot.orderQueue = [];
    window.writedomBot.isProcessingQueue = false;
    window.writedomBot.allOrderUrls = [];
    window.writedomBot.isCollectingUrls = false;
    chrome.storage.local.set({
        isRunning: false,
        isBidding: false,
        processedOrderIds: [],
        collectedOrderUrls: [],
        orderQueue: [],
        currentPage: 1
    }, () => console.log('Bot stopped'));
}

/* Clear processed orders data */
function clearProcessedOrdersData() {
    window.writedomBot.processedOrderIds.clear();
    window.writedomBot.processedUrlsSet.clear();
    window.writedomBot.currentlyProcessingOrders.clear();
    window.writedomBot.orderQueue = [];
    window.writedomBot.allOrderUrls = [];
    chrome.storage.local.set({
        processedOrderIds: [],
        processedUrls: [],
        collectedOrderUrls: [],
        currentPage: 1
    }, () => console.log('Processed orders cleared'));
}

/* Update processed orders in storage */
function updateProcessedOrdersInStorage() {
    chrome.storage.local.set({
        processedOrderIds: Array.from(window.writedomBot.processedOrderIds),
        processedUrls: Array.from(window.writedomBot.processedUrlsSet),
        currentPage: window.writedomBot.currentPage
    }, () => console.log('Processed orders and page updated in storage'));
}

/* Check queue and refresh if empty, then click Next */
async function checkQueueAndRefresh() {
    chrome.storage.local.get(['collectedOrderUrls'], async (data) => {
        const queue = data.collectedOrderUrls || [];
        if (queue.length === 0 && window.writedomBot.currentlyProcessingOrders.size === 0) {
            console.log('Queue empty and no orders processing, refreshing in 10 seconds...');
            if (window.writedomBot.isCollectorTab) {
                if (!window.writedomBot.refreshIntervalId) {
                    window.writedomBot.refreshIntervalId = setInterval(async () => {
                        console.log('Refreshing page...');
                        window.location.reload();
                        // After refresh, the page reload triggers initializeExtension and startUrlCollectionCycle
                    }, window.writedomBot.REFRESH_INTERVAL);
                    window.writedomBot.refreshIntervalSet = true;
                }
            }
        }
    });
}

/* COLLECTOR TAB FUNCTIONALITY */

/* Start URL collection cycle */
async function startUrlCollectionCycle() {
    // Check if bot is running before proceeding
    const data = await new Promise(resolve => 
        chrome.storage.local.get(['isBidding'], resolve)
    );
    
    if (!data.isBidding) {
        console.log('Bot is not running, stopping URL collection');
        return { status: 'not_running' };
    }

    if (window.writedomBot.isCollectingUrls) {
        console.log('Already collecting URLs, skipping');
        return { status: 'already_collecting' };
    }

    window.writedomBot.isCollectingUrls = true;
    console.log('Starting URL collection cycle');
    if (!window.location.href.includes('/dashboard/available-orders')) {
        window.location.href = '/dashboard/available-orders';
        return;
    }
    // After refresh, click "Next" and then collect URLs
    clickNextAfterRefresh();
}

/* Click "Next" after refresh and proceed to collect URLs */
async function clickNextAfterRefresh() {
    console.log('Post-refresh: Preparing to click Next...');
    try {
        // Load current page from storage
        const storageData = await new Promise(resolve => 
            chrome.storage.local.get(['currentPage'], resolve)
        );
        if (storageData.currentPage) window.writedomBot.currentPage = storageData.currentPage;

        // Update pagination info
        updatePaginationInfo();

        // Click "Next" immediately after refresh
        if (!isLastPage()) {
            const nextPageClicked = await clickNextPageButton();
            if (nextPageClicked) {
                console.log(`Advanced to page ${window.writedomBot.currentPage + 1}`);
                window.writedomBot.currentPage++;
                await new Promise(resolve => setTimeout(resolve, 1500)); // Wait for page load
            } else {
                console.log('No next page available or already on last page, resetting to page 1');
                window.writedomBot.currentPage = 1;
                await navigateToPage(1);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        } else {
            console.log('On last page, resetting to page 1');
            window.writedomBot.currentPage = 1;
            await navigateToPage(1);
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // Save updated page number
        chrome.storage.local.set({ currentPage: window.writedomBot.currentPage }, () => {
            console.log(`Current page saved: ${window.writedomBot.currentPage}`);
        });

        // Now collect URLs from the navigated page
        collectUrlsFromAllPages();
    } catch (error) {
        console.error('Error clicking Next after refresh:', error);
        collectUrlsFromAllPages(); // Proceed anyway to avoid stalling
    }
}

/* Collect URLs from current page */
async function collectUrlsFromAllPages() {
    if (!window.writedomBot.isCollectorTab || window.writedomBot.isCollectingUrls) return;
    window.writedomBot.isCollectingUrls = true;
    console.log('🤖 Collecting URLs from current page...');
    window.writedomBot.allOrderUrls = [];

    try {
        const runningData = await new Promise(resolve => chrome.storage.local.get(['isRunning'], resolve));
        if (!runningData.isRunning) {
            console.log('Bot not running, aborting collection');
            window.writedomBot.isCollectingUrls = false;
            return;
        }

        // Load processed URLs from storage
        const storageData = await new Promise(resolve => 
            chrome.storage.local.get(['processedOrderIds', 'processedUrls'], resolve)
        );
        if (storageData.processedOrderIds) storageData.processedOrderIds.forEach(id => window.writedomBot.processedOrderIds.add(id));
        if (storageData.processedUrls) storageData.processedUrls.forEach(url => window.writedomBot.processedUrlsSet.add(url));

        // Extract URLs from the current page
        const currentPageUrls = await extractOrderUrls();
        if (currentPageUrls.length) {
            window.writedomBot.allOrderUrls.push(...currentPageUrls);
            console.log(`Added ${currentPageUrls.length} URLs from page ${window.writedomBot.currentPage}. Total: ${window.writedomBot.allOrderUrls.length}`);
        } else {
            console.log(`No URLs found on page ${window.writedomBot.currentPage}`);
        }

        // Deduplicate and queue all URLs
        const uniqueUrls = [...new Map(window.writedomBot.allOrderUrls.map(item => [item.url, item])).values()];
        console.log(`Found ${uniqueUrls.length} unique URLs`);

        // Store all URLs in queue
        chrome.storage.local.set({ collectedOrderUrls: uniqueUrls }, () => {
            console.log(`Queued ${uniqueUrls.length} URLs for processing from page ${window.writedomBot.currentPage}`);
            if (window.writedomBot.refreshIntervalId) {
                clearInterval(window.writedomBot.refreshIntervalId);
                window.writedomBot.refreshIntervalId = null;
                window.writedomBot.refreshIntervalSet = false;
                console.log('Stopped refresh interval due to queued orders');
            }
        });

        window.writedomBot.isCollectingUrls = false;
    } catch (error) {
        console.error('Error collecting URLs:', error);
        window.writedomBot.isCollectingUrls = false;
    }
}

/* Extract order URLs from current page */
async function extractOrderUrls() {
    console.log('Extracting order URLs...');
    const specificOrderLinks = Array.from(document.querySelectorAll('a[href*="/dashboard/orders/"]'));
    let orderLinks = specificOrderLinks.length ? specificOrderLinks : Array.from(document.querySelectorAll('a')).filter(link => {
        const href = link.href.toLowerCase();
        return /\/dashboard\/orders\/\d+/.test(href) && !href.includes('/dashboard/available-orders') && !href.includes('/dashboard/my-orders');
    });

    if (!orderLinks.length) {
        console.log('No order links found');
        return [];
    }

    const orderUrls = orderLinks.map(link => ({
        url: link.href,
        title: link.textContent.trim() || (link.closest('tr')?.textContent.trim().substring(0, 50) + '...' || 'Order')
    }));

    return [...new Map(orderUrls.filter(item => /\/dashboard\/orders\/\d+/.test(item.url)).map(item => [item.url, item])).values()];
}

/* Click next page button */
async function clickNextPageButton() {
    console.log('Searching for next page button...');
    const nextButtons = Array.from(document.querySelectorAll('button')).filter(button => {
        const svg = button.querySelector('svg');
        return svg && svg.querySelector('path[d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"]');
    });

    if (nextButtons.length) {
        const nextButton = nextButtons[0];
        console.log('Found next page button using SVG path:', nextButton);
        const isDisabled = nextButton.hasAttribute('disabled') || 
                          nextButton.getAttribute('aria-disabled') === 'true' || 
                          nextButton.classList.contains('disabled');
        if (isDisabled) {
            console.warn('⚠️ Next page button is disabled');
            return false;
        }
        console.log('Clicking next page button...');
        nextButton.click();
        return true;
    }

    console.error('❌ Could not find next page button');
    return false;
}




/* PROCESSOR TAB FUNCTIONALITY */

/* Start order processing cycle */
function startOrderProcessingCycle() {
    if (!window.writedomBot.isProcessorTab) return;
    console.log('Starting order processing cycle');
    if (!window.writedomBot.refreshIntervalSet) {
        window.writedomBot.refreshIntervalId = setInterval(() => {
            chrome.storage.local.get(['isRunning'], (data) => {
                if (data.isRunning && window.writedomBot.isProcessorTab) {
                    checkForNewOrdersToProcess();
                }
            });
        }, window.writedomBot.PROCESSOR_CHECK_INTERVAL);
        window.writedomBot.refreshIntervalSet = true;
    }
    checkForNewOrdersToProcess();
}

/* Check for new orders to process */
async function checkForNewOrdersToProcess() {
    const now = Date.now();
    if (now - window.writedomBot.lastProcessorCheckTime < 1000) return;
    window.writedomBot.lastProcessorCheckTime = now;

    try {
        const data = await new Promise(resolve => 
            chrome.storage.local.get(['collectedOrderUrls', 'processedOrderIds', 'processedUrls'], resolve)
        );
        const collectedUrls = data.collectedOrderUrls || [];
        if (data.processedOrderIds) data.processedOrderIds.forEach(id => window.writedomBot.processedOrderIds.add(id));
        if (data.processedUrls) data.processedUrls.forEach(url => window.writedomBot.processedUrlsSet.add(url));

        const unprocessedOrders = collectedUrls.filter(order => {
            const orderId = extractOrderId(order.url);
            return orderId && !window.writedomBot.processedOrderIds.has(orderId) && 
                   !window.writedomBot.processedUrlsSet.has(order.url) && 
                   !window.writedomBot.currentlyProcessingOrders.has(orderId);
        });

        console.log(`Found ${unprocessedOrders.length} unprocessed orders`);
        const maxConcurrent = window.writedomBot.MAX_CONCURRENT_PROCESSING;
        const currentProcessing = window.writedomBot.currentlyProcessingOrders.size;
        const availableSlots = maxConcurrent - currentProcessing;

        if (availableSlots <= 0 || unprocessedOrders.length === 0) return;

        const ordersToProcess = Math.min(availableSlots, unprocessedOrders.length);
        console.log(`Processing ${ordersToProcess} orders concurrently`);

        for (let i = 0; i < ordersToProcess; i++) {
            const order = unprocessedOrders[i];
            processOrderInNewTab(order);
            removeOrderFromStorage(order.url);
            await new Promise(resolve => setTimeout(resolve, 500));
        }

        return { status: 'success', processed: ordersToProcess, remaining: unprocessedOrders.length - ordersToProcess };
    } catch (error) {
        console.error('Error processing orders:', error);
        return { status: 'error', message: error.message };
    }
}

/* Remove order from storage */
function removeOrderFromStorage(url) {
    chrome.storage.local.get(['collectedOrderUrls'], (data) => {
        const collectedUrls = data.collectedOrderUrls || [];
        const updatedUrls = collectedUrls.filter(item => item.url !== url);
        chrome.storage.local.set({ collectedOrderUrls: updatedUrls }, () => 
            console.log(`Removed order ${url} from queue`)
        );
    });
}

/* Process an order in a new tab */
function processOrderInNewTab(order) {
    if (!order?.orderId || !order?.url) return;
    console.log(`Processing order ${order.orderId}: ${order.url}`);
    window.writedomBot.currentlyProcessingOrders.add(order.orderId);
    chrome.runtime.sendMessage({
        action: 'open_order_in_new_tab',
        orderId: order.orderId,
        url: order.url
    }, (response) => {
        if (response?.status === 'success') {
            console.log(`Order ${order.orderId} opened for processing`);
        } else {
            window.writedomBot.currentlyProcessingOrders.delete(order.orderId);
        }
    });
}


(function() {
    // Attempt to find the next page button by looking for a button containing the SVG path for the arrow.
    const nextButtons = Array.from(document.querySelectorAll('button')).filter(button => {
      const svg = button.querySelector('svg');
      return svg && svg.querySelector('path[d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"]');
    });
    
    if (nextButtons.length) {
      const nextButton = nextButtons[0];
      
      // Check if the button is disabled (using common attributes and classes)
      const isDisabled = nextButton.hasAttribute('disabled') ||
                         nextButton.getAttribute('aria-disabled') === 'true' ||
                         nextButton.classList.contains('disabled');
      
      if (isDisabled) {
        console.warn('Next page arrow button is disabled. Possibly on the last page.');
        return;
      }
      
      console.log('Clicking the next page arrow button...');
      nextButton.click();
    } else {
      console.error('Could not find the next page arrow button.');
    }
  })();

/* HELPER FUNCTIONS */

/* Update pagination information */
function updatePaginationInfo() {
    try {
        const paginationText = document.querySelector('.pagination-info')?.textContent;
        if (paginationText) {
            const match = paginationText.match(/Page (\d+) of (\d+)/i);
            if (match) {
                window.writedomBot.currentPage = parseInt(match[1]);
                window.writedomBot.totalPages = parseInt(match[2]);
                return;
            }
        }
        const pageInfoMatch = document.body.textContent.match(/(\d+)\s*-\s*\d+\s*of\s*(\d+)/);
        if (pageInfoMatch) {
            const [_, start, total] = pageInfoMatch;
            const perPage = 20; // Assuming 20 items per page (adjust if known)
            window.writedomBot.currentPage = Math.floor(parseInt(start) / perPage) + 1;
            window.writedomBot.totalPages = Math.ceil(parseInt(total) / perPage);
            return;
        }
        window.writedomBot.currentPage = 1;
        window.writedomBot.totalPages = 1;
    } catch (error) {
        window.writedomBot.currentPage = 1;
        window.writedomBot.totalPages = 1;
    }
}

/* Extract order ID from URL */
function extractOrderId(url) {
    const match = url.match(/\/dashboard\/orders\/(\d+)/) || url.match(/\/order\/(\d+)/) || url.match(/(\d+)$/);
    return match ? match[1] : null;
}

/* Check if on last/first page */
function isLastPage() { return window.writedomBot.currentPage >= window.writedomBot.totalPages; }
function isFirstPage() { return window.writedomBot.currentPage === 1; }

/* Navigate to specific page */
async function navigateToPage(pageNum) {
    console.log(`Navigating to page ${pageNum}...`);
    try {
        if (window.writedomBot.currentPage === pageNum) return true;
        const pageButtons = Array.from(document.querySelectorAll('.pagination a, .pagination button')).filter(el => el.textContent.trim() === pageNum.toString());
        if (pageButtons.length) {
            pageButtons[0].click();
            return true;
        }
        const currentUrl = window.location.href;
        const separator = currentUrl.includes('?') ? '&' : '?';
        window.location.href = `${currentUrl}${separator}page=${pageNum}`;
        return true;
    } catch (error) {
        console.error(`Error navigating to page ${pageNum}:`, error);
        return false;
    }
}

/* Event listeners */
document.addEventListener('DOMContentLoaded', initializeExtension);
if (document.readyState !== 'loading') initializeExtension();
let lastUrl = window.location.href;
new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        setTimeout(initializeExtension, 1000);
    }
}).observe(document, { subtree: true, childList: true });

/* Exports */
window.writedomBot.initializeExtension = initializeExtension;
window.writedomBot.startUrlCollectionCycle = startUrlCollectionCycle;
window.writedomBot.startOrderProcessingCycle = startOrderProcessingCycle;
window.writedomBot.collectUrlsFromAllPages = collectUrlsFromAllPages;
window.writedomBot.checkForNewOrdersToProcess = checkForNewOrdersToProcess;

console.log('Writedom Bidding Bot loaded');

// Global variables
let isProcessing = false;
let currentProcessingUrl = null;

// Main function to handle order discovery
async function handleOrderDiscovery(orderId, orderUrl) {
    // Check if bot is running
    const data = await new Promise(resolve => 
        chrome.storage.local.get(['isBidding'], resolve)
    );
    
    if (!data.isBidding) {
        console.log('Bot is not running, ignoring order discovery');
        return;
    }

    // If already processing, queue or ignore
    if (isProcessing) {
        console.log('Already processing an order, ignoring new discovery');
        return;
    }

    isProcessing = true;
    currentProcessingUrl = orderUrl;

    try {
        // Use the existing tab instead of opening a new one
        await chrome.runtime.sendMessage({
            action: 'open_order',
            orderId: orderId,
            url: orderUrl
        });
    } catch (error) {
        console.error('Error opening order:', error);
    } finally {
        isProcessing = false;
        currentProcessingUrl = null;
    }
}

// Listen for bot status changes
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'stop_bot') {
        isProcessing = false;
        currentProcessingUrl = null;
        if (sendResponse) sendResponse({ status: 'stopped' });
        return true;
    }
    return true;
});