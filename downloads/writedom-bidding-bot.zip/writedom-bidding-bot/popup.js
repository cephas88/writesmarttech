// popup.js

// Add a function for showing toast notifications
function showToast(message, type = 'info') {
  // Create toast container if it doesn't exist
  let toastContainer = document.querySelector('.toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);
  }
  
  // Check if there's already a similar toast message
  const existingToasts = toastContainer.querySelectorAll('.toast');
  for (let i = 0; i < existingToasts.length; i++) {
    if (existingToasts[i].textContent === message) {
      // Don't create a duplicate toast
      return;
    }
  }
  
  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  
  // Add to container
  toastContainer.appendChild(toast);
  
  // Auto remove after delay
  setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => {
      if (toastContainer.contains(toast)) {
        toastContainer.removeChild(toast);
      }
    }, 500);
  }, 3000);
}

// Add CSS for toasts
const style = document.createElement('style');
style.textContent = `
  .toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1000;
  }
  .toast {
    min-width: 200px;
    margin-bottom: 10px;
    padding: 12px 15px;
    border-radius: 5px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    font-size: 14px;
    opacity: 1;
    transition: opacity 0.5s;
    color: white;
    animation: slideIn 0.5s;
  }
  .toast.fade-out {
    opacity: 0;
  }
  .toast.info {
    background-color: #4361ee;
  }
  .toast.success {
    background-color: #10b981;
  }
  .toast.warning {
    background-color: #f59e0b;
  }
  .toast.error {
    background-color: #ef4444;
  }
  @keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', function() {
  const activationSection = document.getElementById('activation-section');
  const settingsSection = document.getElementById('settings-section');
  const controlSection = document.getElementById('control-section');
  const statusSection = document.getElementById('status-section');
  const startBtn = document.getElementById('startBidding');
  const stopBtn = document.getElementById('stopBidding');
  const statusSpan = document.getElementById('status');
  const logDiv = document.getElementById('log');
  const expirationDateElement = document.getElementById('expiration-date');
  const countdownElement = document.getElementById('countdown');
  const progressElement = document.getElementById('time-progress');
  const countdownBox = document.querySelector('.countdown-box');
  const expiredMessageElement = document.getElementById('expired-message');
  const saveSettingsBtn = document.getElementById('saveSettingsBtn');
  const startTrialBtn = document.getElementById('startTrialBtn');
  const showLicenseFormLink = document.getElementById('showLicenseForm');
  const activateBtn = document.getElementById('activateBtn');
  const toggleButton = document.getElementById('toggle-bidding');
  const bidButton = document.getElementById('bidButton');
  const bidStatus = document.getElementById('bidStatus');

  let countdownInterval = null;
  let isStarting = false;

  // Add click event listener with toast notification to all buttons
  document.querySelectorAll('button').forEach(button => {
    const originalClick = button.onclick;
    button.onclick = function(e) {
      if (!this.disabled) {
        showToast(`${this.textContent} button clicked`, 'info');
        if (originalClick) originalClick.call(this, e);
      }
    };
  });

  // Also add notifications for links
  document.querySelectorAll('a').forEach(link => {
    const originalClick = link.onclick;
    link.onclick = function(e) {
      if (!link.href || link.href.startsWith('#')) {
        showToast(`${this.textContent} clicked`, 'info');
      }
      if (originalClick) originalClick.call(this, e);
    };
  });

  // Add notifications to checkbox changes
  document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
      const label = this.closest('label');
      const text = label ? label.textContent.trim() : (this.id || 'Option');
      showToast(`${text} ${this.checked ? 'enabled' : 'disabled'}`, 'info');
    });
  });
  
  // Add notifications to number input changes
  document.querySelectorAll('input[type="number"]').forEach(input => {
    input.addEventListener('change', function() {
      const label = this.closest('.input-group').querySelector('label');
      const text = label ? label.textContent.trim() : (this.id || 'Value');
      showToast(`${text} set to ${this.value}`, 'info');
    });
  });

  // Load initial state and determine which sections to show
  chrome.storage.local.get(['isFirstInstall', 'isRunning', 'activationStatus', 'settings', 'isBidding'], function(data) {
    console.log('Initial state:', data);

    // Check if the bot is currently running and update UI accordingly
    const isBotRunning = !!data.isBidding;
    
    if (isBotRunning) {
      // Bot is running, update UI to show "Stop Bidding"
      if (toggleButton) {
        toggleButton.textContent = 'Stop Bidding';
        toggleButton.classList.add('stop');
      }
      
      if (statusSpan) {
        statusSpan.textContent = 'Running';
        statusSpan.className = 'running';
      }
      
      if (bidButton) {
        bidButton.textContent = 'Stop Bidding';
        bidButton.className = 'button stop';
      }
      
      if (bidStatus) {
        bidStatus.textContent = 'Bot is running';
        bidStatus.className = 'status running';
      }
    } else {
      // Bot is not running, update UI to show "Start Bidding"
      if (toggleButton) {
        toggleButton.textContent = 'Start Bidding';
        toggleButton.classList.remove('stop');
      }
      
      if (statusSpan) {
        statusSpan.textContent = 'Stopped';
        statusSpan.className = 'stopped';
      }
      
      if (bidButton) {
        bidButton.textContent = 'Start Bidding';
        bidButton.className = 'button start';
      }
      
      if (bidStatus) {
        bidStatus.textContent = 'Bot is stopped';
        bidStatus.className = 'status stopped';
      }
    }

    // If this is the first install and no activation has occurred, show the free trial section
    if (data.isFirstInstall && (!data.activationStatus || !data.activationStatus.expirationDate)) {
      document.getElementById('initial-trial').style.display = 'block';
      document.getElementById('trial-info').style.display = 'none';
      document.getElementById('license-activation').style.display = 'none';
      countdownBox.style.display = 'none';
      settingsSection.style.display = 'none';
      controlSection.style.display = 'none';
      statusSection.style.display = 'none';
    } else {
      // Not the first install or already activated, check activation status
      checkAndHandleExpiration(data);
    }

    // Update bot status
    if (data.isRunning) {
      updateBotStatus(true);
      startBtn.textContent = 'Bot Running';
      startBtn.disabled = true;
      stopBtn.disabled = false;
      logDiv.innerHTML = 'Bot is actively bidding...';
    } else {
      updateBotStatus(false);
      startBtn.textContent = 'Start Bidding';
      startBtn.disabled = false;
      stopBtn.disabled = true;
      logDiv.innerHTML = 'Bot is ready.';
    }

    // Always load saved settings to ensure they are displayed
    loadSavedSettings();
  });

  function addSettingsListeners() {
    document.querySelectorAll('input[type="number"]').forEach(input => {
      input.addEventListener('change', saveSettings);
    });

    document.querySelectorAll('input[type="checkbox"]').forEach(input => {
      input.addEventListener('change', saveSettings);
    });

    // Update for new excluded subjects and paper types
    const subjectSelect = document.getElementById('excludedSubjects');
    if (subjectSelect) {
      subjectSelect.addEventListener('change', saveSettings);
    }

    const typeOfPaperSelect = document.getElementById('excludedTypesOfPaper');
    if (typeOfPaperSelect) {
      typeOfPaperSelect.addEventListener('change', saveSettings);
    }
  }

  function saveSettings() {
    const settings = {
        minDeadline: parseInt(document.getElementById('minDeadline').value),
        maxPages: parseInt(document.getElementById('maxPages').value),
        maxWords: parseInt(document.getElementById('maxWords').value),
        maxFiles: parseInt(document.getElementById('maxFiles').value),
        maxSources: parseInt(document.getElementById('maxSources').value),
        maxSlides: parseInt(document.getElementById('maxSlides').value),
        maxProblems: parseInt(document.getElementById('maxProblems').value),
        maxQuestions: parseInt(document.getElementById('maxQuestions').value),
        excludeEditing: document.getElementById('excludeEditing').checked,
        excludeParaphrasing: document.getElementById('excludeParaphrasing').checked,
        excludeRewriting: document.getElementById('excludeRewriting').checked,
        noProgressiveDelivery: document.getElementById('noProgressiveDelivery').checked,
        noAbstractPage: document.getElementById('noAbstractPage').checked,
        noSoftCopies: document.getElementById('noSoftCopies').checked,
        requireNoSoftware: document.getElementById('requireNoSoftware').checked,
        excludeTestTopics: document.getElementById('excludeTestTopics').checked,
        excludeRevisionStatus: document.getElementById('excludeRevisionStatus').checked,
        requireWritingFromScratch: document.getElementById('requireWritingFromScratch').checked,
        excludedSubjects: getCheckedValues('excludedSubjects'),
        excludedTypesOfPaper: getCheckedValues('excludedTypesOfPaper')
    };

    chrome.storage.local.set({ settings }, () => {
        showMessage('Settings saved successfully!', 'success');
    });
}

  function setupAutoSave() {
    // Create a debounce function to prevent multiple saves in quick succession
    let saveTimeout = null;
    const debounce = (func, delay) => {
      return function() {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          func.apply(this, arguments);
        }, delay);
      };
    };
    
    // The actual save function
    const performSave = debounce(() => {
      const settings = collectSettings();
      chrome.storage.local.set({ settings }, () => {
        if (chrome.runtime.lastError) {
          console.error('Auto-save failed:', chrome.runtime.lastError);
          showToast('Auto-save failed', 'error');
        } else {
          console.log('Settings auto-saved:', settings);
          // Remove any existing success toasts to prevent stacking
          const toastContainer = document.querySelector('.toast-container');
          if (toastContainer) {
            const successToasts = toastContainer.querySelectorAll('.toast.success');
            successToasts.forEach(toast => {
              if (toast.textContent.includes('Settings auto-saved')) {
                toastContainer.removeChild(toast);
              }
            });
          }
          showToast('Settings auto-saved', 'success');
          chrome.runtime.sendMessage({
            action: 'settings_updated',
            settings: settings
          });
        }
      });
    }, 1000); // Delay by 1 second
    
    // Add change listeners to all inputs and selects
    settingsSection.querySelectorAll('input, select').forEach(input => {
      input.addEventListener('change', performSave);
    });
  }

  startBtn.addEventListener('click', function() {
    if (isStarting || this.disabled) return;

    chrome.storage.local.get(['activationStatus'], function(data) {
      if (!data.activationStatus?.activated || new Date() >= new Date(data.activationStatus.expirationDate)) {
        showMessage('Please activate your license before starting the bot', 'error');
        showToast('Please activate your license first', 'error');
        return;
      }

      // Check if we're on the available orders page first
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (!tabs[0].url?.includes('writedom.com/dashboard/available-orders')) {
          // Add status message in the status area
          logDiv.innerHTML = '<div class="alert alert-error">⚠️ Please navigate to Available Orders page first!</div>';
          statusSpan.textContent = 'Error: Wrong Page';
          statusSpan.style.color = '#ff4444';
          
          // Show notification popup
          showToast('Please navigate to the Available Orders page', 'error');
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: 'Wrong Page',
            message: 'Please navigate to the Available Orders page before starting the bot.',
            priority: 2
          });
          return;
        }

        isStarting = true;
        startBtn.disabled = true;
        startBtn.textContent = 'Starting...';
        stopBtn.disabled = false;
        showToast('Starting the bidding bot...', 'info');

        chrome.tabs.query({ url: 'https://writedom.com/dashboard/available-orders' }, (tabs) => {
          if (tabs.length > 0) {
            const tab = tabs[0];
            chrome.tabs.reload(tab.id, () => {
              chrome.runtime.sendMessage({
                action: 'start_bidding',
                tabId: tab.id
              }, handleStartResponse);
            });
          } else {
            showMessage('Please open the Available Orders page first', 'error');
            showToast('Please open the Available Orders page first', 'error');
            isStarting = false;
            startBtn.disabled = false;
            startBtn.textContent = 'Start Bidding';
            stopBtn.disabled = true;
          }
        });
      });
    });
  });

  function handleStartResponse(response) {
    isStarting = false;
    if (response?.status === 'success') {
      startBtn.textContent = 'Bot Running';
      stopBtn.disabled = false;
      updateBotStatus(true);
      showToast('Bot successfully started!', 'success');
    } else {
      startBtn.textContent = 'Start Bidding';
      startBtn.disabled = false;
      stopBtn.disabled = true;
      showMessage(response?.message || 'Failed to start bot', 'error');
      showToast(response?.message || 'Failed to start bot', 'error');
    }
  }

  stopBtn.addEventListener('click', function() {
    if (this.disabled) return;
    
    stopBtn.disabled = true;
    stopBtn.textContent = 'Stopping...';
    showToast('Stopping the bidding bot...', 'info');

    // Stop bidding without closing tabs
    chrome.runtime.sendMessage({ action: 'stop_bidding' }, function(response) {
        stopBtn.textContent = 'Stop Bidding';
        stopBtn.disabled = false;
        updateBotStatus(false);
        showToast('Bot stopped successfully', 'success');
    });
  });

  saveSettingsBtn.addEventListener('click', function() {
    console.log('Save Settings button clicked');
    saveSettings();
    showMessage('Settings saved successfully!', 'success');
    showToast('Settings saved successfully!', 'success');
  });
  
  if (startTrialBtn) {
    startTrialBtn.addEventListener('click', function() {
      showToast('Starting free trial...', 'info');
      handleTrialStart();
    });
  }
  
  if (showLicenseFormLink) {
    showLicenseFormLink.addEventListener('click', function(e) {
      e.preventDefault();
      document.getElementById('initial-trial').style.display = 'none';
      document.getElementById('license-activation').style.display = 'block';
      showToast('License activation form opened', 'info');
    });
  }
  
  if (activateBtn) {
    activateBtn.addEventListener('click', function() {
      const licenseKey = document.getElementById('licenseKey').value.trim();
      if (!licenseKey) {
        showMessage('Please enter a license key', 'error');
        showToast('Please enter a license key', 'error');
        return;
      }
      
      showToast('Activating license...', 'info');
      chrome.runtime.sendMessage({ 
        action: 'verify_activation_key', 
        key: licenseKey 
      }, handleActivationResponse);
    });
  }
  
  function handleActivationResponse(response) {
    if (response.success) {
      showMessage(response.message || 'License activated successfully!', 'success');
      showToast('License activated successfully!', 'success');
      setTimeout(() => {
        document.getElementById('license-activation').style.display = 'none';
        checkAndHandleExpiration({ activationStatus: { 
          activated: true, 
          expirationDate: response.expirationDate 
        }});
      }, 1000);
    } else {
      showMessage(response.message || 'Failed to activate license', 'error');
      showToast('Failed to activate license', 'error');
    }
  }

  function showSettingsSection() {
    activationSection.style.display = 'none';
    settingsSection.style.display = 'block';
    controlSection.style.display = 'block';
    statusSection.style.display = 'block';
    countdownBox.style.display = 'block';
    loadSavedSettings();
    setupAutoSave();
  }

  function updateBotStatus(isRunning) {
    statusSpan.textContent = isRunning ? 'Running' : 'Idle';
    statusSpan.style.color = isRunning ? '#4CAF50' : '#2196F3';

    startBtn.disabled = isRunning;
    stopBtn.disabled = !isRunning;
    startBtn.style.opacity = isRunning ? '0.6' : '1';
    stopBtn.style.opacity = isRunning ? '1' : '0.6';

    if (isRunning) {
      startBtn.classList.add('running');
      logDiv.innerHTML = 'Bot is actively bidding...';
    } else {
      startBtn.classList.remove('running');
      logDiv.innerHTML = 'Bot is ready.';
    }
  }

  function showMessage(message, type) {
    const msgDiv = document.getElementById('activation-message');
    if (msgDiv) {
      msgDiv.textContent = message;
      msgDiv.className = `message ${type || ''}`;
    }
  }

  function collectSettings() {
    const settings = {
      maxWords: parseInt(document.getElementById('maxWords')?.value) || 2750,
      minDeadline: parseInt(document.getElementById('minDeadline')?.value) || 3,
      maxFiles: parseInt(document.getElementById('maxFiles')?.value) || 5,
      maxPages: parseInt(document.getElementById('maxPages')?.value) || 0,
      maxSlides: parseInt(document.getElementById('maxSlides')?.value) || 0,
      maxProblems: parseInt(document.getElementById('maxProblems')?.value) || 0,
      maxQuestions: parseInt(document.getElementById('maxQuestions')?.value) || 0,
      minSources: parseInt(document.getElementById('minSources')?.value) || 0,
      maxSources: parseInt(document.getElementById('maxSources')?.value) || 50,
      excludeEditing: document.getElementById('excludeEditing')?.checked || false,
      excludeParaphrasing: document.getElementById('excludeParaphrasing')?.checked || false,
      excludeRewriting: document.getElementById('excludeRewriting')?.checked || false,
      noProgressiveDelivery: document.getElementById('noProgressiveDelivery')?.checked || false,
      noAbstractPage: document.getElementById('noAbstractPage')?.checked || false,
      noSoftCopies: document.getElementById('noSoftCopies')?.checked || false,
      requireNoSoftware: document.getElementById('requireNoSoftware')?.checked || false,
      excludeTestTopics: document.getElementById('excludeTestTopics')?.checked || false,
      excludeRevisionStatus: document.getElementById('excludeRevisionStatus')?.checked || false,
      requireWritingFromScratch: document.getElementById('requireWritingFromScratch')?.checked || true
    };

    // Get excluded subjects
    const excludedSubjectsElement = document.getElementById('excludedSubjects');
    if (excludedSubjectsElement) {
      settings.excludedSubjects = [];
      excludedSubjectsElement.querySelectorAll('input:checked').forEach(input => {
        settings.excludedSubjects.push(input.value);
      });
    }

    // Get excluded paper types
    const excludedTypesOfPaperElement = document.getElementById('excludedTypesOfPaper');
    if (excludedTypesOfPaperElement) {
      settings.excludedTypesOfPaper = [];
      excludedTypesOfPaperElement.querySelectorAll('input:checked').forEach(input => {
        settings.excludedTypesOfPaper.push(input.value);
      });
    }

    return settings;
  }

  function loadSavedSettings() {
    chrome.storage.local.get(['settings'], function(data) {
      if (data.settings) {
        const settings = data.settings;
        
        const setInputValue = (id, value, defaultValue) => {
          const input = document.getElementById(id);
          if (input) {
            if (input.type === 'checkbox') {
              input.checked = !!value;
            } else {
              input.value = value !== undefined ? value : defaultValue;
            }
          }
        };

        // Number inputs
        setInputValue('maxWords', settings.maxWords, 2750);
        setInputValue('minDeadline', settings.minDeadline, 3);
        setInputValue('maxFiles', settings.maxFiles, 5);
        setInputValue('maxPages', settings.maxPages, 0);
        setInputValue('maxSlides', settings.maxSlides, 0);
        setInputValue('maxProblems', settings.maxProblems, 0);
        setInputValue('maxQuestions', settings.maxQuestions, 0);
        setInputValue('minSources', settings.minSources, 0);
        setInputValue('maxSources', settings.maxSources, 50);

        // Checkbox inputs
        setInputValue('excludeEditing', settings.excludeEditing, false);
        setInputValue('excludeParaphrasing', settings.excludeParaphrasing, false);
        setInputValue('excludeRewriting', settings.excludeRewriting, false);
        setInputValue('noProgressiveDelivery', settings.noProgressiveDelivery, false);
        setInputValue('noAbstractPage', settings.noAbstractPage, false);
        setInputValue('noSoftCopies', settings.noSoftCopies, false);
        setInputValue('requireNoSoftware', settings.requireNoSoftware, false);
        setInputValue('excludeTestTopics', settings.excludeTestTopics, false);
        setInputValue('excludeRevisionStatus', settings.excludeRevisionStatus, false);
        setInputValue('requireWritingFromScratch', settings.requireWritingFromScratch, true);

        // Handle excluded subjects
        if (settings.excludedSubjects && Array.isArray(settings.excludedSubjects)) {
          const excludedSubjects = document.getElementById('excludedSubjects');
          if (excludedSubjects) {
            excludedSubjects.querySelectorAll('input[type="checkbox"]').forEach(input => {
              input.checked = settings.excludedSubjects.includes(input.value);
            });
          }
        } 
        // Handle legacy format for backward compatibility
        else if (settings.allowedSubjects && Array.isArray(settings.allowedSubjects)) {
          const excludedSubjects = document.getElementById('excludedSubjects');
          if (excludedSubjects) {
            // Get all subject values
            const allSubjects = [];
            excludedSubjects.querySelectorAll('input[type="checkbox"]').forEach(input => {
              allSubjects.push(input.value);
            });
            
            // Check subjects that are not in the allowed list
            excludedSubjects.querySelectorAll('input[type="checkbox"]').forEach(input => {
              input.checked = !settings.allowedSubjects.includes(input.value);
            });
          }
        }

        // Handle excluded paper types
        if (settings.excludedTypesOfPaper && Array.isArray(settings.excludedTypesOfPaper)) {
          const excludedTypesOfPaper = document.getElementById('excludedTypesOfPaper');
          if (excludedTypesOfPaper) {
            excludedTypesOfPaper.querySelectorAll('input[type="checkbox"]').forEach(input => {
              input.checked = settings.excludedTypesOfPaper.includes(input.value);
            });
          }
        }
        // Handle legacy format for backward compatibility
        else if (settings.allowedTypesOfPaper && Array.isArray(settings.allowedTypesOfPaper)) {
          const excludedTypesOfPaper = document.getElementById('excludedTypesOfPaper');
          if (excludedTypesOfPaper) {
            // Get all paper type values
            const allTypes = [];
            excludedTypesOfPaper.querySelectorAll('input[type="checkbox"]').forEach(input => {
              allTypes.push(input.value);
            });
            
            // Check types that are not in the allowed list
            excludedTypesOfPaper.querySelectorAll('input[type="checkbox"]').forEach(input => {
              input.checked = !settings.allowedTypesOfPaper.includes(input.value);
            });
          }
        }
      }
      
      // Set up listeners after loading
      addSettingsListeners();
    });
  }

  function updateCountdown() {
    chrome.storage.local.get(['activationStatus', 'isRunning'], function(data) {
      if (!data.activationStatus || !data.activationStatus.expirationDate) {
        countdownElement.textContent = '--:--:--';
        progressElement.style.width = '0%';
        countdownBox.style.display = 'none';
        return;
      }

      const now = new Date();
      const expiration = new Date(data.activationStatus.expirationDate);
      const timeLeft = expiration - now;

      if (timeLeft <= 0) {
        countdownElement.textContent = '00:00:00';
        progressElement.style.width = '100%';
        expirationDateElement.textContent = 'EXPIRED';
        
        // First stop the bot if it's running
        if (data.isRunning) {
          console.log('License expired: Stopping all bidding activities');
          
          // First send stop message to content script
          chrome.tabs.query({ url: '*://*.writedom.com/dashboard/available-orders' }, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'stop_bidding',
                reason: 'license_expired'
              }).catch(error => {
                console.error('Error sending stop message to tab:', error);
              });
            });
          });

          // Then send force stop to background
          chrome.runtime.sendMessage({ 
            action: 'force_stop_on_expiration', 
            hardStop: true 
          }, function(response) {
            console.log('Force stop response:', response);
            
            // Then trigger the button click for visual feedback
            const stopBiddingBtn = document.getElementById('stopBidding');
            if (stopBiddingBtn) {
              console.log('License expired: Clicking Stop Bidding button');
              stopBiddingBtn.click();
            } else {
              // If the stop button isn't available, call stopBidding function directly
              console.log('License expired: Stop button not found, calling stopBidding function');
              if (typeof stopBidding === 'function') {
                stopBidding();
              }
            }
            
            // After stopping, update UI and show activation
            updateBotStatus(false);
            document.getElementById('license-activation').style.display = 'block';
            document.getElementById('initial-trial').style.display = 'none';
            document.getElementById('trial-info').style.display = 'none';
            settingsSection.style.display = 'none';
            controlSection.style.display = 'none';
            statusSection.style.display = 'none';
            countdownBox.style.display = 'block';

            if (data.activationStatus.keyUsed === 'TRIAL') {
              expiredMessageElement.innerHTML = `
                Your trial has expired. The 5-hour trial is a one-time offer. To continue using the bot, please obtain a 30-day activation key.<br><br>
                <strong>How to get a 30-day key:</strong><br>
                Contact our support team via WhatsApp at <a href="https://wa.me/254707188251" target="_blank">+254707188251</a> (active 24/7) to purchase a 30-day license key.<br>
                Once you have the key, enter it below to reactivate the bot.
              `;
            } else {
              expiredMessageElement.innerHTML = `
                Your 30-day license has expired. To continue using the bot, please obtain a new 30-day activation key.<br><br>
                <strong>How to get a new 30-day key:</strong><br>
                Contact our support team via WhatsApp at <a href="https://wa.me/254707188251" target="_blank">+254707188251</a> (active 24/7) to purchase a 30-day license key.<br>
                Once you have the key, enter it below to reactivate the bot.
              `;
            }
          });
        }

        if (countdownInterval) {
          clearInterval(countdownInterval);
          countdownInterval = null;
        }
      } else {
        let displayTime = '';
        const totalDuration = data.activationStatus.keyUsed === 'TRIAL' ? 
          5 * 60 * 60 * 1000 : 
          30 * 24 * 60 * 60 * 1000;

        if (data.activationStatus.keyUsed === 'TRIAL') {
          const hours = Math.floor(timeLeft / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
          displayTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        } else {
          const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
          const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
          displayTime = `${days}d ${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }

        countdownElement.textContent = displayTime;
        const elapsed = totalDuration - timeLeft;
        const progress = (elapsed / totalDuration) * 100;
        progressElement.style.width = `${Math.min(progress, 100)}%`;
        countdownBox.style.display = 'block';

        console.log('Countdown updated:', {
          timeLeft,
          display: displayTime,
          progress: progress.toFixed(2) + '%'
        });
      }
    });
  }

  function startCountdown() {
    console.log('Starting countdown timer');
    if (countdownInterval) {
      clearInterval(countdownInterval);
    }
    updateCountdown();
    countdownInterval = setInterval(updateCountdown, 1000);
  }

  function checkAndHandleExpiration(data) {
    if (data.activationStatus?.activated && data.activationStatus?.expirationDate) {
      const now = new Date();
      const expiration = new Date(data.activationStatus.expirationDate);
      if (now < expiration) {
        showSettingsSection();
        expirationDateElement.textContent = expiration.toLocaleString();
        startCountdown();
      } else {
        expirationDateElement.textContent = 'EXPIRED';
        activationSection.style.display = 'block';
        document.getElementById('license-activation').style.display = 'block';
        document.getElementById('initial-trial').style.display = 'none';
        document.getElementById('trial-info').style.display = 'none';
        settingsSection.style.display = 'none';
        controlSection.style.display = 'none';
        statusSection.style.display = 'none';

        if (data.activationStatus.keyUsed === 'TRIAL') {
          expiredMessageElement.innerHTML = `
            Your trial has expired. The 5-hour trial is a one-time offer. To continue using the bot, please obtain a 30-day activation key.<br><br>
            <strong>How to get a 30-day key:</strong><br>
            Contact our support team via WhatsApp at <a href="https://wa.me/254707188251" target="_blank">+254707188251</a> (active 24/7) to purchase a 30-day license key.<br>
            Once you have the key, enter it below to reactivate the bot.
          `;
        } else {
          expiredMessageElement.innerHTML = `
            Your 30-day license has expired. To continue using the bot, please obtain a new 30-day activation key.<br><br>
            <strong>How to get a new 30-day key:</strong><br>
            Contact our support team via WhatsApp at <a href="https://wa.me/254707188251" target="_blank">+254707188251</a> (active 24/7) to purchase a 30-day license key.<br>
            Once you have the key, enter it below to reactivate the bot.
          `;
        }
      }
    } else {
      // If not the first install, show the license activation section
      if (!data.isFirstInstall) {
        document.getElementById('initial-trial').style.display = 'none';
        document.getElementById('trial-info').style.display = 'none';
        document.getElementById('license-activation').style.display = 'block';
        countdownBox.style.display = 'none';
        settingsSection.style.display = 'none';
        controlSection.style.display = 'none';
        statusSection.style.display = 'none';
      }
    }
  }

  function handleTrialStart() {
    console.log('Starting trial activation process...');

    // First check if there's an existing valid activation
    chrome.storage.local.get(['activationStatus'], function(data) {
      if (data.activationStatus?.activated && 
          data.activationStatus?.expirationDate && 
          new Date() < new Date(data.activationStatus.expirationDate)) {
        // Use existing activation
        showSettingsSection();
        expirationDateElement.textContent = new Date(data.activationStatus.expirationDate).toLocaleString();
        startCountdown();
        return;
      }

      // Otherwise proceed with new trial activation
      startTrialBtn.disabled = true;
      startTrialBtn.textContent = 'Starting Trial...';

      chrome.runtime.sendMessage({ action: 'start_trial' }, function(response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending start_trial message:', chrome.runtime.lastError);
          startTrialBtn.disabled = false;
          startTrialBtn.textContent = 'Start Free Trial';
          showMessage('Failed to activate trial due to a communication error', 'error');
          return;
        }
        console.log('Trial activation response:', response);

        if (response && response.success) {
          // Set isFirstInstall to false after starting the trial
          chrome.storage.local.set({ isFirstInstall: false }, () => {
            console.log('Set isFirstInstall to false after trial start');
          });

          document.getElementById('initial-trial').style.display = 'none';
          document.getElementById('trial-info').style.display = 'block';
          showSettingsSection();
          expirationDateElement.textContent = new Date(response.endTime).toLocaleString();
          progressElement.style.width = '0%';
          startCountdown();
          showMessage('Trial activated successfully!', 'success');
        } else {
          startTrialBtn.disabled = false;
          startTrialBtn.textContent = 'Start Free Trial';
          showMessage(response?.message || 'Failed to activate trial', 'error');
        }
      });
    });
  }

  window.addEventListener('unload', function() {
    if (countdownInterval) {
      clearInterval(countdownInterval);
    }
  });

  function logToPopup(message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${message}`;
    logDiv.innerHTML = logEntry + '<br>' + logDiv.innerHTML;
  }

  chrome.runtime.onMessage.addListener(function(message) {
    if (message.action === 'bot_stopped') {
      updateBotStatus(false);
      if (message.error) {
        logToPopup(`Bot stopped due to error: ${message.error}`);
        showMessage(`Bot stopped: ${message.error}`, 'error');
      } else {
        logToPopup('Bot stopped completely');
      }
    } else if (message.action === 'no_orders_found') {
      logToPopup(message.message);
    } else if (message.action === 'order_applied') {
      logToPopup(message.message);
      showMessage('Order applied successfully!', 'success');
    } else if (message.action === 'order_apply_failed') {
      logToPopup(message.message);
      showMessage('Failed to apply for an order', 'error');
    } else if (message.action === 'order_skipped') {
      logToPopup(message.message);
    } else if (message.action === 'order_processing_error') {
      logToPopup(message.message);
      showMessage('Error processing an order', 'error');
    } else if (message.type === 'license_expired') {
      stopBotAndShowActivation();
    }

    if (message.action === 'click_stop_button') {
      // Programmatically click the Stop button
      const stopBtn = document.getElementById('stopBidding');
      if (stopBtn && !stopBtn.disabled) {
        stopBtn.click();
      }
    }
  });

  function stopBotAndShowActivation() {
    // Force stop the bot
    chrome.runtime.sendMessage({ action: 'stop_bidding' });
    
    // Update UI
    updateBotStatus(false);
    startBtn.disabled = true;
    startBtn.textContent = 'Start Bidding';
    stopBtn.disabled = true;
    
    // Show activation section
    activationSection.style.display = 'block';
    document.getElementById('license-activation').style.display = 'block';
    document.getElementById('initial-trial').style.display = 'none';
    document.getElementById('trial-info').style.display = 'none';
    settingsSection.style.display = 'none';
    controlSection.style.display = 'none';
    statusSection.style.display = 'none';
  }

  window.onerror = function(msg, url, line) {
    console.error('Error:', msg, 'at', url, ':', line);
    return false;
  };

  // Add CSS styles for the alert messages
  const style = document.createElement('style');
  style.textContent = `
    .alert {
      padding: 10px;
      margin: 10px 0;
      border-radius: 8px;
      font-weight: 500;
      animation: fadeIn 0.3s ease;
    }
    .alert-error {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #fca5a5;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);

  // Setup auto-save for settings
  setupAutoSave();

  // Initialize the bidding state
  updateBiddingState();
  
  // Set up bidding button with more robust handling
  if (bidButton) {
    bidButton.addEventListener('click', function(e) {
      e.preventDefault();
      // Disable the button immediately to prevent double-clicks
      bidButton.disabled = true;
      
      // Show the appropriate message in the button
      if (bidButton.textContent === 'Start Bidding') {
        bidButton.textContent = 'Starting...';
      } else {
        bidButton.textContent = 'Stopping...';
      }
      
      // Toggle the bidding state
      toggleBidding();
    });
  }
  
  // Clear all stored data option
  const clearDataButton = document.getElementById('clearDataButton');
  if (clearDataButton) {
    clearDataButton.addEventListener('click', function() {
      if (confirm('This will clear all stored data. The bot will be stopped. Continue?')) {
        chrome.storage.local.clear(function() {
          showToast('All data cleared successfully!', 'info');
          // Reset UI to default state
          updateBiddingState();
          // Reload popup to reset all inputs
          location.reload();
        });
      }
    });
  }

  // Add debug controls and status dashboard
  function createDebugDashboard() {
    const debugSection = document.createElement('div');
    debugSection.classList.add('debug-section');
    
    // Add title
    const title = document.createElement('h3');
    title.textContent = 'Debug Tools';
    debugSection.appendChild(title);
    
    // Add status display
    const statusDisplay = document.createElement('div');
    statusDisplay.id = 'debug-status-display';
    statusDisplay.innerHTML = `
        <div class="status-row">
            <span class="status-label">Bot Status:</span>
            <span id="bot-status" class="status-value">Inactive</span>
        </div>
        <div class="status-row">
            <span class="status-label">Orders Found:</span>
            <span id="orders-found" class="status-value">0</span>
        </div>
        <div class="status-row">
            <span class="status-label">Orders Processed:</span>
            <span id="orders-processed" class="status-value">0</span>
        </div>
    `;
    debugSection.appendChild(statusDisplay);
    
    // Add debug buttons
    const buttonContainer = document.createElement('div');
    buttonContainer.classList.add('debug-buttons');
    
    // Scan button
    const scanButton = document.createElement('button');
    scanButton.id = 'scan-now-button';
    scanButton.textContent = 'Scan Now';
    scanButton.onclick = triggerImmediateScan;
    buttonContainer.appendChild(scanButton);
    
    // Reset button
    const resetButton = document.createElement('button');
    resetButton.id = 'reset-processed-button';
    resetButton.textContent = 'Reset Processed';
    resetButton.onclick = resetProcessedOrders;
    buttonContainer.appendChild(resetButton);
    
    debugSection.appendChild(buttonContainer);
    
    // Add CSS for debug section
    const style = document.createElement('style');
    style.textContent = `
        .debug-section {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #ccc;
        }
        .debug-section h3 {
            color: #555;
            margin-bottom: 10px;
        }
        .status-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .status-label {
            font-weight: bold;
        }
        .status-value {
            color: #0066cc;
        }
        .debug-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        .debug-buttons button {
            background-color: #555;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        .debug-buttons button:hover {
            background-color: #444;
        }
        #bot-status.active {
            color: green;
            font-weight: bold;
        }
        #bot-status.inactive {
            color: #cc0000;
        }
    `;
    document.head.appendChild(style);
    
    return debugSection;
  }

  // Scan now button function
  function triggerImmediateScan() {
    // Find all active tabs with writedom.com
    chrome.tabs.query({url: "*://*.writedom.com/*", active: true}, function(tabs) {
        if (tabs.length > 0) {
            // Send message to scan now
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'start_immediate_scan'
            }, function(response) {
                console.log('Scan response:', response);
                if (response && response.status) {
                    updateDebugStatus(`Scan complete: ${response.links || 0} links found`);
                } else {
                    updateDebugStatus('Scan failed or no response');
                }
            });
        } else {
            updateDebugStatus('No active Writedom tab found');
        }
    });
  }

  // Reset processed orders function
  function resetProcessedOrders() {
    if (confirm('Are you sure you want to reset all processed orders? This will allow the bot to process all orders again.')) {
        chrome.storage.local.set({
            processedOrders: [],
            processedUrls: []
        }, function() {
            updateDebugStatus('All processed orders have been reset');
            updateDebugCounts();
        });
    }
  }

  // Update debug status text
  function updateDebugStatus(message) {
    const statusEl = document.getElementById('bot-status');
    if (statusEl) {
        statusEl.textContent = message;
    }
  }

  // Update counts in the debug dashboard
  function updateDebugCounts() {
    chrome.storage.local.get(['processedOrders', 'isBidding'], function(data) {
        const ordersProcessedEl = document.getElementById('orders-processed');
        if (ordersProcessedEl) {
            ordersProcessedEl.textContent = (data.processedOrders || []).length;
        }
        
        const botStatusEl = document.getElementById('bot-status');
        if (botStatusEl) {
            if (data.isBidding) {
                botStatusEl.textContent = 'Active';
                botStatusEl.className = 'status-value active';
            } else {
                botStatusEl.textContent = 'Inactive';
                botStatusEl.className = 'status-value inactive';
            }
        }
    });
    
    // Update order count from background
    chrome.runtime.sendMessage({action: 'get_debug_info'}, function(response) {
        if (response && response.orderCount !== undefined) {
            const ordersFoundEl = document.getElementById('orders-found');
            if (ordersFoundEl) {
                ordersFoundEl.textContent = response.orderCount || 0;
            }
        }
    });
  }

  // Add debug dashboard to the page
  const container = document.querySelector('.container');
  if (container) {
    container.appendChild(createDebugDashboard());
  }
  
  // Set up updates for debug panel
  updateDebugCounts();
  
  // Update debug counts every 2 seconds while popup is open
  const debugInterval = setInterval(updateDebugCounts, 2000);
  
  // Clean up interval when popup closes
  window.addEventListener('beforeunload', function() {
    clearInterval(debugInterval);
  });
});

// Update bidding state from storage
function updateBiddingState() {
    chrome.storage.local.get(['isBidding', 'orderCount', 'bidCount'], function (data) {
        const isBidding = data.isBidding || false;
        const orderCount = data.orderCount || 0;
        const bidCount = data.bidCount || 0;
        
        console.log('Updating bidding state UI:', { isBidding, orderCount, bidCount });
        
        const bidButton = document.getElementById('bidButton');
        if (bidButton) {
            bidButton.textContent = isBidding ? 'Stop Bidding' : 'Start Bidding';
            bidButton.className = isBidding ? 'button stop' : 'button start';
            bidButton.disabled = false; // Ensure button is always enabled after state update
        }
        
        const statusElement = document.getElementById('bidStatus');
        if (statusElement) {
            statusElement.textContent = isBidding ? 'Bot is running' : 'Bot is stopped';
            statusElement.className = isBidding ? 'status running' : 'status stopped';
        }
        
        const statsElement = document.getElementById('bidStats');
        if (statsElement) {
            statsElement.textContent = `Orders checked: ${orderCount} | Bids placed: ${bidCount}`;
        }
    });
}

// Toggle bidding state with clearer logic and prevent double-clicking
function toggleBidding() {
    // Get button references
    const bidButton = document.getElementById('bidButton');
    const statusElement = document.getElementById('bidStatus');
    
    // Prevent double-clicking by disabling the button temporarily
    if (bidButton) bidButton.disabled = true;
    
    // First check current state
    chrome.storage.local.get(['isBidding'], function (data) {
        const isBidding = data.isBidding || false;
        
        if (isBidding) {
            stopBidding();
        } else {
            startBidding();
        }
    });
}

// Start bidding with enhanced error handling
function startBidding() {
    // Show "Starting..." status immediately
    const bidButton = document.getElementById('bidButton');
    const statusElement = document.getElementById('bidStatus');
    
    if (bidButton) {
        bidButton.textContent = 'Starting...';
        bidButton.disabled = true;
    }
    
    if (statusElement) {
        statusElement.textContent = 'Starting bot...';
        statusElement.className = 'status starting';
    }
    
    // Display starting toast
    showToast('Starting bidding bot...', 'info');
    
    // Get settings
    chrome.storage.local.get([
        'maxPrice', 'maxCredits', 'maxSlides', 'minPrice', 'minCredits',
        'minSlides', 'maxPages', 'minPages', 'maxWords', 'minWords',
        'minHours', 'maxHours', 'excludedSubjects', 'excludedPaperTypes'
    ], function (settings) {
        console.log('Using settings for bidding:', settings);
        
        // Set bidding to true and reset counters
        const biddingData = {
            isBidding: true,
            isRunning: true, // For legacy compatibility
            orderCount: 0,
            bidCount: 0,
            startTime: new Date().getTime(),
            settings: settings,
            processedOrders: [],
            processedUrls: [],
            orderQueue: []
        };
        
        // First set the local state
        chrome.storage.local.set(biddingData, function () {
            console.log('Bot started with settings:', settings);
            showToast('Bot started successfully!', 'success');
            updateBiddingState();
            
            // Find and get current active tab to use for bidding
            chrome.tabs.query({
                active: true,
                currentWindow: true
            }, function(tabs) {
                if (tabs.length > 0) {
                    const currentTab = tabs[0];
                    
                    // Start bidding in background.js
                    sendMessageWithRetry({
                        action: 'start_bidding',
                        tabId: currentTab.id
                    }, 3);
                    
                    // Re-enable button after a delay
                    setTimeout(() => {
                        if (bidButton) {
                            bidButton.disabled = false;
                        }
                    }, 2000);
                } else {
                    console.error('No active tab found');
                    showToast('Error starting bot: No active tab found', 'error');
                    
                    // Reset button state
                    if (bidButton) {
                        bidButton.textContent = 'Start Bidding';
                        bidButton.className = 'button start';
                        bidButton.disabled = false;
                    }
                    
                    if (statusElement) {
                        statusElement.textContent = 'Bot is stopped';
                        statusElement.className = 'status stopped';
                    }
                    
                    // Reset bidding state since we couldn't start
                    chrome.storage.local.set({
                        isBidding: false,
                        isRunning: false
                    });
                }
            });
        });
    });
}

// Stop bidding with reliable messaging
function stopBidding() {
    // Update UI immediately
    const bidButton = document.getElementById('bidButton');
    const statusElement = document.getElementById('bidStatus');
    
    if (bidButton) {
        bidButton.textContent = 'Stopping...';
        bidButton.disabled = true;
    }
    
    if (statusElement) {
        statusElement.textContent = 'Stopping bot...';
        statusElement.className = 'status stopping';
    }
    
    // Show toast
    showToast('Stopping bidding bot...', 'info');
    
    // Send stop message to background with timeout and retry
    sendMessageWithRetry({
        action: 'stop_bidding',
        hardStop: true
    }, 3, function(response) {
        console.log('Stop bidding response:', response);
        
        // Clear all bidding state
        chrome.storage.local.set({
            isBidding: false,
            isRunning: false, // For legacy compatibility
            isProcessingOrder: false,
            orderQueue: [] // Clear any pending orders
        }, function() {
            console.log('Bot stopped');
            showToast('Bot stopped successfully', 'info');
            updateBiddingState();
            
            // Re-enable button
            if (bidButton) {
                bidButton.disabled = false;
            }
        });
    });
}

// Helper function to send message with retry for reliability
function sendMessageWithRetry(message, retries, callback) {
    try {
        chrome.runtime.sendMessage(message, function(response) {
            const error = chrome.runtime.lastError;
            if (error) {
                console.error('Error sending message:', error);
                if (retries > 0) {
                    console.log(`Retrying message (${retries} attempts left)...`);
                    setTimeout(() => sendMessageWithRetry(message, retries - 1, callback), 500);
                } else {
                    console.error('Failed to send message after all retries');
                    showToast('Communication error. Please try again.', 'error');
                    if (callback) callback({ status: 'error', message: 'Communication error' });
                }
                return;
            }
            
            console.log('Message response:', response);
            if (callback) callback(response);
        });
    } catch (e) {
        console.error('Exception sending message:', e);
        showToast('Error communicating with bot. Please try again.', 'error');
        if (callback) callback({ status: 'error', message: 'Exception sending message' });
    }
}

// Add test function that can be called from popup console
async function testLicenseExpiration() {
  console.log('Starting license expiration test...');
  try {
    const response = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'test_expiration' }, resolve);
    });
    console.log('Test started:', response);
    console.log('The license will expire in 10 seconds.');
    console.log('Watch for:');
    console.log('1. Bot stopping automatically');
    console.log('2. Activation screen appearing');
    console.log('3. Expiration notification');
    return response;
  } catch (error) {
    console.error('Error starting test:', error);
  }
}