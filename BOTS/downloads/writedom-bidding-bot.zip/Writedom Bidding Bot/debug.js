// debug.js
console.log('Debug script loaded on:', window.location.href);

// Add visual debug indicator to show bot is working
function addDebugIndicator() {
  // Remove existing indicator if any
  const existingIndicator = document.getElementById('debug-indicator');
  if (existingIndicator) {
    existingIndicator.remove();
  }
  
  // Create new indicator
  const indicator = document.createElement('div');
  indicator.id = 'debug-indicator';
  indicator.style.position = 'fixed';
  indicator.style.top = '10px';
  indicator.style.right = '10px';
  indicator.style.backgroundColor = 'rgba(0, 0, 255, 0.7)';
  indicator.style.color = 'white';
  indicator.style.padding = '10px';
  indicator.style.borderRadius = '5px';
  indicator.style.zIndex = '9999';
  indicator.style.fontSize = '14px';
  indicator.style.width = '250px';
  indicator.style.maxHeight = '300px';
  indicator.style.overflowY = 'auto';
  
  // Add content
  const title = document.createElement('div');
  title.textContent = 'Writedom Bot Debug 🤖';
  title.style.fontWeight = 'bold';
  title.style.marginBottom = '5px';
  
  const status = document.createElement('div');
  status.id = 'debug-status';
  status.textContent = 'Processing order...';
  
  const orderDetails = document.createElement('div');
  orderDetails.id = 'debug-order-details';
  orderDetails.textContent = 'Order details: Loading...';
  
  // Assemble indicator
  indicator.appendChild(title);
  indicator.appendChild(status);
  indicator.appendChild(orderDetails);
  
  // Add to page
  document.body.appendChild(indicator);
  
  return {
    updateStatus: (text) => {
      const statusEl = document.getElementById('debug-status');
      if (statusEl) statusEl.textContent = text;
    },
    updateOrderDetails: (text) => {
      const detailsEl = document.getElementById('debug-order-details');
      if (detailsEl) detailsEl.textContent = text;
    }
  };
}

// Initialize debug UI
let debugUI = null;

// Check if we're on the available orders page
function isAvailableOrdersPage() {
  return window.location.href.includes('/dashboard/available-orders');
}

// Check if we're on an order details page
function isOrderPage() {
  return window.location.href.includes('/dashboard/orders/');
}

// Helper to check if a link is an order link
function isOrderLink(url) {
  return url && (
    url.includes('/dashboard/order/') || 
    url.includes('/dashboard/orders/') ||
    url.includes('/order/')
  );
}

// Helper to extract order ID from URL
function extractOrderId(url) {
  let match = url.match(/\/dashboard\/order\/(\d+)/);
  if (!match) match = url.match(/\/dashboard\/orders\/(\d+)/);
  if (!match) match = url.match(/\/order\/(\d+)/);
  if (!match) match = url.match(/(\d+)$/);
  return match ? match[1] : null;
}

// Keep track of processed orders locally for faster checking
let processedOrderIds = new Set();
let processedUrls = new Set();

// Load processed orders from storage
function loadProcessedOrders() {
  chrome.storage.local.get(['processedOrders', 'processedUrls', 'isBidding'], function(data) {
    const processedOrdersArray = data.processedOrders || [];
    const processedUrlsArray = data.processedUrls || [];
    
    console.log(`Loaded ${processedOrdersArray.length} processed orders and ${processedUrlsArray.length} processed URLs`);
    
    // Add to our local sets
    processedOrdersArray.forEach(id => processedOrderIds.add(id));
    processedUrlsArray.forEach(url => processedUrls.add(url));
    
    // Update UI if available
    if (debugUI) {
      debugUI.updateStatus('Bot ready');
    }
  });
}

// Find order links on the page
function findOrderLinks() {
  console.log('Finding order links on page');
  
  // Get all links on the page
  const links = Array.from(document.querySelectorAll('a'));
  
  // Filter for order links
  const orderLinks = links.filter(link => {
    const href = link.href;
    return isOrderLink(href) && !processedUrls.has(href);
  });
  
  console.log(`Found ${orderLinks.length} new order links`);
  
  // Update debug UI if available
  if (debugUI) {
    debugUI.updateStatus(`Found ${orderLinks.length} new orders`);
  }
  
  return orderLinks;
}

// Process a single order link
async function processOrderLink(link) {
  const url = link.href;
  const orderId = extractOrderId(url);
  
  if (!orderId) {
    console.log(`Could not extract order ID from URL: ${url}`);
    return;
  }
  
  // Check if already processed
  if (processedOrderIds.has(orderId) || processedUrls.has(url)) {
    console.log(`Order ${orderId} already processed, skipping`);
    return;
  }
  
  console.log(`Processing order ${orderId}`);
  
  // Update debug UI if available
  if (debugUI) {
    debugUI.updateStatus(`Processing order ${orderId}`);
  }
  
  // Add to processed lists
  processedOrderIds.add(orderId);
  processedUrls.add(url);
  
  // Update storage
  chrome.storage.local.get(['processedOrders', 'processedUrls'], function(data) {
    const processedOrdersArray = data.processedOrders || [];
    const processedUrlsArray = data.processedUrls || [];
    
    if (!processedOrdersArray.includes(orderId)) {
      processedOrdersArray.push(orderId);
    }
    
    if (!processedUrlsArray.includes(url)) {
      processedUrlsArray.push(url);
    }
    
    chrome.storage.local.set({
      processedOrders: processedOrdersArray,
      processedUrls: processedUrlsArray
    });
  });
  
  // Navigate to the order
  window.location.href = url;
}

// Detect and process new order links
function detectAndProcessLinks() {
  // Check if bot is active
  chrome.storage.local.get(['isBidding'], function(data) {
    if (!data.isBidding) {
      console.log('Bot is not active, skipping link detection');
      return;
    }
    
    // Find new order links
    const orderLinks = findOrderLinks();
    
    // Process each link
    orderLinks.forEach(link => {
      processOrderLink(link);
    });
  });
}

// Set up mutation observer to detect new links
function setupLinkDetection() {
  // Create a mutation observer to watch for DOM changes
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      if (mutation.addedNodes.length) {
        detectAndProcessLinks();
      }
    });
  });
  
  // Start observing the document with the configured parameters
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Also check periodically
  setInterval(detectAndProcessLinks, 5000);
}

// Speed up order processing
function speedUpOrderProcessing() {
  if (isOrderPage()) {
    console.log('On order page, speeding up processing');
    
    // Initialize debug UI if not already done
    if (!debugUI) {
      debugUI = addDebugIndicator();
    }
    
    // Get the current URL and order ID
    const currentUrl = window.location.href;
    const orderId = extractOrderId(currentUrl);
    
    // Add to processed lists right away
    if (orderId) {
      processedOrderIds.add(orderId);
      processedUrls.add(currentUrl);
      
      // Also update in storage
      chrome.storage.local.get(['processedOrders', 'processedUrls'], function(data) {
        const processedOrdersArray = data.processedOrders || [];
        const processedUrlsArray = data.processedUrls || [];
        
        // Add to arrays if not already there
        if (!processedOrdersArray.includes(orderId)) {
          processedOrdersArray.push(orderId);
        }
        
        if (!processedUrlsArray.includes(currentUrl)) {
          processedUrlsArray.push(currentUrl);
        }
        
        // Update storage
        chrome.storage.local.set({
          processedOrders: processedOrdersArray,
          processedUrls: processedUrlsArray
        }, function() {
          console.log(`Added order ${orderId} to processed lists in storage`);
        });
      });
      
      // Also send a message to notify background script this order is being processed
      chrome.runtime.sendMessage({
        action: 'processing_order',
        orderId: orderId,
        url: currentUrl
      });
    }
  }
}

// Listen for storage changes to update our processed lists
chrome.storage.onChanged.addListener(function(changes) {
  if (changes.processedOrders) {
    const newProcessedOrders = changes.processedOrders.newValue || [];
    console.log(`Storage updated with ${newProcessedOrders.length} processed orders`);
    
    // Update our local set
    processedOrderIds = new Set(newProcessedOrders);
  }
  
  if (changes.processedUrls) {
    const newProcessedUrls = changes.processedUrls.newValue || [];
    console.log(`Storage updated with ${newProcessedUrls.length} processed URLs`);
    
    // Update our local set
    processedUrls = new Set(newProcessedUrls);
  }
});

// Initialize the bot
function initializeBot() {
  console.log('Initializing bot');
  
  // Load processed orders
  loadProcessedOrders();
  
  // Set up link detection if on available orders page
  if (isAvailableOrdersPage()) {
    console.log('On available orders page, setting up link detection');
    setupLinkDetection();
    
    // Do initial scan
    detectAndProcessLinks();
  }
  
  // Speed up order processing if on order page
  if (isOrderPage()) {
    console.log('On order page, speeding up processing');
    speedUpOrderProcessing();
  }
}

// Start the bot when the page loads
document.addEventListener('DOMContentLoaded', initializeBot);

// Also handle navigation events
window.addEventListener('load', initializeBot); 