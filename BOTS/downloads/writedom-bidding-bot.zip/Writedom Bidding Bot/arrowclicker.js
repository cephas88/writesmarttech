(function() {
    // Define the function to click the next page arrow
    function clickNextArrow() {
      const nextButtons = Array.from(document.querySelectorAll('button')).filter(button => {
        const svg = button.querySelector('svg');
        return svg && svg.querySelector('path[d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"]');
      });
      
      if (nextButtons.length) {
        const nextButton = nextButtons[0];
        
        // Check if the button is disabled (using common attributes and classes)
        const isDisabled = nextButton.hasAttribute('disabled') ||
                           nextButton.getAttribute('aria-disabled') === 'true' ||
                           nextButton.classList.contains('disabled');
        
        if (isDisabled) {
          console.warn('Arrow Clicker: Next page arrow button is disabled. Possibly on the last page.');
          return;
        }
        
        console.log('Arrow Clicker: Clicking the next page arrow button...');
        nextButton.click();
      } else {
        console.error('Arrow Clicker: Could not find the next page arrow button.');
      }
    }
    
    // After the page loads, wait 1.5 seconds then attempt to click the next arrow.
    window.addEventListener('load', function() {
      console.log('Arrow Clicker: Page loaded. Waiting 1.5 seconds before attempting to click arrow.');
      setTimeout(clickNextArrow, 1500);
    });
  
    // Also, set an interval to execute the arrow click every 10 seconds (for auto-refresh scenarios)
    setInterval(function() {
      console.log('Arrow Clicker: 10-second interval triggered.');
      clickNextArrow();
    }, 10000);
  })();
  