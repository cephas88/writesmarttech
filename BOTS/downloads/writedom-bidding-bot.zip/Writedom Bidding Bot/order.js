// content.js
console.log('Content script loaded on:', window.location.href);

let orderEvaluated = false;
let monitoringInterval = null;
let refreshInterval = null;

// Wait for an element to appear - with reduced timeout
function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const checkInterval = setInterval(() => {
      const element = document.querySelector(selector);
      if (element) {
        clearInterval(checkInterval);
        resolve(element);
      } else if (Date.now() - startTime > timeout) {
        clearInterval(checkInterval);
        reject(new Error(`Timeout waiting for element: ${selector}`));
      }
    }, 200); // Check more frequently
  });
}

// Find element by text content
function findElementContainingText(text, selector = '*') {
  const elements = document.querySelectorAll(selector);
  for (const element of elements) {
    if (element.textContent.trim().includes(text)) {
      return element;
    }
  }
  return null;
}


// Make sure window.writedomBot is initialized
window.writedomBot = window.writedomBot || {};
window.writedomBot.perPageValue = window.writedomBot.perPageValue || 20;
window.writedomBot.MAX_PER_PAGE = window.writedomBot.MAX_PER_PAGE || 100;

function checkForNewOrders() {
  if (orderEvaluated) {
    console.log('Order already evaluated, skipping check');
    return;
  }

  console.log('Checking for new orders...');
  
  // Set a flag to indicate we're processing an order
  window.orderBeingProcessed = true;
  
  // Wait for the container to appear
  const findContainer = () => {
    const container = document.querySelector('.order-info-table__wrapper');
    
    if (container) {
      console.log('Found order info container, proceeding with evaluation');
      evaluateOrder();
    } else {
      console.log('Order info container not found, retrying in 500ms');
      setTimeout(findContainer, 500);
    }
  };
  
  findContainer();
}

// Add this function to handle order completion
function completeOrderProcessing(orderId, orderUrl) {
  console.log(`Order ${orderId} processing complete, returning to available orders`);
  
  // Mark order as processed
  chrome.runtime.sendMessage({
    action: 'order_complete',
    orderId: orderId,
    url: orderUrl
  });
  
  // Clear the processing flag
  window.orderBeingProcessed = false;
  
  // Navigate back to the available orders page
  chrome.runtime.sendMessage({
    action: 'return_to_available_orders'
  });
}

// Find table row by title - with reduced timeout
async function findRowByTitle(title, valueSelector = '.data-cell', timeout = 3000) {
  try {
    await waitForElement('.combined-info-table-row, .order-details-table', timeout);
    const rows = document.querySelectorAll('.combined-info-table-row, tr');
    for (const row of rows) {
      const titleElement = row.querySelector('.title-cell, th, td:first-child');
      if (titleElement && titleElement.textContent.trim().includes(title)) {
        const valueElement = row.querySelector(valueSelector);
        return valueElement ? valueElement.textContent.trim() : '';
      }
    }
    console.warn(`No row found for title: ${title}`);
    return '';
  } catch (error) {
    console.error(`Error finding row for title ${title}:`, error);
    return '';
  }
}

// Extract order status
function extractOrderStatus() {
  try {
    const statusElement = document.querySelector('.order-status__text--highlited');
    if (statusElement) {
      const status = statusElement.textContent.replace(/\s+/g, ' ').trim();
      console.log('Extracted Order Status:', status);
      return status;
    }
    console.warn('Status element not found using primary selector');

    const statusFallback = document.querySelector('.order-status .order-status__text--highlited');
    if (statusFallback) {
      const status = statusFallback.textContent.replace(/\s+/g, ' ').trim();
      console.log('Extracted Order Status (fallback):', status);
      return status;
    }

    console.warn('Status element not found');
    return '';
  } catch (error) {
    console.error('Error extracting order status:', error);
    return '';
  }
}

// Apply for order function - reduced delay
async function tryApplyOrder() {
  console.log('Attempting to apply for order');
  
  // Try multiple approaches to find the apply button
  let applyButton = null;
  
  // First try standard button selectors
  const buttonSelectors = [
    'button.apply-button',
    'button.btn-apply',
    'button.btn-primary:not([disabled])',
    'button:contains("Apply")',
    'button:contains("apply")',
    'button[type="submit"]',
    'input[type="submit"][value="Apply"]',
    'input[type="submit"][value="apply"]'
  ];
  
  for (const selector of buttonSelectors) {
    try {
      const buttons = document.querySelectorAll(selector);
      for (const button of buttons) {
        if (button && !button.disabled && button.offsetParent !== null) {
          applyButton = button;
          console.log('Found apply button with selector:', selector);
          break;
        }
      }
      if (applyButton) break;
    } catch (e) {
      console.log('Error with selector:', selector, e);
    }
  }
  
  // If not found, try finding by text content
  if (!applyButton) {
    console.log('Trying to find apply button by text content');
    const allButtons = document.querySelectorAll('button, input[type="submit"]');
    for (const button of allButtons) {
      const buttonText = button.textContent.toLowerCase().trim();
      if ((buttonText === 'apply' || buttonText.includes('apply')) && 
          !button.disabled && 
          button.offsetParent !== null) {
        applyButton = button;
        console.log('Found apply button by text content:', buttonText);
        break;
      }
    }
  }
  
  // If still not found, try finding by looking for buttons with specific classes or attributes
  if (!applyButton) {
    console.log('Trying to find apply button by classes or attributes');
    const possibleButtons = document.querySelectorAll('button, input[type="submit"]');
    for (const button of possibleButtons) {
      // Check if button has classes that might indicate it's an apply button
      const hasApplyClass = Array.from(button.classList).some(cls => 
        cls.toLowerCase().includes('apply') || 
        cls.toLowerCase().includes('submit') || 
        cls.toLowerCase().includes('primary')
      );
      
      // Check if button has attributes that might indicate it's an apply button
      const hasApplyAttr = button.getAttribute('data-action')?.toLowerCase().includes('apply') ||
                          button.getAttribute('aria-label')?.toLowerCase().includes('apply');
      
      if ((hasApplyClass || hasApplyAttr) && !button.disabled && button.offsetParent !== null) {
        applyButton = button;
        console.log('Found apply button by class or attribute');
        break;
      }
    }
  }
  
  if (applyButton) {
    console.log('Apply button found, clicking it');
    applyButton.click();
    
    // Wait for confirmation or error message
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Check for success or error messages
    const successMessage = document.querySelector('.alert-success, .success-message, .notification-success');
    const errorMessage = document.querySelector('.alert-danger, .error-message, .notification-error');
    
    if (successMessage) {
      console.log('Successfully applied for order');
      return { success: true, message: 'Successfully applied for order' };
    } else if (errorMessage) {
      console.log('Error applying for order:', errorMessage.textContent);
      return { success: false, message: errorMessage.textContent };
    } else {
      console.log('No confirmation message found, assuming success');
      return { success: true, message: 'No confirmation message found, assuming success' };
    }
  } else {
    console.log('Apply button not found');
    return { success: false, message: 'Apply button not found' };
  }
}

// Extract order details - optimized
async function extractOrderDetails(settings = {}) {
  try {
    console.log('Starting to extract order details');
    
    // Try multiple selectors for the order info table
    let infoTableWrapper = 
      await waitForElement('.order-info-table__wrapper', 6000) ||
      await waitForElement('.combined-info-table-row', 6000) ||
      await waitForElement('.order-info-table', 6000) ||
      await waitForElement('.status.main-info-block', 6000) ||
      await waitForElement('.main-info-block', 6000);
      
    if (!infoTableWrapper) {
      console.log('Order info table not found with standard selectors, trying alternative approach');
      
      // Try to find any table or container that might have order info
      const possibleContainers = document.querySelectorAll('table, .card, .card-body, .status, .main-info-block');
      if (possibleContainers.length > 0) {
        console.log(`Found ${possibleContainers.length} possible containers, using the first one`);
        // Use the first container found
        infoTableWrapper = possibleContainers[0];
      } else {
        throw new Error('Order info table not found');
      }
    }
    
    console.log('Order page content loaded successfully');
    console.log('🔍 Starting detailed criteria check with settings:', settings);

    const details = {
      wordCount: 0,
      deadlineHours: 0,
      fileCount: 0,
      pageCount: 0,
      slideCount: 0,
      problemCount: 0,
      questionCount: 0,
      sourceCount: 0,
      isMixedOrder: false,
      isRevision: false,
      isEditing: false,
      isParaphrasing: false,
      isRewriting: false,
      hasProgressiveDelivery: false,
      hasAbstractPage: false,
      hasSoftCopies: false,
      hasOneDraft: false,
      hasOneSummary: false,
      requiresSoftware: false,
      subject: '',
      typeOfPaper: '',
      isWritingFromScratch: true,
      status: '',
      deadline: 0
    };
    const reasons = [];
    let meetsCriteria = true;

    // Extract word count and page count
    console.log('Attempting to extract pages and words count');
    
    // Try multiple approaches to find the pages/words information
    let pagesWordsRow = document.querySelector('.combined-info-table-row.pages-count-row .data-cell div');
    
    if (!pagesWordsRow) {
      console.log('Standard pages/words row not found, trying alternative selectors');
      pagesWordsRow = 
        document.querySelector('.pages-count-row .data-cell') ||
        document.querySelector('[data-label="Pages"]') ||
        document.querySelector('[data-label="Words"]') ||
        document.querySelector('.data-cell:contains("pages")') ||
        document.querySelector('.data-cell:contains("words")');
    }
    
    if (pagesWordsRow) {
      console.log('Found pages/words element:', pagesWordsRow.outerHTML);
      const pagesWordsText = pagesWordsRow.textContent;
      console.log('Pages/Words text:', pagesWordsText);
      
      // Try multiple regex patterns to extract the information
      const pagesFormat = pagesWordsText.match(/(\d+)\s*pages?\s*\/\s*(?:-|(\d+)\s*words)/i);
      const wordsOnlyFormat = pagesWordsText.match(/(?:-|(\d+)\s*pages?)\s*\/\s*(\d+)\s*words/i);
      const simplePagesFormat = pagesWordsText.match(/(\d+)\s*pages?/i);
      const simpleWordsFormat = pagesWordsText.match(/(\d+)\s*words/i);

      if (pagesFormat) {
        details.pageCount = parseInt(pagesFormat[1]) || 0;
        details.wordCount = pagesFormat[2] ? parseInt(pagesFormat[2]) : details.pageCount * 275;
      } else if (wordsOnlyFormat) {
        details.pageCount = wordsOnlyFormat[1] ? parseInt(wordsOnlyFormat[1]) : 0;
        details.wordCount = parseInt(wordsOnlyFormat[2]) || 0;
      } else if (simplePagesFormat) {
        details.pageCount = parseInt(simplePagesFormat[1]) || 0;
        details.wordCount = details.pageCount * 275; // Estimate words based on pages
      } else if (simpleWordsFormat) {
        details.wordCount = parseInt(simpleWordsFormat[1]) || 0;
        details.pageCount = Math.ceil(details.wordCount / 275); // Estimate pages based on words
      }
      
      console.log('Extracted Pages/Words:', { pagesWordsText, pageCount: details.pageCount, wordCount: details.wordCount });
    } else {
      console.log('Could not find pages/words information, using default values');
      // Set default values if we can't find the information
      details.pageCount = 1;
      details.wordCount = 275;
    }

    // Early check for max pages and words to fail fast
    if (settings.maxPages > 0 && details.pageCount > settings.maxPages) {
      meetsCriteria = false;
      reasons.push(`Page count exceeds maximum allowed: ${details.pageCount} > ${settings.maxPages}`);
    }
    if (settings.maxWords > 0 && details.wordCount > settings.maxWords) {
      meetsCriteria = false;
      reasons.push(`Word count exceeds maximum allowed: ${details.wordCount} > ${settings.maxWords}`);
    }
    
    // If already failing criteria, return early
    if (!meetsCriteria) {
      console.log('Order failed early criteria check, skipping further checks');
      return { meetsCriteria, reasons, details };
    }

    // Process all rows to extract details
    const allRows = document.querySelectorAll('.combined-info-table-row');

    // Extract problems, slides, and questions counts
    const problemsRow = Array.from(allRows).find(row => {
      const titleCell = row.querySelector('.title-cell');
      return titleCell && titleCell.textContent.trim().includes('Problems');
    });
    if (problemsRow) {
      const problemsValue = problemsRow.querySelector('.data-cell')?.textContent;
      details.problemCount = parseInt(problemsValue) || 0;
      console.log('Found Problems:', details.problemCount);
      
      // FIXING: Check if max problems is set to 0 (meaning don't accept any problems)
      if (settings.maxProblems === 0 && details.problemCount > 0) {
        meetsCriteria = false;
        reasons.push(`Problems not allowed (${details.problemCount} found, max is 0)`);
        console.log('Failed criteria: Problems not allowed', details.problemCount);
      } else if (settings.maxProblems > 0 && details.problemCount > settings.maxProblems) {
        meetsCriteria = false;
        reasons.push(`Problem count exceeds maximum allowed: ${details.problemCount} > ${settings.maxProblems}`);
        console.log('Failed criteria: Too many problems', details.problemCount, '>', settings.maxProblems);
      }
    }

    const slidesRow = Array.from(allRows).find(row => {
      const titleCell = row.querySelector('.title-cell');
      return titleCell && titleCell.textContent.trim().includes('Slides');
    });
    if (slidesRow) {
      const slidesValue = slidesRow.querySelector('.data-cell')?.textContent;
      details.slideCount = parseInt(slidesValue) || 0;
      console.log('Found Slides:', details.slideCount);
      
      // FIXING: Check if max slides is set to 0 (meaning don't accept any slides)
      if (settings.maxSlides === 0 && details.slideCount > 0) {
        meetsCriteria = false;
        reasons.push(`Slides not allowed (${details.slideCount} found, max is 0)`);
        console.log('Failed criteria: Slides not allowed', details.slideCount);
      } else if (settings.maxSlides > 0 && details.slideCount > settings.maxSlides) {
        meetsCriteria = false;
        reasons.push(`Slide count exceeds maximum allowed: ${details.slideCount} > ${settings.maxSlides}`);
        console.log('Failed criteria: Too many slides', details.slideCount, '>', settings.maxSlides);
      }
    }

    const questionsRow = Array.from(allRows).find(row => {
      const titleCell = row.querySelector('.title-cell');
      return titleCell && titleCell.textContent.trim().includes('Questions');
    });
    if (questionsRow) {
      const questionsValue = questionsRow.querySelector('.data-cell')?.textContent;
      details.questionCount = parseInt(questionsValue) || 0;
      console.log('Found Questions:', details.questionCount);
      
      // FIXING: Check if max questions is set to 0 (meaning don't accept any questions)
      if (settings.maxQuestions === 0 && details.questionCount > 0) {
        meetsCriteria = false;
        reasons.push(`Questions not allowed (${details.questionCount} found, max is 0)`);
        console.log('Failed criteria: Questions not allowed', details.questionCount);
      } else if (settings.maxQuestions > 0 && details.questionCount > settings.maxQuestions) {
        meetsCriteria = false;
        reasons.push(`Question count exceeds maximum allowed: ${details.questionCount} > ${settings.maxQuestions}`);
        console.log('Failed criteria: Too many questions', details.questionCount, '>', settings.maxQuestions);
      }
    }

    details.status = extractOrderStatus();

    if (settings?.excludeRevisionStatus &&
      (details.status.toLowerCase() === 'revision' ||
        details.status.toLowerCase().includes('revision'))) {
      meetsCriteria = false;
      reasons.push('Order status is Revision, which is excluded');
      console.log('Excluded due to Revision status:', details.status);
      return { meetsCriteria, reasons, details };
    }

    // Extract deadline
    console.log('Attempting to extract deadline');
    
    // Try multiple approaches to find the deadline information
    let deadlineRow = document.querySelector('.combined-info-table-row.deadline-row .data-cell div');
    
    if (!deadlineRow) {
      console.log('Standard deadline row not found, trying alternative selectors');
      deadlineRow = 
        document.querySelector('.deadline-row .data-cell') ||
        document.querySelector('[data-label="Deadline"]') ||
        document.querySelector('.data-cell[data-label="Deadline"]') ||
        document.querySelector('.data-cell[data-label="Due"]') ||
        document.querySelector('.data-cell[data-label="Due Date"]');
      
      // If still not found, try finding by text content
      if (!deadlineRow) {
        console.log('Trying to find deadline by text content');
        const allDataCells = document.querySelectorAll('.data-cell');
        for (const cell of allDataCells) {
          const cellText = cell.textContent.toLowerCase();
          if (cellText.includes('deadline') || cellText.includes('due') || cellText.includes('hours') || cellText.includes('hrs')) {
            deadlineRow = cell;
            console.log('Found deadline cell by text content:', cellText);
            break;
          }
        }
      }
    }
    
    if (deadlineRow) {
      console.log('Found deadline element:', deadlineRow.outerHTML);
      const deadlineText = deadlineRow.textContent;
      console.log('Deadline text:', deadlineText);
      
      // Try multiple regex patterns to extract the deadline
      const deadlineFormat = deadlineText.match(/(\d{1,2})\s*(?:hours?|hrs?)/i);
      const exactTimeFormat = deadlineText.match(/(\d{1,2}):(\d{2})\s*(?:AM|PM)/i);
      const dateTimeFormat = deadlineText.match(/(\d{1,2})\s*(?:hours?|hrs?)\s*from\s*now/i);
      
      if (deadlineFormat) {
        details.deadline = parseInt(deadlineFormat[1]) || 0;
      } else if (exactTimeFormat) {
        const hours = parseInt(exactTimeFormat[1]);
        const minutes = parseInt(exactTimeFormat[2]);
        const isPM = /PM/i.test(deadlineText);
        
        let totalHours = hours;
        if (isPM && hours !== 12) totalHours += 12;
        if (!isPM && hours === 12) totalHours = 0;
        
        details.deadline = totalHours + (minutes / 60);
      } else if (dateTimeFormat) {
        details.deadline = parseInt(dateTimeFormat[1]) || 0;
      }
      
      console.log('Extracted Deadline:', { deadlineText, deadline: details.deadline });
    } else {
      console.log('Could not find deadline information, using default value');
      // Set default value if we can't find the information
      details.deadline = 24; // Default to 24 hours
    }

    const subjectRow = findElementContainingText('Subject:', '.title-cell')?.closest('.combined-info-table-row');
    details.subject = subjectRow?.querySelector('.data-cell')?.textContent.trim() || '';

    const paperTypeRow = findElementContainingText('Type of paper:', '.title-cell')?.closest('.combined-info-table-row');
    details.typeOfPaper = paperTypeRow?.querySelector('.data-cell')?.textContent.trim() || '';

    const workTypeText = await findRowByTitle('Type of work:');
    if (workTypeText) {
      const workTypes = workTypeText.toLowerCase();
      details.isWritingFromScratch = workTypes.includes('writing from scratch');
      details.isRevision = workTypes.includes('revision');
      details.isEditing = workTypes.includes('editing');
      details.isParaphrasing = workTypes.includes('paraphrasing');
      details.isRewriting = workTypes.includes('rewriting');
      details.isMixedOrder = workTypes.split(',').length > 1;
    }

    details.sourceCount = parseInt(document.querySelector('.combined-info-table-row.unit-count-row .data-cell')?.textContent.trim() || 0);

    details.hasProgressiveDelivery = document.querySelector('.combined-info-table-row.progressive-delivery-row .row-data-text')?.textContent.trim().toLowerCase() === 'yes';
    details.hasAbstractPage = document.querySelector('.combined-info-table-row.abstract-page-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.hasSoftCopies = document.querySelector('.combined-info-table-row.soft-copies-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.hasOneDraft = document.querySelector('.combined-info-table-row.one-page-draft-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.hasOneSummary = document.querySelector('.combined-info-table-row.one-page-summary-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.requiresSoftware = document.querySelector('.combined-info-table-row.software-row .data-cell')?.textContent.trim().toLowerCase() !== 'none';

    const booleanChecks = [
      { setting: settings?.excludeRevisions, value: details.isRevision, message: 'Revision' },
      { setting: settings?.excludeEditing, value: details.isEditing, message: 'Editing' },
      { setting: settings?.excludeParaphrasing, value: details.isParaphrasing, message: 'Paraphrasing' },
      { setting: settings?.excludeRewriting, value: details.isRewriting, message: 'Rewriting' },
      { setting: settings?.noProgressiveDelivery, value: details.hasProgressiveDelivery, message: 'Progressive Delivery' },
      { setting: settings?.noAbstractPage, value: details.hasAbstractPage, message: 'Abstract Page' },
      { setting: settings?.noSoftCopies, value: details.hasSoftCopies, message: 'Soft Copies' },
      { setting: settings?.noOneDraft, value: details.hasOneDraft, message: 'One Draft' },
      { setting: settings?.noOneSummary, value: details.hasOneSummary, message: 'One Summary' },
      { setting: settings?.requireNoSoftware, value: details.requiresSoftware, message: 'Software Required' },
      { setting: settings?.skipMixedOrders, value: details.isMixedOrder, message: 'Mixed Order' }
    ];
    booleanChecks.forEach(check => {
      if (check.setting && check.value) {
        meetsCriteria = false;
        reasons.push(`${check.message} not allowed`);
      }
    });

    if (settings?.requireWritingFromScratch && !details.isWritingFromScratch) {
      meetsCriteria = false;
      reasons.push('Must be writing from scratch');
    }
    
    // Check if the subject is in the excluded list
    if (settings?.excludedSubjects?.length > 0 && 
        settings.excludedSubjects.some(s => s.toLowerCase() === details.subject.toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Subject "${details.subject}" is excluded`);
    }
    
    // Check if the paper type is in the excluded list
    if (settings?.excludedTypesOfPaper?.length > 0 && 
        settings.excludedTypesOfPaper.some(t => t.toLowerCase() === details.typeOfPaper.toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Paper type "${details.typeOfPaper}" is excluded`);
    }
    
    // Legacy support for allowedSubjects (inclusion-based)
    if (!settings?.excludedSubjects && settings?.allowedSubjects?.length > 0 && 
        !settings.allowedSubjects.some(s => s.toLowerCase() === details.subject.toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Subject "${details.subject}" not in allowed list`);
    }
    
    // Legacy support for allowedTypesOfPaper (inclusion-based)
    if (!settings?.excludedTypesOfPaper && settings?.allowedTypesOfPaper?.length > 0 && 
        !settings.allowedTypesOfPaper.some(t => t.toLowerCase() === details.typeOfPaper.toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Paper type "${details.typeOfPaper}" not in allowed list`);
    }

    console.log('Order evaluation complete:', { meetsCriteria, reasons, details });

    return { meetsCriteria, reasons, details };

  } catch (error) {
    console.error('Error in extractOrderDetails:', error);
    return { meetsCriteria: false, reasons: [error.message], details: {} };
  }
}

function checkForNewOrders() {
  if (orderEvaluated) {
    console.log('Order already evaluated, skipping check');
    return;
  }

  console.log('Checking for new orders...');
  
  // Set a flag to indicate we're processing an order
  window.orderBeingProcessed = true;
  
  // Wait for the container to appear
  const findContainer = () => {
    const container = document.querySelector('.order-info-table__wrapper');
    
    if (container) {
      console.log('Found order info container, proceeding with evaluation');
      evaluateOrder();
    } else {
      console.log('Order info container not found, retrying in 500ms');
      setTimeout(findContainer, 500);
    }
  };
  
  findContainer();
}

// Add this function to handle order completion
function completeOrderProcessing(orderId, orderUrl) {
  console.log(`Order ${orderId} processing complete, returning to available orders`);
  
  // Mark order as processed
  chrome.runtime.sendMessage({
    action: 'order_complete',
    orderId: orderId,
    url: orderUrl
  });
  
  // Clear the processing flag
  window.orderBeingProcessed = false;
  
  // Navigate back to the available orders page
  chrome.runtime.sendMessage({
    action: 'return_to_available_orders'
  });
}


// Handle the evaluation of the order details
async function evaluateOrder() {
  try {
    console.log('Evaluating order');
    
    // Extract order details
    const orderDetails = await extractOrderDetails();
    const orderId = extractOrderIdFromUrl(window.location.href);
    const url = window.location.href;
    
    // Get user settings and compare criteria
    chrome.storage.local.get(['settings'], function(data) {
      const settings = data.settings || {};
      
      // Check if order meets criteria - compare directly from orderDetails
      // Don't call an external function that might not exist
      let meetsCriteria = true;
      let reasons = [];
      
      // Extract the actual details object from the response
      const details = orderDetails.details || {};
      
      // Perform criteria checks directly here
      
      // Check word count
      if (settings.maxWords > 0 && details.wordCount > settings.maxWords) {
        meetsCriteria = false;
        reasons.push(`Word count exceeds maximum: ${details.wordCount} > ${settings.maxWords}`);
      }
      
      // Check page count
      if (settings.maxPages > 0 && details.pageCount > settings.maxPages) {
        meetsCriteria = false;
        reasons.push(`Page count exceeds maximum: ${details.pageCount} > ${settings.maxPages}`);
      }
      
      // Check slide count
      if (settings.maxSlides === 0 && details.slideCount > 0) {
        meetsCriteria = false;
        reasons.push(`Slides not allowed (${details.slideCount} found)`);
      } else if (settings.maxSlides > 0 && details.slideCount > settings.maxSlides) {
        meetsCriteria = false;
        reasons.push(`Slide count exceeds maximum: ${details.slideCount} > ${settings.maxSlides}`);
      }
      
      // Check problem count
      if (settings.maxProblems === 0 && details.problemCount > 0) {
        meetsCriteria = false;
        reasons.push(`Problems not allowed (${details.problemCount} found)`);
      } else if (settings.maxProblems > 0 && details.problemCount > settings.maxProblems) {
        meetsCriteria = false;
        reasons.push(`Problem count exceeds maximum: ${details.problemCount} > ${settings.maxProblems}`);
      }
      
      // Check question count
      if (settings.maxQuestions === 0 && details.questionCount > 0) {
        meetsCriteria = false;
        reasons.push(`Questions not allowed (${details.questionCount} found)`);
      } else if (settings.maxQuestions > 0 && details.questionCount > settings.maxQuestions) {
        meetsCriteria = false;
        reasons.push(`Question count exceeds maximum: ${details.questionCount} > ${settings.maxQuestions}`);
      }
      
      // Check deadlines
      if (settings.minHours > 0 && details.deadlineHours < settings.minHours) {
        meetsCriteria = false;
        reasons.push(`Deadline too short: ${details.deadlineHours} hours < ${settings.minHours} hours`);
      } else if (settings.maxHours > 0 && details.deadlineHours > settings.maxHours) {
        meetsCriteria = false;
        reasons.push(`Deadline too long: ${details.deadlineHours} hours > ${settings.maxHours} hours`);
      }
      
      // Check for excluded subjects
      if (settings.excludedSubjects && settings.excludedSubjects.length > 0 && 
          settings.excludedSubjects.some(s => s.toLowerCase() === details.subject.toLowerCase())) {
        meetsCriteria = false;
        reasons.push(`Subject "${details.subject}" is excluded`);
      }
      
      // Check for excluded paper types
      if (settings.excludedTypesOfPaper && settings.excludedTypesOfPaper.length > 0 && 
          settings.excludedTypesOfPaper.some(t => t.toLowerCase() === details.typeOfPaper.toLowerCase())) {
        meetsCriteria = false;
        reasons.push(`Paper type "${details.typeOfPaper}" is excluded`);
      }
      
      // Check boolean conditions
      if (settings.excludeRevisions && details.isRevision) {
        meetsCriteria = false;
        reasons.push('Revisions are excluded');
      }
      
      if (settings.excludeEditing && details.isEditing) {
        meetsCriteria = false;
        reasons.push('Editing is excluded');
      }
      
      if (settings.excludeParaphrasing && details.isParaphrasing) {
        meetsCriteria = false;
        reasons.push('Paraphrasing is excluded');
      }
      
      if (settings.excludeRewriting && details.isRewriting) {
        meetsCriteria = false;
        reasons.push('Rewriting is excluded');
      }
      
      if (settings.skipMixedOrders && details.isMixedOrder) {
        meetsCriteria = false;
        reasons.push('Mixed orders are excluded');
      }
      
      if (settings.noProgressiveDelivery && details.hasProgressiveDelivery) {
        meetsCriteria = false;
        reasons.push('Progressive delivery is excluded');
      }
      
      if (settings.noAbstractPage && details.hasAbstractPage) {
        meetsCriteria = false;
        reasons.push('Abstract page is excluded');
      }
      
      if (settings.noSoftCopies && details.hasSoftCopies) {
        meetsCriteria = false;
        reasons.push('Soft copies are excluded');
      }
      
      if (settings.noOneDraft && details.hasOneDraft) {
        meetsCriteria = false;
        reasons.push('One draft is excluded');
      }
      
      if (settings.noOneSummary && details.hasOneSummary) {
        meetsCriteria = false;
        reasons.push('One summary is excluded');
      }
      
      if (settings.requireNoSoftware && details.requiresSoftware) {
        meetsCriteria = false;
        reasons.push('Software requirements are excluded');
      }
      
      if (settings.requireWritingFromScratch && !details.isWritingFromScratch) {
        meetsCriteria = false;
        reasons.push('Only writing from scratch is allowed');
      }

      console.log('Order evaluation results:', { meetsCriteria, reasons, details });
      
      if (meetsCriteria) {
        console.log('Order meets criteria, applying for order');
        applyForOrder();
      } else {
        console.log('Order does not meet criteria:', reasons);
        
        // Send message to background to mark as processed and return to available orders
        chrome.runtime.sendMessage({
          action: 'order_processed',
          orderId: orderId,
          url: url,
          details: {
            ...details,
            skipped: true,
            reasons: reasons
          },
          notifyComplete: true
        }, () => {
                    // Navigate back to available orders after marking as processed
          console.log('Navigating back to available orders after skipping:', reasons);
          window.location.href = 'https://writedom.com/dashboard/available-orders';
        });
      }
    });
  } catch (error) {
    console.error('Error evaluating order:', error);
    // Still return to available orders if there's an error
    returnToAvailableOrders();
  }
   const orderId = extractOrderIdFromUrl(window.location.href);
  completeOrderProcessing(orderId, window.location.href);
}

// Add this helper function to extract order ID from URL
function extractOrderIdFromUrl(url) {
  // Try different URL patterns
  let match = url.match(/\/dashboard\/order\/(\d+)/);
  if (!match) match = url.match(/\/dashboard\/orders\/(\d+)/);
  if (!match) match = url.match(/\/order\/(\d+)/);
  if (!match) match = url.match(/(\d+)$/);
  return match ? match[1] : null;
}

// Add this listener to prevent page refreshes during order processing
window.addEventListener('beforeunload', function(e) {
  if (window.orderBeingProcessed) {
    // Cancel the event
    e.preventDefault();
    // Chrome requires returnValue to be set
    e.returnValue = 'Order is being processed. Are you sure you want to leave?';
  }
});

// Add function to increment bid counter when an order is successfully applied for
async function incrementBidCounter() {
  try {
    const data = await new Promise(resolve => 
      chrome.storage.local.get(['bidCount', 'orderCount'], resolve)
    );
    
    const bidCount = (data.bidCount || 0) + 1;
    const orderCount = (data.orderCount || 0) + 1;
    
    await new Promise(resolve => 
      chrome.storage.local.set({ bidCount, orderCount }, resolve)
    );
    
    console.log(`Updated statistics: orders checked=${orderCount}, bids placed=${bidCount}`);
  } catch (error) {
    console.error('Error incrementing bid counter:', error);
  }
}

// Function to clear monitoring intervals
function clearMonitoringIntervals() {
  if (monitoringInterval) {
    clearInterval(monitoringInterval);
    monitoringInterval = null;
  }
  if (refreshInterval) {
    clearInterval(refreshInterval);
    refreshInterval = null;
  }
}

// Function to start monitoring - faster check interval
function startMonitoring() {
  clearMonitoringIntervals(); // Clear any existing intervals

  // Check for new orders every 0.5 seconds
  monitoringInterval = setInterval(checkForNewOrders, 500);

  // Refresh the page every 7 seconds if no suitable order found
  refreshInterval = setInterval(() => {
    if (!orderEvaluated) {
      console.log('No suitable order found, refreshing page...');
      window.location.reload();
    }
  }, 7000);
}

// Update processOrder function to better handle order processing
async function processOrder() {
  console.log('Starting order processing');
  
  // Extract the order ID from the URL
  const url = window.location.href;
  const orderId = extractOrderIdFromUrl(url);
  
  if (!orderId) {
    console.error('Could not extract order ID from URL');
    // Close the tab if we can't process it
    returnToAvailableOrders();
    return;
  }
  
  console.log(`Processing order ${orderId}`);
  
  // Check if the bot is running
  const isBotRunning = await checkIfBotIsRunning();
  if (!isBotRunning) {
    console.log('Bot is not running, closing tab');
    returnToAvailableOrders();
    return;
  }
  
  // Check if order already processed
  const isProcessed = await checkIfOrderProcessed(orderId, url);
  if (isProcessed) {
    console.log(`Order ${orderId} already processed, closing tab immediately`);
    returnToAvailableOrders();
    return;
  }
  
  // Notify background script that we've started processing
  chrome.runtime.sendMessage({ action: 'processing_started' });
  
  // Wait for order info to load
  await checkForNewOrders();
}

// Function to wait for order info to appear
async function checkForNewOrders() {
  console.log('Checking for order info container');
  
  // Wait for the order info container to appear
  let retryCount = 0;
  const maxRetries = 15; // Increased from 10 to 15
  
  while (retryCount < maxRetries) {
    // For both old and new page structures - using more robust selectors
    const orderContainer = 
      document.querySelector('.order-info-container') || 
      document.querySelector('.order-details') ||
      document.querySelector('.card-body') ||
      document.querySelector('.card') ||
      document.querySelector('.status.main-info-block') || // Added based on user's HTML
      document.querySelector('.main-info-block') ||
      document.querySelector('.order-info-table__wrapper') ||
      document.querySelector('.combined-info-table-row') ||
      document.querySelector('.order-info-table');
    
    if (orderContainer) {
      console.log('Order container found, evaluating order');
      console.log('Container class:', orderContainer.className);
      console.log('Container HTML:', orderContainer.outerHTML.substring(0, 200) + '...');
      await evaluateOrder();
      return;
    }
    
    // Log the current page structure to help diagnose issues
    if (retryCount % 3 === 0) { // Log every 3rd retry to avoid console spam
      console.log(`Order container not found, retrying (${retryCount + 1}/${maxRetries})`);
      console.log('Current page structure:', document.body.innerHTML.substring(0, 500) + '...');
    } else {
      console.log(`Order container not found, retrying (${retryCount + 1}/${maxRetries})`);
    }
    
    retryCount++;
    
    // Wait before trying again - increased from 1000ms to 1500ms
    await new Promise(resolve => setTimeout(resolve, 1500));
  }
  
  console.log('Order container not found after maximum retries, closing tab');
  returnToAvailableOrders();
}

// Function to apply for an order
function applyForOrder() {
  console.log('Attempting to apply for order');
  
  // Use the more robust button detection from tryApplyOrder
  tryApplyOrder().then(result => {
    if (result.success) {
      console.log('Successfully applied for order:', result.message);
      
      // Increment the bid counter
      incrementBidCounter();
      
      // Extract the order ID and URL
      const orderId = extractOrderIdFromUrl(window.location.href);
      const url = window.location.href;
      
      // Send message to background to mark as processed
      chrome.runtime.sendMessage({
        action: 'order_processed',
        orderId: orderId,
        url: url,
        details: {
          applied: true,
          success: true
        },
        notifyComplete: true
      }, () => {
        // Return to available orders page after successful apply
        console.log('Navigating back to available orders after successful apply');
        window.location.href = 'https://writedom.com/dashboard/available-orders';
      });
    } else {
      console.log('Error applying for order:', result.message);
      
      // Still mark as processed to avoid reprocessing
      const orderId = extractOrderIdFromUrl(window.location.href);
      const url = window.location.href;
      
      chrome.runtime.sendMessage({
        action: 'order_processed',
        orderId: orderId,
        url: url,
        details: {
          applied: true,
          success: false,
          error: result.message
        },
        notifyComplete: true
      }, () => {
        // Return to available orders even if there was an error
        console.log('Navigating back to available orders after apply error');
        window.location.href = 'https://writedom.com/dashboard/available-orders';
      });
    }
  });
}

// Function to extract order ID from URL
function extractOrderIdFromUrl(url) {
  if (!url) {
    console.log('URL is null or undefined');
    return null;
  }
  
  console.log('Extracting order ID from URL:', url);
  
  // Handle various URL formats
  let match = url.match(/\/dashboard\/orders\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /dashboard/orders/:', match[1]);
    return match[1];
  }
  
  match = url.match(/\/dashboard\/order\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /dashboard/order/:', match[1]);
    return match[1];
  }
  
  match = url.match(/\/order\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /order/:', match[1]);
    return match[1];
  }
  
  // Try to find any numeric ID at the end of the URL
  match = url.match(/(\d+)(?:\?|$)/);
  if (match) {
    console.log('Found order ID at the end of URL:', match[1]);
    return match[1];
  }
  
  // Try to find ID in query parameters
  const urlObj = new URL(url);
  const idParam = urlObj.searchParams.get('id') || urlObj.searchParams.get('orderId');
  if (idParam) {
    console.log('Found order ID in query parameters:', idParam);
    return idParam;
  }
  
  console.log('Could not extract order ID from URL. URL format not recognized.');
  return null;
}

// Function to return to available orders page
function returnToAvailableOrders() {
  console.log('Processing complete, navigating back to available orders page');
  
  // Notify background that processing is complete
  chrome.runtime.sendMessage({ action: 'processing_complete' });
  
  // Get the order ID and URL
  const orderId = extractOrderIdFromUrl(window.location.href);
  const url = window.location.href;
  
  // Tell background.js this order is processed
  chrome.runtime.sendMessage({
    action: 'order_processed',
    orderId: orderId,
    url: url,
    notifyComplete: true
  }, () => {
    // Navigate back to available orders page
    console.log('Navigating back to available orders page');
    window.location.href = 'https://writedom.com/dashboard/available-orders';
  });
}

// Add a function to check if the bot is running
function checkIfBotIsRunning() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['isBidding'], function(data) {
      resolve(!!data.isBidding);
    });
  });
}

// Check if an order has already been processed
function checkIfOrderProcessed(orderId, url) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({
      action: 'check_if_processed',
      orderId: orderId,
      url: url
    }, function(response) {
      resolve(response ? response.isProcessed : false);
    });
  });
}

// Update the markOrderAsProcessed function to navigate instead of closing tab
async function markOrderAsProcessed() {
  const orderId = window.location.href.match(/\/orders\/(\d+)/)?.[1];
  const currentUrl = window.location.href;
  
  if (!orderId) {
    console.error('Could not extract order ID for marking as processed');
    return;
  }

  try {
    console.log(`Marking order ${orderId} as processed`);
    
    // Extract order details one more time to ensure we send complete data
    const orderDetails = await extractOrderDetails();
    
    // Update order count
    const data = await new Promise(resolve => 
      chrome.storage.local.get(['orderCount'], resolve)
    );
    
    const orderCount = (data.orderCount || 0) + 1;
    await new Promise(resolve => 
      chrome.storage.local.set({ orderCount }, resolve)
    );
    
    // Send message with order details for storage
    await chrome.runtime.sendMessage({
      action: 'order_processed',
      orderId: orderId,
      url: currentUrl,
      details: orderDetails.details || {}, // Include order details
      notifyComplete: true // Add flag to notify background.js processing is complete
    });

    clearMonitoringIntervals();
    orderEvaluated = true;
    
    console.log('Order processed, navigating back to main page...');
    
    // Navigate back to available orders
    window.location.href = 'https://writedom.com/dashboard/available-orders';
  } catch (error) {
    console.error('Error marking order as processed:', error);
    
    // In case of error, still try to navigate back
    try {
      console.log('Navigating back to available orders after error');
      window.location.href = 'https://writedom.com/dashboard/available-orders';
    } catch (e) {
      console.error('Error navigating back:', e);
    }
  }
}

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message in order.js:', message);
  
  if (message.action === 'extract_order_details') {
    (async () => {
      try {
        const details = await extractOrderDetails(message.settings);
        sendResponse({
          status: 'success',
          meetsCriteria: details.meetsCriteria,
          reasons: details.reasons,
          details: details.details
        });
      } catch (error) {
        sendResponse({
          status: 'error',
          message: error.message
        });
      }
    })();
    return true;
  }
  
  // Allow forced processing
  if (message.action === 'force_process_order') {
    console.log('Received force process order message', message);
    setTimeout(() => processOrder(), 500); // Process with a short delay
    if (sendResponse) sendResponse({ status: 'processing_started' });
    return true;
  }
  
  // Make sure we still handle apply_for_order
  if (message.action === 'apply_for_order') {
    console.log('Received apply for order message');
    applyForOrder();
    if (sendResponse) sendResponse({ status: 'applying' });
    return true;
  }
  
  // Make sure we still handle return_to_orders
  if (message.action === 'return_to_orders') {
    console.log('Received return to orders message');
    returnToAvailableOrders();
    if (sendResponse) sendResponse({ status: 'returning' });
    return true;
  }
  
  return true;
});

// Initialize order.js with an immediate check if we're on an order page
(function() {
  if (window.location.href.includes('/dashboard/orders/') || 
      window.location.href.includes('/dashboard/order/') ||
      window.location.href.includes('/order/')) {
    console.log('On order page, checking if should process automatically');
    // Check if the bot is running before auto-processing
    checkIfBotIsRunning().then(isRunning => {
      if (isRunning) {
        console.log('Bot is running, processing order automatically');
        // Use setTimeout to ensure the page has fully loaded
        setTimeout(processOrder, 1000);
      } else {
        console.log('Bot is not running, not auto-processing');
      }
    });
  }
})();

// Add visual debug indicator to show bot is working
function addDebugIndicator() {
  // Remove existing indicator if any
  const existingIndicator = document.getElementById('debug-indicator');
  if (existingIndicator) {
    existingIndicator.remove();
  }
  
  // Create new indicator
  const indicator = document.createElement('div');
  indicator.id = 'debug-indicator';
  indicator.style.position = 'fixed';
  indicator.style.top = '10px';
  indicator.style.right = '10px';
  indicator.style.backgroundColor = 'rgba(0, 0, 255, 0.8)';
  indicator.style.color = 'white';
  indicator.style.padding = '15px';
  indicator.style.borderRadius = '8px';
  indicator.style.zIndex = '9999';
  indicator.style.fontSize = '14px';
  indicator.style.width = '350px';
  indicator.style.maxHeight = '400px';
  indicator.style.overflowY = 'auto';
  indicator.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
  indicator.style.fontFamily = 'Arial, sans-serif';
  
  // Add content
  const title = document.createElement('div');
  title.textContent = 'Writedom Bot Debug 🤖';
  title.style.fontWeight = 'bold';
  title.style.fontSize = '16px';
  title.style.marginBottom = '10px';
  title.style.borderBottom = '1px solid rgba(255,255,255,0.3)';
  title.style.paddingBottom = '5px';
  
  const status = document.createElement('div');
  status.id = 'debug-status';
  status.textContent = 'Processing order...';
  status.style.marginBottom = '8px';
  
  const orderDetails = document.createElement('div');
  orderDetails.id = 'debug-order-details';
  orderDetails.textContent = 'Order details: Loading...';
  orderDetails.style.lineHeight = '1.4';
  
  // Assemble indicator
  indicator.appendChild(title);
  indicator.appendChild(status);
  indicator.appendChild(orderDetails);
  
  // Add to page
  document.body.appendChild(indicator);
  
  return {
    updateStatus: (text) => {
      const statusEl = document.getElementById('debug-status');
      if (statusEl) statusEl.textContent = text;
    },
    updateOrderDetails: (text) => {
      const detailsEl = document.getElementById('debug-order-details');
      if (detailsEl) detailsEl.textContent = text;
    }
  };
}

