(function() {
    let intervalId = null;

    // Define the function to click the next page arrow
    function clickNextArrow() {
        chrome.storage.local.get(['isBidding'], function(data) {
            if (!data.isBidding) {
                console.log('Arrow Clicker: Bot is not running, skipping arrow click.');
                if (intervalId) {
                    clearInterval(intervalId);
                    intervalId = null;
                }
                return;
            }

            const nextButtons = Array.from(document.querySelectorAll('button')).filter(button => {
                const svg = button.querySelector('svg');
                return svg && svg.querySelector('path[d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"]');
            });
            
            if (nextButtons.length) {
                const nextButton = nextButtons[0];
                
                const isDisabled = nextButton.hasAttribute('disabled') ||
                                nextButton.getAttribute('aria-disabled') === 'true' ||
                                nextButton.classList.contains('disabled');
                
                if (isDisabled) {
                    console.log('Arrow Clicker: Next page arrow button is disabled. Possibly on the last page.');
                    return;
                }
                
                console.log('Arrow Clicker: Clicking the next page arrow button...');
                nextButton.click();
            } else {
                console.log('Arrow Clicker: Could not find the next page arrow button.');
            }
        });
    }

    // Listen for bot status changes
    chrome.storage.onChanged.addListener(function(changes, namespace) {
        if (changes.isBidding) {
            if (changes.isBidding.newValue) {
                console.log('Arrow Clicker: Bot started, initializing arrow clicker.');
                setTimeout(clickNextArrow, 1500);
                intervalId = setInterval(clickNextArrow, 10000);
            } else {
                console.log('Arrow Clicker: Bot stopped, cleaning up arrow clicker.');
                if (intervalId) {
                    clearInterval(intervalId);
                    intervalId = null;
                }
            }
        }
    });

    // Check initial state
    chrome.storage.local.get(['isBidding'], function(data) {
        if (data.isBidding) {
            console.log('Arrow Clicker: Bot is running, initializing arrow clicker.');
            setTimeout(clickNextArrow, 1500);
            intervalId = setInterval(clickNextArrow, 10000);
        }
    });
})();
