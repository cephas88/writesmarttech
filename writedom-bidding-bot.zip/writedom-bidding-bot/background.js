// background.js
let processedOrderIds = [];
let isBotRunning = false;
let settings = {};
let currentTabId = null; // Main tab ID (available orders tab)
let refreshInterval = null;
let checkForOrdersRetries = 0;
const MAX_RETRIES = 3;
let isProcessingOrder = false;
let processedOrdersSet = new Set();
let processedUrlsSet = new Set();
const REFRESH_INTERVAL = 10000;
const REFRESH_INTERVAL_WITH_ORDERS = 100000;
let pageRefreshCount = 0;
const MAX_PAGE_REFRESHES = 5;
let lastOrderFoundTime = 0;

// Background script state
let processedOrders = new Map();
let isBidding = false;

chrome.runtime.onInstalled.addListener(() => {
  console.log('Writedom Bidding Bot installed');
  chrome.storage.local.get(['activationStatus', 'processedOrderIds', 'isRunning', 'evaluatedOrders'], (data) => {
    const updates = {};
    if (!data.processedOrderIds) updates.processedOrderIds = [];
    if (!data.isRunning) updates.isRunning = false;
    if (!data.evaluatedOrders) updates.evaluatedOrders = [];
    if (!data.activationStatus) {
      updates.isFirstInstall = true;
      updates.activationStatus = null;
    }
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }
  });
  chrome.storage.local.set({ lastBiddingState: 'stopped' });
});

chrome.runtime.onStartup.addListener(() => {
    // Load processed orders/urls from storage on startup
    chrome.storage.local.get(['processedOrders', 'processedUrls'], (data) => {
        processedOrdersSet = new Set(data.processedOrders || []);
        processedUrlsSet = new Set(data.processedUrls || []);
        console.log('Loaded processed orders:', processedOrdersSet.size);
        console.log('Loaded processed URLs:', processedUrlsSet.size);
    });
});

async function startBidding(tabId) {
  console.log('Starting bidding with tab ID:', tabId);
  
  if (isBotRunning) {
    console.log('Bot already running, not starting again');
    return { status: 'already_running' };
  }
  
  try {
    // Use the existing tab instead of creating a new one
    currentTabId = tabId;
    console.log('Using tab ID:', currentTabId);
    
    // Set bot as running
    isBotRunning = true;
    console.log('Bot is now running');

    // Store state in local storage for persistence
    await chrome.storage.local.set({ 
      isBidding: true,
      isRunning: true,
      lastBiddingState: 'running'
    });
    
    // If tab is not on the available orders page, wait for navigation
    const tab = await chrome.tabs.get(currentTabId);
    if (!tab.url?.includes('dashboard/available-orders')) {
      console.log('Tab not on available orders page, navigating...');
      await chrome.tabs.update(currentTabId, { 
        url: 'https://writedom.com/dashboard/available-orders' 
      });
    }
    
    // Start the refresh loop
    startRefreshLoop();
    
    return { status: 'success', tabId: currentTabId };
  } catch (error) {
    console.error('Error starting bidding:', error);
    return { status: 'error', message: error.message };
  }
}

function startRefreshLoop() {
    if (refreshInterval) clearInterval(refreshInterval);
    
    // Function to handle the refresh
    const refreshPage = async () => {
        if (!isBotRunning || !currentTabId) return;

        try {
            console.log('Starting page refresh and scan...');
            
            // First reload the page
            await chrome.tabs.reload(currentTabId);
            
            // Wait for page to load
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Then scan for orders
            const response = await chrome.tabs.sendMessage(currentTabId, { 
                action: 'start_comprehensive_scan'
            }).catch(() => {
                console.log('Error sending scan message, will try again next refresh');
            });

            // If we found orders, update the refresh interval
            if (response && response.ordersFound > 0) {
                lastOrderFoundTime = Date.now();
                // Update to slower refresh rate since we found orders
                if (refreshInterval) clearInterval(refreshInterval);
                refreshInterval = setInterval(refreshPage, REFRESH_INTERVAL_WITH_ORDERS);
                console.log('Orders found, switching to 20-second refresh interval');
            } else {
                // If it's been more than 30 seconds since we found an order
                // and we're not on the faster refresh rate, switch to it
                if (Date.now() - lastOrderFoundTime > 30000) {
                    if (refreshInterval) clearInterval(refreshInterval);
                    refreshInterval = setInterval(refreshPage, REFRESH_INTERVAL);
                    console.log('No orders found, maintaining 10-second refresh interval');
                }
            }
            
        } catch (error) {
            console.error('Error in refresh loop:', error);
        }
    };
    
    // Start the refresh loop immediately
    refreshPage();
    
    // Set up the interval (starts with 10-second refresh rate)
    refreshInterval = setInterval(refreshPage, REFRESH_INTERVAL);
    console.log('Started refresh loop with 10-second interval');
}

function stopBidding(reason = 'manual') {
  console.log('Stopping bidding process...');
  
  // Set the running flags to false immediately
  isBotRunning = false;
  
  // Clear all timers
  if (refreshInterval) {
    console.log('Clearing refresh interval');
    clearInterval(refreshInterval);
    refreshInterval = null;
  }
  
  // Clear all internal tracking variables
  processedOrderIds = [];
  orderQueue = [];
  processedOrdersSet.clear();
  processedUrlsSet.clear();
  checkForOrdersRetries = 0;
  pageRefreshCount = 0;
  isProcessingOrder = false;
  
  // Clear all timeouts
  const highestTimeoutId = setTimeout(() => {}, 0);
  for (let i = 0; i < highestTimeoutId; i++) {
    clearTimeout(i);
  }

  // Clear storage and reset the isRunning flag without closing tabs
  chrome.storage.local.set({ 
    isRunning: false,
    isBidding: false,
    processedOrderIds: [], 
    evaluatedOrders: [],
    lastBiddingState: 'stopped',
    processedOrders: [],
    processedUrls: [],
    processedOrderDetails: {}
  }, () => {
    console.log('All bot storage cleared');
    
    // Only notify the active tab to stop operations
    if (currentTabId) {
      try {
        chrome.tabs.sendMessage(currentTabId, { 
          action: 'stop_bot',
          reason: reason
        });
      } catch (error) {
        console.error('Error sending stop message to tab:', error);
      }
    }
    
    // Notify popup that the bot has stopped
    chrome.runtime.sendMessage({ action: 'bot_stopped', reason });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message in background.js:', message, 'Bot running:', isBotRunning);
  if (message.action === 'batch_process_orders') {
    console.log(`Received batch of ${message.orderIds.length} orders for processing`);
    
    // Check if we should process concurrently
    if (message.concurrent) {
      processConcurrentOrders(message.orderIds, message.orderUrls);
    } else {
      // Process in batches (existing functionality)
      processBatchOrders(message.orderIds, message.orderUrls);
    }
    
    if (sendResponse) sendResponse({ status: 'processing_batch' });
    return true;
  } else if (message.action === 'return_to_available_orders') {
    // Handle returning to available orders page
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0]) {
        // Navigate back to available orders page
        chrome.tabs.update(tabs[0].id, { 
          url: 'https://writedom.com/dashboard/available-orders' 
        });
      }
    });
    return true;
  }

  if (message.action === 'start_bidding') {
    if (message.tabId) {
      // Ensure we handle this async properly
      (async () => {
        try {
          const result = await startBidding(message.tabId);
          sendResponse(result);
        } catch (error) {
          console.error('Error in start_bidding handler:', error);
          sendResponse({ status: 'error', message: error.message });
        }
      })();
    } else {
      console.error('No tabId provided');
      sendResponse({ status: 'error', message: 'No tab ID provided' });
    }
    return true;
  } else if (message.action === 'stop_bidding') {
    stopBidding();
    sendResponse({ status: 'success', message: 'Bidding stopped' });
  } else if (message.action === 'settings_updated') {
    console.log('Settings updated:', message.settings);
    settings = message.settings;
    sendResponse({ status: 'success', message: 'Settings updated' });
  } else if (message.action === 'start_trial') {
    chrome.storage.local.get(['activationStatus'], (data) => {
      if (data.activationStatus && data.activationStatus.keyUsed === 'TRIAL' && data.activationStatus.expirationDate) {
        console.log('Trial already started, using existing expiration date:', data.activationStatus.expirationDate);
        startExpirationCheck();
        sendResponse({ success: true, endTime: data.activationStatus.expirationDate });
      } else {
        const now = new Date();
        const endTime = new Date(now.getTime() + 5 * 60 * 60 * 1000);
        const activationStatus = {
          activated: true,
          expirationDate: endTime.toISOString(),
          keyUsed: 'TRIAL'
        };
        chrome.storage.local.set({ activationStatus }, () => {
          startExpirationCheck();
          sendResponse({ success: true, endTime: endTime.toISOString() });
        });
      }
    });
    return true;
  } else if (message.action === 'verify_activation_key') {
    chrome.storage.local.get(['activationStatus'], (data) => {
      if (data.activationStatus?.activated && 
          data.activationStatus?.expirationDate && 
          new Date() < new Date(data.activationStatus.expirationDate)) {
        sendResponse({ 
          success: true, 
          expirationDate: data.activationStatus.expirationDate,
          message: 'Using existing valid license' 
        });
        return;
      }
      const key = message.key.trim();
      if (!isValidKeyFormat(key)) {
        sendResponse({ success: false, message: 'Invalid key format' });
        return;
      }
      const now = new Date();
      const endTime = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      const activationStatus = {
        activated: true,
        expirationDate: endTime.toISOString(),
        keyUsed: key
      };
      chrome.storage.local.set({ activationStatus }, () => {
        startExpirationCheck();
        sendResponse({ 
          success: true, 
          expirationDate: endTime.toISOString(), 
          message: 'License activated successfully!' 
        });
      });
    });
    return true;
  } else if (message.action === 'log') {
    console.log('Log from content script:', message.message);
  } else if (message.action === 'order_evaluation_complete') {
    const { orderUrl, meetsCriteria, reasons, orderId } = message;
    console.log(`Order evaluation complete for ${orderUrl}: meetsCriteria=${meetsCriteria}, reasons=${reasons}`);

    if (meetsCriteria) {
      chrome.tabs.sendMessage(sender.tab.id, { action: 'apply_for_order' });
    } else {
      chrome.runtime.sendMessage({ 
        action: 'order_skipped', 
        message: `Skipped order ${orderUrl}: ${reasons.join('; ')}` 
      });
      chrome.tabs.sendMessage(sender.tab.id, { action: 'return_to_orders' });
    }
    return true;
  } else if (message.action === 'processing_started') {
    isProcessingOrder = true;
    console.log('Order processing started, pausing refresh');
    return true;
  } else if (message.action === 'processing_complete') {
    isProcessingOrder = false;
    console.log('Order processing complete, resuming refresh');
    return true;
  } else if (message.action === 'open_order_tab') {
    chrome.tabs.create({ 
        url: message.url,
        active: false // Opens tab in background
    }, tab => {
        console.log(`Opened order ${message.orderId} in tab ${tab.id}`);
        sendResponse({ tabId: tab.id });
    });
    return true;
  } else if (message.action === 'close_order_tab') {
    if (sender.tab) {
        const orderId = message.orderId;
        console.log(`Processing complete for order ${orderId}`);
        
        // Mark as no longer processing
        isProcessingOrder = false;
        
        // Process next in queue
        processConcurrentOrders();
        
        // Notify available.js
        chrome.tabs.query({url: '*://*.writedom.com/dashboard/available-orders'}, (tabs) => {
            if (tabs.length > 0) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'order_complete',
                    orderId: orderId
                });
            }
        });
    }
    if (sendResponse) sendResponse({ status: 'success' });
    return true;
  } else if (message.action === 'open_order') {
    handleOrderOpen(message.url, message.orderId).then(sendResponse);
    return true;
  } else if (message.action === 'get_current_tab') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
            sendResponse({ tabId: tabs[0].id });
        } else {
            sendResponse({ tabId: null });
        }
    });
    return true; // Required for async response
  } else if (message.action === 'order_processed' || message.action === 'order_complete') {
    const orderId = message.orderId;
    const url = message.url;
    const details = message.details;
    
    if (orderId) {
      // Handle order processing complete
      handleOrderProcessingComplete(orderId, url, details);
      console.log(`Order ${orderId} processed and marked complete`);
    }
    
    if (sendResponse) sendResponse({ status: 'success' });
    return true;
  } else if (message.action === 'check_if_processed') {
    const isProcessed = processedOrdersSet.has(message.orderId) || 
                      processedUrlsSet.has(message.url);
    sendResponse({ isProcessed });
    return true;
  } else if (message.action === 'pagination_complete') {
    // Reset refresh counter when pagination is handled
    pageRefreshCount = 0;
    sendResponse({ status: 'acknowledged' });
    return true;
  } else if (message.action === 'batch_process_orders') {
    // Handle batch processing one at a time in main tab
    const { orderIds, orderUrls } = message;
    if (Array.isArray(orderIds) && Array.isArray(orderUrls) && orderIds.length === orderUrls.length) {
      console.log(`Received batch of ${orderIds.length} orders to process one at a time`);
      
      // Add all orders to the queue
      for (let i = 0; i < orderIds.length; i++) {
        const orderId = orderIds[i];
        const url = orderUrls[i];
        
        // Skip if already processed
        if (processedOrdersSet.has(orderId) || processedUrlsSet.has(url)) {
          console.log(`Order ${orderId} already processed, skipping`);
          continue;
        }
        
        // Add to queue
        orderQueue.push({ url, orderId });
        console.log(`Added order ${orderId} to queue. Queue length: ${orderQueue.length}`);
      }
      
      // Start processing if not already processing
      if (!isProcessingOrder) {
        console.log('Starting to process orders from batch');
        processConcurrentOrders();
      } else {
        console.log('Already processing an order, new orders will be processed when current one completes');
      }
      
      sendResponse({ 
        status: 'batch_processing_started', 
        queueLength: orderQueue.length,
        isProcessing: isProcessingOrder
      });
    } else {
      sendResponse({ status: 'error', message: 'Invalid batch data' });
    }
    return true;
  } else if (message.action === 'close_this_tab') {
    // This action is now deprecated - we're navigating instead of closing tabs
    // Just mark the order as processed
    if (sender.tab && message.orderId) {
      console.log(`Order ${message.orderId} processed - keeping tab open for reuse`);
      
      // Add to processed sets to prevent reprocessing
      processedOrdersSet.add(message.orderId);
      if (message.url) {
        processedUrlsSet.add(message.url);
      }
      
      // Mark as processed with details if provided
      addProcessedOrder(message.orderId, message.url, message.details || {});
      
      // Reset processing flag
      isProcessingOrder = false;
    }
    
    if (sendResponse) sendResponse({ status: 'success', navigating: true });
    return true;
  } else if (message.action === 'debug_force_process_links') {
    console.log('Debug: Received force process links message', message.links, 'Bot running:', isBotRunning);
    
    // Only process links if we're running
    if (isBotRunning) {
      const links = message.links || [];
      if (links.length > 0) {
        console.log(`Debug: Processing ${links.length} links from debug message`);
        
        // Filter out already processed links
        const newLinks = links.filter(link => {
          return link && link.url && link.orderId && 
                 !processedOrdersSet.has(link.orderId) && 
                 !processedUrlsSet.has(link.url);
        });
        
        if (newLinks.length > 0) {
          console.log(`Debug: Found ${newLinks.length} new links to process`);
          
          // Process only unique links
          const uniqueOrderMap = new Map();
          newLinks.forEach(link => {
            if (!uniqueOrderMap.has(link.orderId)) {
              uniqueOrderMap.set(link.orderId, link);
            }
          });
          
          const uniqueLinks = Array.from(uniqueOrderMap.values());
          console.log(`Debug: Adding ${uniqueLinks.length} unique orders to queue:`, uniqueLinks);
          
          // Add each order to the queue, avoiding duplicates
          uniqueLinks.forEach(link => {
            // Check if already in queue
            const alreadyInQueue = orderQueue.some(order => 
              order.orderId === link.orderId || order.url === link.url
            );
            
            // Check if already being processed
            const alreadyProcessing = isProcessingOrder && processingTabId !== null;
            
            if (!alreadyInQueue && !alreadyProcessing) {
              orderQueue.push({
                orderId: link.orderId,
                url: link.url
              });
              console.log(`Debug: Added order ${link.orderId} to queue. Queue now has ${orderQueue.length} orders.`);
            } else {
              console.log(`Debug: Order ${link.orderId} already in queue or being processed, skipping`);
            }
          });
          
          // Process the queue, opening up to MAX_CONCURRENT_TABS
          processConcurrentOrders();
        } else {
          console.log('Debug: All links were already processed');
        }
      }
    } else {
      console.log('Debug: Bot not running, ignoring link processing request');
    }
    
    sendResponse({ status: 'processing_links', queued: orderQueue.length });
    return true;
  } else if (message.action === 'get_debug_info') {
    const debugInfo = {
      orderCount: orderQueue.length,
      isProcessing: isProcessingOrder,
      isBotRunning: isBotRunning,
      processedCount: processedOrdersSet.size,
      currentTabId: currentTabId,
      pageRefreshCount: pageRefreshCount
    };
    sendResponse(debugInfo);
    return true;
  } else if (message.action === 'debug_reset_processed') {
    clearProcessedOrders();
    sendResponse({ status: 'reset_complete' });
    return true;
  } else if (message.action === 'debug_processing_order') {
    const orderId = message.orderId;
    const url = message.url;
    
    if (orderId) {
      console.log(`Debug: Order ${orderId} is being processed at ${url}`);
    }
    
    sendResponse({ status: 'acknowledged' });
    return true;
  } else if (message.action === 'force_stop_on_expiration') {
    console.log('Received force stop on expiration command');
    // Call the enhanced force stop function
    forceStopBidding('license_expired').then(() => {
      sendResponse({ status: 'success', message: 'Bidding forcefully stopped due to license expiration' });
    }).catch(error => {
      console.error('Error in force stop:', error);
      sendResponse({ status: 'error', message: error.message });
    });
    return true;
  } else if (message.action === 'force_stop_from_content') {
    console.log('Received force stop from content script due to:', message.reason);
    // Call the enhanced force stop function
    forceStopBidding(message.reason).then(() => {
      sendResponse({ status: 'success', message: 'Bidding forcefully stopped due to license expiration' });
    }).catch(error => {
      console.error('Error in force stop:', error);
      sendResponse({ status: 'error', message: error.message });
    });
    return true;
  } else if (message.action === 'test_expiration') {
    console.log('Starting expiration test...');
    const now = new Date();
    const expirationDate = new Date(now.getTime() + 10000); // 10 seconds from now
    
    chrome.storage.local.set({
      activationStatus: {
        activated: true,
        expirationDate: expirationDate.toISOString(),
        keyUsed: 'TEST-KEY'
      },
      isRunning: true,
      isBidding: true
    }, () => {
      console.log('Test started:', {
        currentTime: now.toISOString(),
        expirationTime: expirationDate.toISOString(),
        timeUntilExpiration: '10 seconds'
      });
      
      // Start countdown in console
      const testInterval = setInterval(() => {
        const timeLeft = expirationDate - new Date();
        console.log(`Time until expiration: ${Math.max(0, Math.floor(timeLeft/1000))} seconds`);
        if (timeLeft <= 0) {
          clearInterval(testInterval);
          console.log('License should expire now. Check that:');
          console.log('1. Bot stopped automatically');
          console.log('2. All Writedom tabs closed');
          console.log('3. Activation UI shows expired state');
          console.log('4. Expiration notification appeared');
        }
      }, 1000);
      
      sendResponse({ status: 'test_started' });
    });
    return true;
  }
});

function notifyOrderProcessed(orderId) {
  if (!processedOrderIds.includes(orderId)) {
    processedOrderIds.push(orderId);
    chrome.storage.local.set({ processedOrderIds }, () => {
      console.log('Updated processed orders:', processedOrderIds);
    });
  }
  
  chrome.tabs.sendMessage(currentTabId, { 
    action: 'order_processed', 
    orderId 
  });
}

async function checkForOrders() {
  if (!isBotRunning || !currentTabId) {
    console.log('Bot is not running or no tab ID, stopping checkForOrders');
    return;
  }

  try {
    const tab = await new Promise((resolve, reject) => {
      chrome.tabs.get(currentTabId, (tab) => {
        if (chrome.runtime.lastError) {
          console.error('Error fetching tab in checkForOrders:', chrome.runtime.lastError);
          reject(chrome.runtime.lastError);
        } else {
          resolve(tab);
        }
      });
    });

    if (!tab || tab.url !== 'https://writedom.com/dashboard/available-orders') {
      console.log('Tab not found or not on available orders page, stopping bot');
      stopBidding();
      return;
    }

    const response = await new Promise((resolve) => {
      chrome.tabs.sendMessage(currentTabId, { action: 'check_for_orders' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error sending message to tab:', chrome.runtime.lastError);
          resolve(null);
        } else {
          resolve(response);
        }
      });
    });

    if (!response) {
      checkForOrdersRetries++;
      if (checkForOrdersRetries >= MAX_RETRIES) {
        await reloadAndRetry();
      }
      return;
    }

    checkForOrdersRetries = 0;

    if (response.orderUrls && response.orderUrls.length > 0) {
      console.log('Found orders:', response.orderUrls);
    }

    if (isBotRunning) {
      setTimeout(checkForOrders, 5000);
    }
  } catch (error) {
    console.error('Error in checkForOrders:', error);
    if (isBotRunning) {
      setTimeout(checkForOrders, 5000);
    }
  }
}

async function reloadAndRetry() {
  console.log('Reloading page and retrying...');
  try {
    await new Promise((resolve) => {
      chrome.tabs.reload(currentTabId, () => {
        setTimeout(resolve, 5000);
      });
    });
    checkForOrdersRetries = 0;
    if (isBotRunning) {
      setTimeout(checkForOrders, 5000);
    }
  } catch (error) {
    console.error('Error in reloadAndRetry:', error);
  }
}

async function forceStopBidding(reason = 'license_expired') {
  try {
    console.log(`Force stopping bidding due to: ${reason}`);
    
    // Immediately set bot as not running
    isBotRunning = false;
    processedOrderIds = [];
    if (refreshInterval) clearInterval(refreshInterval);
    refreshInterval = null;
    
    // Reset bidding state
    isProcessingOrder = false;
    orderQueue = [];
    pageRefreshCount = 0;

    // Find all Writedom-related tabs
    const tabs = await chrome.tabs.query({});
    
    // Find all Writedom tabs
    const writedomTabs = tabs.filter(tab => 
      tab.url?.includes('writedom.com')
    );
    
    console.log(`Found ${writedomTabs.length} Writedom tabs`);
    
    // For each tab, try to send a stop message before closing
    for (const tab of writedomTabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, { 
          action: 'stop_bidding',
          reason: reason
        }).catch(() => {
          // Ignore errors from tabs that can't receive messages
          console.log(`No content script in tab ${tab.id}`);
        });
      } catch (e) {
        console.log(`Error sending message to tab ${tab.id}:`, e);
      }
    }
    
    // Find tabs with active order processing
    const processingTabs = tabs.filter(tab => 
      tab.url?.includes('writedom.com/dashboard/orders/')
    );
    
    // Close all processing tabs
    if (processingTabs.length > 0) {
      console.log(`Closing ${processingTabs.length} order processing tabs...`);
      await chrome.tabs.remove(processingTabs.map(tab => tab.id)).catch(e => {
        console.error('Error closing processing tabs:', e);
      });
    }
    
    // Make sure processing tab reference is cleared
    processingTabId = null;

    // Reset all storage state related to bidding
    await chrome.storage.local.set({ 
      isRunning: false,
      isBidding: false,
      isProcessingOrder: false, 
      processedOrderIds: [],
      orderQueue: [],
      lastBiddingState: 'stopped_by_expiration'
    });

    // Notify popup that bidding has been stopped
    chrome.runtime.sendMessage({
      action: 'bot_stopped',
      reason: reason
    });

    console.log('Bot forcefully stopped due to:', reason);
    return { status: 'success' };
  } catch (error) {
    console.error('Error in forceStopBidding:', error);
    return { status: 'error', message: error.message };
  }
}

function isValidKeyFormat(key) {
  const keyPattern = /^WH-[A-Z][A-Z][0-9][A-Z][0-9][A-Z][0-9][A-Z]$/;
  return keyPattern.test(key);
}

function startExpirationCheck() {
  setInterval(() => {
    chrome.storage.local.get(['activationStatus', 'isRunning', 'isBidding'], async (data) => {
      if (data.activationStatus && data.activationStatus.expirationDate) {
        const now = new Date();
        const expiration = new Date(data.activationStatus.expirationDate);
        
        if (now >= expiration && (data.isRunning || data.isBidding || data.activationStatus.activated)) {
          console.log('License expired, force stopping bot...');
          
          // First, find all Writedom tabs and trigger stop button click
          const tabs = await chrome.tabs.query({url: "*://*.writedom.com/*"});
          for (const tab of tabs) {
            // Inject script to click stop button
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                  const stopButton = document.querySelector('#bidButton, #stopBidding, button.button.stop, button:contains("Stop Bidding")');
                  if (stopButton) {
                    console.log('Found stop button, clicking it...');
                    stopButton.click();
                  }
                }
              });
            } catch (e) {
              console.log('Could not inject stop button click script:', e);
            }
            
            // Also send stop message to content script
            try {
              await chrome.tabs.sendMessage(tab.id, {
                action: 'force_click_stop',
                reason: 'license_expired'
              });
            } catch (e) {
              console.log('Could not send stop message to tab:', tab.id);
            }
          }

          // Wait a moment for stop button click to take effect
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // Then force stop all bidding activities
          await forceStopBidding('license_expired');
          
          // Update storage to reflect expired state
          await chrome.storage.local.set({
            isRunning: false,
            isBidding: false,
            isProcessingOrder: false,
            processedOrderIds: [],
            evaluatedOrders: [],
            lastBiddingState: 'stopped_by_expiration',
            processedOrders: [],
            processedUrls: [],
            processedOrderDetails: {}
          });

          const message = data.activationStatus.keyUsed === 'TRIAL' 
            ? 'Your trial period has expired. Please activate a 30-day license to continue.' 
            : 'Your 30-day license has expired. Please renew to continue.';
          
          // Show notification
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon.png',
            title: 'Writedom Bidding Bot - License Expired',
            message: message,
            priority: 2
          });

          // Notify popup to show activation screen
          chrome.runtime.sendMessage({
            type: 'license_expired',
            message: message,
            wasTrialExpiration: data.activationStatus.keyUsed === 'TRIAL'
          });
        }
      }
    });
  }, 1000); // Check every second
}

if (typeof window !== 'undefined') {
  window.testExpirationBehavior = testExpirationBehavior;
}

function testExpirationBehavior() {
  console.group('🧪 Testing License Expiration Behavior');
  const now = new Date();
  const expirationDate = new Date(now.getTime() + 10000);
  chrome.storage.local.set({
    activationStatus: {
      activated: true,
      expirationDate: expirationDate.toISOString(),
      keyUsed: 'TEST-KEY'
    },
    isRunning: true
  }, () => {
    console.log('Test started:', {
      currentTime: now.toISOString(),
      expirationTime: expirationDate.toISOString(),
      timeUntilExpiration: '10 seconds'
    });
    console.log('Waiting for expiration...');
    const testInterval = setInterval(() => {
      const timeLeft = expirationDate - new Date();
      console.log(`Time until expiration: ${Math.max(0, Math.floor(timeLeft/1000))} seconds`);
      if (timeLeft <= 0) {
        clearInterval(testInterval);
        console.log('License should have expired now. Check that:');
        console.log('1. Bot stopped automatically');
        console.log('2. All Writedom tabs closed');
        console.log('3. Activation UI shows expired state');
        console.log('4. Expiration notification appeared');
      }
    }, 1000);
  });
  console.groupEnd();
}

// Completely rework order processing to use only the main tab
async function handleOrderOpen(url, orderId) {
  console.log(`Handling order open: ${orderId}, URL: ${url}`);
  
  // If bot is not running, do nothing
  if (!isBotRunning) {
    console.log('Bot not running, ignoring order open request');
    return { status: 'not_running' };
  }
  
  // First check if the order or URL is already processed
  if (processedOrdersSet.has(orderId) || processedUrlsSet.has(url)) {
    console.log(`Order ${orderId} or URL ${url} already processed, skipping`);
    return { status: 'already_processed' };
  }
  
  // Double-check with storage to ensure we have the latest data
  const data = await new Promise(resolve => 
    chrome.storage.local.get(['processedOrders', 'processedUrls'], resolve)
  );
  
  const processedOrders = data.processedOrders || [];
  const processedUrls = data.processedUrls || [];
  
  if (processedOrders.includes(orderId) || processedUrls.includes(url)) {
    console.log(`Order ${orderId} or URL ${url} found in storage as processed, skipping`);
    
    // Update our local sets for future checks
    processedOrdersSet.add(orderId);
    if (url) processedUrlsSet.add(url);
    
    return { status: 'already_processed' };
  }
  
  // Check if already processing
  if (isProcessingOrder) {
    console.log(`Already processing an order, queuing order ${orderId}`);
    
    // Add to queue if not already there
    if (!orderQueue.some(order => order.orderId === orderId || order.url === url)) {
      orderQueue.push({ url, orderId });
      console.log(`Added order ${orderId} to queue. Queue length: ${orderQueue.length}`);
    }
    
    return { status: 'queued' };
  }
  
  // Process the order right away
  try {
    await processOrderInSingleTab({ url, orderId });
    return { status: 'success' };
  } catch (error) {
    console.error(`Error handling order ${orderId}:`, error);
    return { status: 'error', message: error.message };
  }
}

// Improved function to process next order in queue
function processNextInQueue() {
  console.log('Processing next in queue. Queue length:', orderQueue.length, 'Is processing:', isProcessingOrder);
  
  // If bot isn't running or already processing an order, don't continue
  if (!isBotRunning) {
    console.log('Bot not running, not processing queue');
    return;
  }
  
  // If no orders in queue, we're done
  if (orderQueue.length === 0) {
    console.log('No orders in queue, stopping processing');
    isProcessingOrder = false;
    return;
  }
  
  // If already processing, don't start another
  if (isProcessingOrder) {
    console.log('Already processing an order, not starting another');
    return;
  }
  
  // Get the next order from the queue
  const nextOrder = orderQueue.shift();
  console.log('Processing next order in queue:', nextOrder);
  
  // Make sure this order isn't already processed before proceeding
  if (processedOrdersSet.has(nextOrder.orderId) || processedUrlsSet.has(nextOrder.url)) {
    console.log(`Order ${nextOrder.orderId} already processed, skipping and moving to next`);
    // Don't set processing flag for skipped orders
    processNextInQueue(); // Process next order immediately
    return;
  }
  
  // Process using single tab approach
  processOrderInSingleTab(nextOrder);
}

// Add these functions for state management
function addProcessedOrder(orderId, url, details = null) {
    if (!orderId) return;
    
    console.log(`Adding order ${orderId} to processed list`);
    
    // Add to memory sets
    processedOrdersSet.add(orderId);
    if (url) {
        processedUrlsSet.add(url);
        console.log(`Added URL to processed list: ${url}`);
    }
    
    // Also add to legacy array for backward compatibility
    if (!processedOrderIds.includes(orderId)) {
        processedOrderIds.push(orderId);
    }
    
    // Store processed orders in more detail if we have them
    chrome.storage.local.get(['processedOrderDetails', 'processedOrders', 'processedUrls'], (data) => {
        const processedOrderDetails = data.processedOrderDetails || {};
        const processedOrders = data.processedOrders || [];
        const processedUrls = data.processedUrls || [];
        
        // Store order details with timestamp
        processedOrderDetails[orderId] = {
            url: url,
            processedAt: new Date().toISOString(),
            details: details || {}
        };
        
        // Make sure the URL is in the processedUrls array
        if (url && !processedUrls.includes(url)) {
            processedUrls.push(url);
        }
        
        // Make sure the orderId is in the processedOrders array
        if (!processedOrders.includes(orderId)) {
            processedOrders.push(orderId);
        }
        
        // Update storage with all data
        chrome.storage.local.set({
            processedOrders: Array.from(new Set([...processedOrders, ...Array.from(processedOrdersSet)])),
            processedUrls: Array.from(new Set([...processedUrls, ...Array.from(processedUrlsSet)])),
            processedOrderIds: processedOrderIds,
            processedOrderDetails: processedOrderDetails
        }, () => {
            console.log(`Successfully stored processed order ${orderId} with URL ${url}`);
        });
    });

    // Notify available.js
    chrome.tabs.query({url: '*://*.writedom.com/dashboard/available-orders*'}, (tabs) => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
                action: 'order_processed',
                orderId: orderId,
                url: url
            });
        });
    });
}

function clearProcessedOrders() {
    processedOrdersSet.clear();
    processedUrlsSet.clear();
    processedOrderIds = [];
    
    chrome.storage.local.set({
        processedOrders: [],
        processedUrls: [],
        processedOrderIds: [],
        processedOrderDetails: {}
    });
}

// Function to process orders concurrently
function processConcurrentOrders(orderIds, orderUrls) {
  console.log(`Processing ${orderIds.length} orders concurrently`);
  
  // Store the orders being processed
  chrome.storage.local.get(['processedOrders', 'processedUrls'], function(data) {
    const processedOrders = data.processedOrders || [];
    const processedUrls = data.processedUrls || [];
    
    // Process each order in a new tab
    orderIds.forEach((orderId, index) => {
      const url = orderUrls[index];
      
      // Skip if already processed
      if (processedOrders.includes(orderId) || processedUrls.includes(url)) {
        console.log(`Order ${orderId} already processed, skipping`);
        return;
      }
      
      // Open in a new tab
      chrome.tabs.create({ 
        url: url,
        active: false // Open in background
      }, function(tab) {
        console.log(`Opened order ${orderId} in tab ${tab.id}`);
        
        // Track this order as being processed
        chrome.storage.local.get(['orderQueue'], function(data) {
          const orderQueue = data.orderQueue || [];
          orderQueue.push({
            orderId: orderId,
            url: url,
            tabId: tab.id,
            status: 'processing',
            timestamp: Date.now()
          });
          
          chrome.storage.local.set({ orderQueue: orderQueue }, function() {
            console.log(`Added order ${orderId} to queue`);
          });
        });
      });
    });
  });
}


// Process an order in a single tab
async function processOrderInSingleTab(order) {
  try {
    console.log(`Processing order ${order.orderId} in single tab`);
    isProcessingOrder = true;
    
    // Check if we already have a processing tab
    if (processingTabId) {
      // Check if the tab still exists
      try {
        const tab = await chrome.tabs.get(processingTabId);
        // If tab exists, navigate to the order
        console.log(`Reusing existing tab ${processingTabId} for order ${order.orderId}`);
        await chrome.tabs.update(processingTabId, { url: order.url });
      } catch (error) {
        // Tab doesn't exist, create a new one
        console.log(`Processing tab doesn't exist, creating new tab for order ${order.orderId}`);
        const newTab = await chrome.tabs.create({
          url: order.url,
          active: false
        });
        processingTabId = newTab.id;
      }
    } else {
      // No processing tab yet, create one
      console.log(`Creating new tab for order ${order.orderId}`);
      const newTab = await chrome.tabs.create({
        url: order.url,
        active: false
      });
      processingTabId = newTab.id;
    }
    
    // Set up an auto-check timeout in case the tab doesn't process the order
    setTimeout(() => {
      // Check if we're still processing this order
      if (isProcessingOrder) {
        console.log(`Order ${order.orderId} processing timed out, marking as processed and moving on`);
        
        // Mark as processed
        addProcessedOrder(order.orderId, order.url, { 
          status: 'timeout', 
          error: 'Order processing timed out' 
        });
        
        // Reset processing flag
        isProcessingOrder = false;
        
        // Navigate back to available orders
        if (processingTabId) {
          chrome.tabs.update(processingTabId, { 
            url: 'https://writedom.com/dashboard/available-orders' 
          });
        }
        
        // Process next order after a delay
        setTimeout(() => {
          processConcurrentOrders();
        }, 2000);
      }
    }, 45000); // 45 second timeout
    
  } catch (error) {
    console.error(`Error processing order ${order.orderId}:`, error);
    
    // Mark as processed to avoid retrying
    addProcessedOrder(order.orderId, order.url, { 
      status: 'error', 
      error: error.message 
    });
    
    // Reset processing flag
    isProcessingOrder = false;
    
    // Process next order
    setTimeout(() => {
      processConcurrentOrders();
    }, 1000);
  }
}

// Update function to handle when order processing is complete
function handleOrderProcessingComplete(orderId, url, details) {
  console.log(`Order ${orderId} processing complete`);
  
  // Mark order as processed
  addProcessedOrder(orderId, url, details);
  
  // Reset processing flag
  isProcessingOrder = false;
  
  // Process next order after a delay to allow page to load
  setTimeout(() => {
    processConcurrentOrders();
  }, 2000);
}

// listen for tab close events to handle when tabs are manually closed
chrome.tabs.onRemoved.addListener((tabId) => {
  // Check if this was our processing tab
  if (processingTabId === tabId) {
    console.log(`Processing tab ${tabId} was manually closed`);
    
    // Reset processing flag
    isProcessingOrder = false;
    processingTabId = null;
    
    // Create a new processing tab for the next order
    setTimeout(() => {
      // Only try to process the next in queue if we're still running
      if (isBotRunning && orderQueue.length > 0) {
        console.log('Processing tab was closed, creating a new one for next order');
        processConcurrentOrders();
      }
    }, 1000);
  }
});

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'start_bot') {
    isBidding = true;
    chrome.storage.local.set({ isBidding: true });
    sendResponse({ status: 'started' });
  }
  
  if (message.action === 'stop_bot') {
    isBidding = false;
    chrome.storage.local.set({ isBidding: false });
    
    // Clear processed orders when stopping
    processedOrders.clear();
    
    // Notify all order tabs to stop processing
    activeOrderTabs.forEach((tabInfo, tabId) => {
      chrome.tabs.sendMessage(tabId, { action: 'stop_bot' });
    });
    
    sendResponse({ status: 'stopped' });
  }

  if (message.action === 'processing_started') {
    if (sender.tab) {
      activeOrderTabs.set(sender.tab.id, {
        url: sender.tab.url,
        timestamp: Date.now()
      });
    }
  }

  if (message.action === 'processing_complete') {
    if (sender.tab) {
      activeOrderTabs.delete(sender.tab.id);
    }
  }

  if (message.action === 'check_if_processed') {
    const isProcessed = processedOrders.has(message.orderId);
    sendResponse({ isProcessed });
  }

  if (message.action === 'order_processed') {
    if (message.orderId) {
      processedOrders.set(message.orderId, {
        url: message.url,
        timestamp: Date.now(),
        details: message.details || {}
      });
      
      // If the tab ID is in our active tabs, remove it
      if (sender.tab) {
        activeOrderTabs.delete(sender.tab.id);
      }
    }
  }

  return true;
});

// Handle tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Only process if the tab is fully loaded and is an order page
  if (changeInfo.status === 'complete' && 
      tab.url && 
      (tab.url.includes('/dashboard/orders/') || 
       tab.url.includes('/dashboard/order/') ||
       tab.url.includes('/order/'))) {
    
    // Check if this tab is already being processed
    if (!activeOrderTabs.has(tabId) && isBidding) {
      chrome.tabs.sendMessage(tabId, { 
        action: 'force_process_order',
        isFirstLoad: true
      });
    }
  }
});

// Handle tab removal
chrome.tabs.onRemoved.addListener((tabId) => {
  activeOrderTabs.delete(tabId);
});

// Clean up old processed orders periodically (every hour)
setInterval(() => {
  const oneHourAgo = Date.now() - (60 * 60 * 1000);
  for (const [orderId, orderInfo] of processedOrders) {
    if (orderInfo.timestamp < oneHourAgo) {
      processedOrders.delete(orderId);
    }
  }
}, 60 * 60 * 1000);

function validateSettings(settings) {
    const validatedSettings = {
        minDeadline: Math.max(0, parseInt(settings.minDeadline) || 3),
        maxPages: Math.max(0, parseInt(settings.maxPages) || 10),
        maxWords: Math.max(0, parseInt(settings.maxWords) || 2750),
        maxFiles: Math.max(0, parseInt(settings.maxFiles) || 15),
        maxSources: Math.max(0, parseInt(settings.maxSources) || 30),
        maxSlides: Math.max(0, parseInt(settings.maxSlides) || 0),
        maxProblems: Math.max(0, parseInt(settings.maxProblems) || 0),
        maxQuestions: Math.max(0, parseInt(settings.maxQuestions) || 0),
        excludeEditing: !!settings.excludeEditing,
        excludeParaphrasing: !!settings.excludeParaphrasing,
        excludeRewriting: !!settings.excludeRewriting,
        noProgressiveDelivery: !!settings.noProgressiveDelivery,
        noAbstractPage: !!settings.noAbstractPage,
        noSoftCopies: !!settings.noSoftCopies,
        requireNoSoftware: !!settings.requireNoSoftware,
        excludeTestTopics: !!settings.excludeTestTopics,
        excludeRevisionStatus: !!settings.excludeRevisionStatus,
        requireWritingFromScratch: settings.requireWritingFromScratch !== false,
        excludedSubjects: Array.isArray(settings.excludedSubjects) ? settings.excludedSubjects : [],
        excludedTypesOfPaper: Array.isArray(settings.excludedTypesOfPaper) ? settings.excludedTypesOfPaper : []
    };

    return validatedSettings;
}