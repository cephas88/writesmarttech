function showNotification(message, isSuccess = true) {
    const existingNotifications = document.querySelectorAll('.order-notification');
    existingNotifications.forEach(n => n.remove());

    const notification = document.createElement('div');
    notification.className = `order-notification ${isSuccess ? 'notification-success' : 'notification-error'}`;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.left = '20px';
    notification.style.zIndex = '9999';
    notification.style.backgroundColor = isSuccess ? '#4CAF50' : '#f44336';
    notification.style.color = 'white';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = '4px';
    notification.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
    notification.style.transition = 'opacity 0.3s';
    notification.style.opacity = '1';
    notification.style.maxWidth = '300px';
    
    // Create a more structured notification content
    const messageContent = document.createElement('div');
    messageContent.style.fontWeight = 'bold';
    messageContent.style.whiteSpace = 'pre-line';  // Preserve line breaks
    messageContent.textContent = message;
    notification.appendChild(messageContent);

    document.body.appendChild(notification);

    // Remove after 4 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 300);
    }, 4000);
}

function showOrderMatchNotification(details) {
    const message = `✅ Order matches criteria - Applying...`;
    showNotification(message, true);
}

function showOrderMismatchNotification(reasons) {
    let message = '❌ Order Skipped\n\nReason(s):\n';
    if (Array.isArray(reasons)) {
        message += reasons.map(reason => `• ${reason}`).join('\n');
    } else {
        message += `• ${reasons}`;
    }
    showNotification(message, false);
}

// Export functions globally but only if we're on an order page
if (window.location.href.includes('/dashboard/orders/') || 
    window.location.href.includes('/dashboard/order/') ||
    window.location.href.includes('/order/')) {
    window.writedomNotifications = {
        showOrderMatchNotification,
        showOrderMismatchNotification
    };
}
