// content.js
console.log('Content script loaded on:', window.location.href);

let orderEvaluated = false;
let monitoringInterval = null;
let refreshInterval = null;

// Wait for an element to appear - with reduced timeout
function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const checkInterval = setInterval(() => {
      const element = document.querySelector(selector);
      if (element) {
        clearInterval(checkInterval);
        resolve(element);
      } else if (Date.now() - startTime > timeout) {
        clearInterval(checkInterval);
        reject(new Error(`Timeout waiting for element: ${selector}`));
      }
    }, 200); // Check more frequently
  });
}

// Find element by text content
function findElementContainingText(text, selector = '*') {
  const elements = document.querySelectorAll(selector);
  for (const element of elements) {
    if (element.textContent.trim().includes(text)) {
      return element;
    }
  }
  return null;
}


// Make sure window.writedomBot is initialized
window.writedomBot = window.writedomBot || {};
window.writedomBot.perPageValue = window.writedomBot.perPageValue || 20;
window.writedomBot.MAX_PER_PAGE = window.writedomBot.MAX_PER_PAGE || 100;

function checkForNewOrders() {
  if (orderEvaluated) {
    console.log('Order already evaluated, skipping check');
    return;
  }

  console.log('Checking for new orders...');
  
  // Set a flag to indicate we're processing an order
  window.orderBeingProcessed = true;
  
  // Wait for the container to appear
  const findContainer = () => {
    const container = document.querySelector('.order-info-table__wrapper');
    
    if (container) {
      console.log('Found order info container, proceeding with evaluation');
      evaluateOrder();
    } else {
      console.log('Order info container not found, retrying in 500ms');
      setTimeout(findContainer, 500);
    }
  };
  
  findContainer();
}

// Add this function to handle order completion
function completeOrderProcessing(orderId, orderUrl) {
  console.log(`Order ${orderId} processing complete, returning to available orders`);
  
  // Mark order as processed
  chrome.runtime.sendMessage({
    action: 'order_complete',
    orderId: orderId,
    url: orderUrl
  });
  
  // Clear the processing flag
  window.orderBeingProcessed = false;
  
  // Navigate back to the available orders page
  chrome.runtime.sendMessage({
    action: 'return_to_available_orders'
  });
}

// Find table row by title - with reduced timeout
async function findRowByTitle(title, valueSelector = '.data-cell', timeout = 3000) {
  try {
    await waitForElement('.combined-info-table-row, .order-details-table', timeout);
    const rows = document.querySelectorAll('.combined-info-table-row, tr');
    for (const row of rows) {
      const titleElement = row.querySelector('.title-cell, th, td:first-child');
      if (titleElement && titleElement.textContent.trim().includes(title)) {
        const valueElement = row.querySelector(valueSelector);
        return valueElement ? valueElement.textContent.trim() : '';
      }
    }
    console.warn(`No row found for title: ${title}`);
    return '';
  } catch (error) {
    console.error(`Error finding row for title ${title}:`, error);
    return '';
  }
}

// Extract order status
function extractOrderStatus() {
  try {
    // Try new structure first
    const statusContainer = document.querySelector('.order-status.main-info-block');
    if (statusContainer) {
      const statusText = statusContainer.querySelector('.order-status__text--highlited')?.textContent || 
                        statusContainer.querySelector('.order-status__text--in-progress')?.textContent;
      if (statusText) {
        const status = statusText.replace(/\s+/g, ' ').trim();
        console.log('Extracted Order Status (new structure):', status);
        return status;
      }
    }

    // Try old structure as fallback
    const statusElement = document.querySelector('.order-status__text--highlited');
    if (statusElement) {
      const status = statusElement.textContent.replace(/\s+/g, ' ').trim();
      console.log('Extracted Order Status (old structure):', status);
      return status;
    }

    // Try other potential selectors
    const fallbackSelectors = [
      '.order-status .order-status__text--highlited',
      '.status .column-text-title + span',
      '.order-status__text',
      '.status-text'
    ];

    for (const selector of fallbackSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        const status = element.textContent.replace(/\s+/g, ' ').trim();
        console.log('Extracted Order Status (fallback):', status);
        return status;
      }
    }

    console.warn('Status element not found with any selector');
    return '';
  } catch (error) {
    console.error('Error extracting order status:', error);
    return '';
  }
}

// Apply for order function - reduced delay
async function tryApplyOrder() {
  console.log('Attempting to apply for order');
  
  // Try multiple approaches to find the apply button
  let applyButton = null;
  
  // First try standard button selectors
  const buttonSelectors = [
    'button.apply-button',
    'button.btn-apply',
    'button.btn-primary:not([disabled])',
    'button:contains("Apply")',
    'button:contains("apply")',
    'button[type="submit"]',
    'input[type="submit"][value="Apply"]',
    'input[type="submit"][value="apply"]'
  ];
  
  for (const selector of buttonSelectors) {
    try {
      const buttons = document.querySelectorAll(selector);
      for (const button of buttons) {
        if (button && !button.disabled && button.offsetParent !== null) {
          applyButton = button;
          console.log('Found apply button with selector:', selector);
          break;
        }
      }
      if (applyButton) break;
    } catch (e) {
      console.log('Error with selector:', selector, e);
    }
  }
  
  // If not found, try finding by text content
  if (!applyButton) {
    console.log('Trying to find apply button by text content');
    const allButtons = document.querySelectorAll('button, input[type="submit"]');
    for (const button of allButtons) {
      const buttonText = button.textContent.toLowerCase().trim();
      if ((buttonText === 'apply' || buttonText.includes('apply')) && 
          !button.disabled && 
          button.offsetParent !== null) {
        applyButton = button;
        console.log('Found apply button by text content:', buttonText);
        break;
      }
    }
  }
  
  // If still not found, try finding by looking for buttons with specific classes or attributes
  if (!applyButton) {
    console.log('Trying to find apply button by classes or attributes');
    const possibleButtons = document.querySelectorAll('button, input[type="submit"]');
    for (const button of possibleButtons) {
      // Check if button has classes that might indicate it's an apply button
      const hasApplyClass = Array.from(button.classList).some(cls => 
        cls.toLowerCase().includes('apply') || 
        cls.toLowerCase().includes('submit') || 
        cls.toLowerCase().includes('primary')
      );
      
      // Check if button has attributes that might indicate it's an apply button
      const hasApplyAttr = button.getAttribute('data-action')?.toLowerCase().includes('apply') ||
                          button.getAttribute('aria-label')?.toLowerCase().includes('apply');
      
      if ((hasApplyClass || hasApplyAttr) && !button.disabled && button.offsetParent !== null) {
        applyButton = button;
        console.log('Found apply button by class or attribute');
        break;
      }
    }
  }
  
  if (applyButton) {
    console.log('Apply button found, clicking it');
    applyButton.click();
    
    // Wait for confirmation or error message
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Check for success or error messages
    const successMessage = document.querySelector('.alert-success, .success-message, .notification-success');
    const errorMessage = document.querySelector('.alert-danger, .error-message, .notification-error');
    
    if (successMessage) {
      console.log('Successfully applied for order');
      return { success: true, message: 'Successfully applied for order' };
    } else if (errorMessage) {
      console.log('Error applying for order:', errorMessage.textContent);
      return { success: false, message: errorMessage.textContent };
    } else {
      console.log('No confirmation message found, assuming success');
      return { success: true, message: 'No confirmation message found, assuming success' };
    }
  } else {
    console.log('Apply button not found');
    return { success: false, message: 'Apply button not found' };
  }
}

// Extract order details - optimized
async function extractOrderDetails(settings = {}) {
  try {
    console.log('Starting to extract order details');
    
    const details = {
      wordCount: 0,
      deadlineHours: 0,
      fileCount: 0,
      pageCount: 0,
      slideCount: 0,
      problemCount: 0,
      questionCount: 0,
      sourceCount: 0,
      price: 0,
      isMixedOrder: false,
      isRevision: false,
      isEditing: false,
      isParaphrasing: false,
      isRewriting: false,
      hasProgressiveDelivery: false,
      hasAbstractPage: false,
      hasSoftCopies: false,
      subject: '',
      typeOfPaper: '',
      isWritingFromScratch: true,
      status: '',
      deadline: 0,
      topic: '',
      clientFiles: [],
      requiresSoftware: false,
      softwareSection: '',
      status: extractOrderStatus(), // Use the improved status extraction function
      isTestTopic: false
    };

    // Get table cells for the order row
    const cells = document.querySelectorAll('tr td');
    if (cells.length >= 8) { // Make sure we have enough cells
      // Cell indices: Topic(1), Price(2), Pages(3), Slides(4), Problems(5), Questions(6), Subject(7)
      details.topic = cells[1].textContent.trim();
      details.price = parseFloat(cells[2].textContent.replace('$', '')) || 0;
      details.pageCount = parseInt(cells[3].textContent) || 0;
      details.slideCount = parseInt(cells[4].textContent) || 0;
      details.problemCount = parseInt(cells[5].textContent) || 0;
      details.questionCount = parseInt(cells[6].textContent) || 0;
      details.subject = cells[7].textContent.trim();
    }

    // If page count is 0, try to find direct word count
    if (details.pageCount === 0) {
      // Try to find word count in the Pages / Words row
      const pagesWordsRow = document.querySelector('.combined-info-table-row.pages-count-row');
      if (pagesWordsRow) {
        const wordsText = pagesWordsRow.querySelector('.data-cell')?.textContent || '';
        const wordMatch = wordsText.match(/(\d+)\s*words?/i);
        if (wordMatch) {
          details.wordCount = parseInt(wordMatch[1]);
          console.log('Found direct word count:', details.wordCount);
        }
      }
    } else {
      // Calculate word count based on pages if no direct word count found
      details.wordCount = details.pageCount * 275;
    }

    // Extract deadline - updated to handle days, hours, and minutes
    const deadlineContainer = document.querySelector('.deadline-container') || 
                            document.querySelector('.deadline .column-text-title + span') ||
                            document.querySelector('.deadline span:last-child');
                            
    if (deadlineContainer) {
      const deadlineText = deadlineContainer.textContent.trim();
      console.log('Found deadline text:', deadlineText);
      
      // Handle "X days Y hours" format
      const daysHoursMatch = deadlineText.match(/(\d+)\s*days?\s*(?:(\d+)\s*hours?)?/i);
      if (daysHoursMatch) {
        const days = parseInt(daysHoursMatch[1]);
        const hours = daysHoursMatch[2] ? parseInt(daysHoursMatch[2]) : 0;
        details.deadline = (days * 24) + hours;
        console.log(`Extracted deadline: ${days} days and ${hours} hours = ${details.deadline} hours`);
      } else {
        // Handle "X hours Y min" format
        const hoursMinMatch = deadlineText.match(/(\d+)\s*hours?\s*(?:(\d+)\s*min)?/i);
        if (hoursMinMatch) {
          const hours = parseInt(hoursMinMatch[1]);
          const minutes = hoursMinMatch[2] ? parseInt(hoursMinMatch[2]) : 0;
          details.deadline = hours + (minutes / 60);
          console.log(`Extracted deadline: ${hours} hours and ${minutes} minutes = ${details.deadline} hours`);
        } else {
          // Try just days format
          const daysMatch = deadlineText.match(/(\d+)\s*days?/i);
          if (daysMatch) {
            details.deadline = parseInt(daysMatch[1]) * 24;
            console.log(`Extracted deadline: ${details.deadline} hours (${daysMatch[1]} days)`);
          } else {
            // Try just hours format
            const hoursMatch = deadlineText.match(/(\d+)\s*hours?/i);
            if (hoursMatch) {
              details.deadline = parseInt(hoursMatch[1]);
              console.log(`Extracted deadline: ${details.deadline} hours`);
            }
          }
        }
      }
    }

    // Extract attached files
    const fileLinks = document.querySelectorAll('li a[href*="download"]');
    details.fileCount = fileLinks.length;
    fileLinks.forEach(link => {
      const fileName = link.textContent.split('|').pop().trim();
      details.clientFiles.push({
        name: fileName,
        url: link.href
      });
    });

    // Helper function to find row by specific classes and title
    function findRowByClasses(text, classes) {
      const rows = document.querySelectorAll(classes);
      for (const row of rows) {
        const titleCell = row.querySelector('.title-cell');
        if (titleCell && titleCell.textContent.trim().includes(text)) {
          return row;
        }
      }
      return null;
    }

    // Extract type of work and writing type
    const workTypeRow = findRowByClasses('Type of work', '.combined-info-table-row');
    if (workTypeRow) {
      const workTypeText = workTypeRow.querySelector('.data-cell')?.textContent.toLowerCase() || '';
      details.isWritingFromScratch = workTypeText.includes('writing from scratch');
      details.isRevision = workTypeText.includes('revision');
      details.isEditing = workTypeText.includes('editing') || workTypeText.includes('proofreading');  // Added proofreading check
      details.isParaphrasing = workTypeText.includes('paraphrasing');
      details.isRewriting = workTypeText.includes('rewriting');
      details.isMixedOrder = workTypeText.split(',').length > 1;
    }

    // Extract software requirements
    const softwareRow = findRowByClasses('Software', '.combined-info-table-row');
    if (softwareRow) {
      details.softwareSection = softwareRow.querySelector('.data-cell')?.textContent.trim() || '';
      details.requiresSoftware = details.softwareSection.toLowerCase() !== 'none' && details.softwareSection !== '';
    }

    // Extract status
    const statusRow = findRowByClasses('Status', '.combined-info-table-row');
    if (statusRow) {
      details.status = statusRow.querySelector('.data-cell')?.textContent.trim() || '';
    }

    // Check if it's a test topic
    const testKeywords = ['test', 'test domain', 'TEST', 'testing', 'test order', 'test assignment'];
    details.isTestTopic = testKeywords.some(keyword => 
      details.topic.toLowerCase().includes(keyword.toLowerCase())
    );

    // Extract type of paper
    const paperTypeRow = findRowByClasses('Type of paper', '.combined-info-table-row');
    if (paperTypeRow) {
      // Check for anchor tag first, fallback to direct text content
      const dataCell = paperTypeRow.querySelector('.data-cell');
      const anchor = dataCell?.querySelector('a');
      details.typeOfPaper = (anchor?.textContent || dataCell?.textContent || '').trim();
    }

    // Extract sources count
    const sourcesRow = document.querySelector('.combined-info-table-row.unit-count-row');
    if (sourcesRow) {
      details.sourceCount = parseInt(sourcesRow.querySelector('.data-cell')?.textContent) || 0;
    }

    // Extract additional features
    details.hasProgressiveDelivery = document.querySelector('.progressive-delivery-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.hasAbstractPage = document.querySelector('.abstract-page-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';
    details.hasSoftCopies = document.querySelector('.soft-copies-row .data-cell')?.textContent.trim().toLowerCase() === 'yes';

    // Extract subject with correct selector
    const subjectRow = findRowByClasses('Subject', '.combined-info-table-row.paper-format-row.combined-info-table-row--wide');
    if (subjectRow) {
      const dataCell = subjectRow.querySelector('.data-cell');
      details.subject = dataCell?.querySelector('div')?.textContent.trim() || dataCell?.textContent.trim() || '';
    }

    // Extract pages and words with correct selector
    const pagesWordsRow = findRowByClasses('Pages / Words', '.combined-info-table-row.pages-count-row.combined-info-table-row--wide');
    if (pagesWordsRow) {
      const dataCell = pagesWordsRow.querySelector('.data-cell div')?.textContent.trim() || '';
      
      // Handle "X pages / -" format
      const pagesMatch = dataCell.match(/(\d+)\s*pages?\s*\/\s*-/i);
      if (pagesMatch) {
        details.pageCount = parseInt(pagesMatch[1]);
        details.wordCount = details.pageCount * 275; // Convert pages to words
      }
      
      // Handle "- / X words" format
      const wordsMatch = dataCell.match(/-\s*\/\s*(\d+)\s*words/i);
      if (wordsMatch) {
        details.wordCount = parseInt(wordsMatch[1]);
        details.pageCount = Math.ceil(details.wordCount / 275); // Convert words to pages
      }
    }

    // Extract slides, problems, and questions using the correct selectors
    const slidesRow = findRowByClasses('Slides', '.combined-info-table-row.unit-count-row.combined-info-table-row--wide');
    if (slidesRow) {
      details.slideCount = parseInt(slidesRow.querySelector('.data-cell')?.textContent) || 0;
    }

    const problemsRow = findRowByClasses('Problems', '.combined-info-table-row.unit-count-row.combined-info-table-row--wide');
    if (problemsRow) {
      details.problemCount = parseInt(problemsRow.querySelector('.data-cell')?.textContent) || 0;
    }

    const questionsRow = findRowByClasses('Questions', '.combined-info-table-row.unit-count-row.combined-info-table-row--wide');
    if (questionsRow) {
      details.questionCount = parseInt(questionsRow.querySelector('.data-cell')?.textContent) || 0;
    }

    // Clear any values that might have been set from the table cells
    if (!slidesRow) details.slideCount = 0;
    if (!problemsRow) details.problemCount = 0;
    if (!questionsRow) details.questionCount = 0;

    // Evaluate criteria
    let meetsCriteria = true;
    const reasons = [];

    // Word and page count checks
    if (settings.maxPages > 0 && details.pageCount > settings.maxPages) {
      meetsCriteria = false;
      reasons.push(`Page count (${details.pageCount}) exceeds maximum allowed (${settings.maxPages})`);
    }

    // Update word count check to handle both direct word count and page-based calculation
    if (settings.maxWords > 0 && details.wordCount > settings.maxWords) {
      meetsCriteria = false;
      reasons.push(`Word count (${details.wordCount}) exceeds maximum allowed (${settings.maxWords})`);
    }

    // Deadline check
    if (settings.minDeadline && details.deadline < settings.minDeadline) {
      meetsCriteria = false;
      reasons.push(`Deadline (${details.deadline}h) is below minimum (${settings.minDeadline}h)`);
    }

    // Price check
    if (settings.minPrice && details.price < settings.minPrice) {
      meetsCriteria = false;
      reasons.push(`Price ($${details.price}) is below minimum ($${settings.minPrice})`);
    }

    // Files check
    if (settings.maxFiles > 0 && details.fileCount > settings.maxFiles) {
      meetsCriteria = false;
      reasons.push(`Too many attached files: ${details.fileCount} (max: ${settings.maxFiles})`);
    }

    // Sources check
    if (settings.maxSources > 0 && details.sourceCount > settings.maxSources) {
      meetsCriteria = false;
      reasons.push(`Sources count (${details.sourceCount}) exceeds maximum allowed (${settings.maxSources})`);
    }

    // Slides check - check if slides exist when maxSlides is 0
    if (settings.maxSlides === 0 && details.slideCount > 0) {
      meetsCriteria = false;
      reasons.push('Orders with slides are not allowed (max slides set to 0)');
    } else if (settings.maxSlides > 0 && details.slideCount > settings.maxSlides) {
      meetsCriteria = false;
      reasons.push(`Slides count (${details.slideCount}) exceeds maximum allowed (${settings.maxSlides})`);
    }

    // Problems check - check if problems exist when maxProblems is 0
    if (settings.maxProblems === 0 && details.problemCount > 0) {
      meetsCriteria = false;
      reasons.push('Orders with problems are not allowed (max problems set to 0)');
    } else if (settings.maxProblems > 0 && details.problemCount > settings.maxProblems) {
      meetsCriteria = false;
      reasons.push(`Problems count (${details.problemCount}) exceeds maximum allowed (${settings.maxProblems})`);
    }

    // Questions check - check if questions exist when maxQuestions is 0
    if (settings.maxQuestions === 0 && details.questionCount > 0) {
      meetsCriteria = false;
      reasons.push('Orders with questions are not allowed (max questions set to 0)');
    } else if (settings.maxQuestions > 0 && details.questionCount > settings.maxQuestions) {
      meetsCriteria = false;
      reasons.push(`Questions count (${details.questionCount}) exceeds maximum allowed (${settings.maxQuestions})`);
    }

    // Work type and status checks - Updated revision status check
    const booleanChecks = [
      { 
        setting: settings?.excludeRevisionStatus, 
        value: details.status.toLowerCase().includes('revision'), // Changed to includes() for better matching
        message: 'Orders with Revision status' 
      },
      { setting: settings?.excludeEditing, value: details.isEditing, message: 'Editing orders' },
      { setting: settings?.excludeParaphrasing, value: details.isParaphrasing, message: 'Paraphrasing orders' },
      { setting: settings?.excludeRewriting, value: details.isRewriting, message: 'Rewriting orders' },
      { setting: settings?.noProgressiveDelivery, value: details.hasProgressiveDelivery, message: 'Progressive Delivery' },
      { setting: settings?.noAbstractPage, value: details.hasAbstractPage, message: 'Abstract Page' },
      { setting: settings?.noSoftCopies, value: details.hasSoftCopies, message: 'Soft Copies' },
      { setting: settings?.requireNoSoftware, value: details.requiresSoftware, message: 'Software Required' },
      { setting: settings?.excludeTestTopics, value: details.isTestTopic, message: 'Test Topic' }
    ];

    booleanChecks.forEach(check => {
      if (check.setting && check.value) {
        meetsCriteria = false;
        reasons.push(`${check.message} not allowed`);
      }
    });

    // Handle editing/paraphrasing/rewriting exclusion
    if (settings?.excludeEditing && (details.isEditing || details.isParaphrasing || details.isRewriting)) {
      meetsCriteria = false;
      const types = [];
      if (details.isEditing) types.push('Editing');
      if (details.isParaphrasing) types.push('Paraphrasing');
      if (details.isRewriting) types.push('Rewriting');
      reasons.push(`Order type not allowed: ${types.join(', ')}`);
    }

    // Check subject restrictions - make case insensitive
    if (settings?.excludedSubjects?.length > 0 && 
        settings.excludedSubjects.some(s => s.toLowerCase() === (details.subject || '').toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Subject "${details.subject}" is excluded`);
    }

    // Check paper type restrictions
    if (settings?.excludedTypesOfPaper?.length > 0 && 
        settings.excludedTypesOfPaper.some(t => t.toLowerCase() === details.typeOfPaper.toLowerCase())) {
      meetsCriteria = false;
      reasons.push(`Paper type "${details.typeOfPaper}" is excluded`);
    }

    // Writing from scratch requirement
    if (settings?.requireWritingFromScratch && !details.isWritingFromScratch) {
      meetsCriteria = false;
      reasons.push('Must be writing from scratch');
    }

    console.log('Order evaluation complete:', { meetsCriteria, reasons, details });
    return { meetsCriteria, reasons, details };

  } catch (error) {
    console.error('Error in extractOrderDetails:', error);
    return { meetsCriteria: false, reasons: [error.message], details: {} };
  }
}

// Handle the evaluation of the order details
async function evaluateOrder() {
  try {
    console.log('Evaluating order');
    
    // Get user settings first
    const data = await new Promise(resolve => 
      chrome.storage.local.get(['settings'], resolve)
    );
    const settings = data.settings || {};
    
    // Extract order details with settings
    const orderDetails = await extractOrderDetails(settings);
    const orderId = extractOrderIdFromUrl(window.location.href);
    const url = window.location.href;
    
    const details = orderDetails.details || {};
    const meetsCriteria = orderDetails.meetsCriteria;
    const reasons = orderDetails.reasons;
    
    if (meetsCriteria) {
      console.log('Order meets criteria, applying for order');
      window.writedomNotifications?.showOrderMatchNotification(details);
      applyForOrder();
    } else {
      console.log('Order does not meet criteria:', reasons);
      window.writedomNotifications?.showOrderMismatchNotification(reasons);
      
      // Send message to background to mark as processed and return to available orders
      chrome.runtime.sendMessage({
        action: 'order_processed',
        orderId: orderId,
        url: url,
        details: {
          ...details,
          skipped: true,
          reasons: reasons
        },
        notifyComplete: true
      }, () => {
        console.log('Navigating back to available orders after skipping:', reasons);
        window.location.href = 'https://writedom.com/dashboard/available-orders';
      });
    }
  } catch (error) {
    console.error('Error evaluating order:', error);
    // Still return to available orders if there's an error
    returnToAvailableOrders();
  }
}

// Add this helper function to extract order ID from URL
function extractOrderIdFromUrl(url) {
  // Try different URL patterns
  let match = url.match(/\/dashboard\/order\/(\d+)/);
  if (!match) match = url.match(/\/dashboard\/orders\/(\d+)/);
  if (!match) match = url.match(/\/order\/(\d+)/);
  if (!match) match = url.match(/(\d+)$/);
  return match ? match[1] : null;
}

// Add this listener to prevent page refreshes during order processing
window.addEventListener('beforeunload', function(e) {
  if (window.orderBeingProcessed) {
    // Cancel the event
    e.preventDefault();
    // Chrome requires returnValue to be set
    e.returnValue = 'Order is being processed. Are you sure you want to leave?';
  }
});

// Add function to increment bid counter when an order is successfully applied for
async function incrementBidCounter() {
  try {
    const data = await new Promise(resolve => 
      chrome.storage.local.get(['bidCount', 'orderCount'], resolve)
    );
    
    const bidCount = (data.bidCount || 0) + 1;
    const orderCount = (data.orderCount || 0) + 1;
    
    await new Promise(resolve => 
      chrome.storage.local.set({ bidCount, orderCount }, resolve)
    );
    
    console.log(`Updated statistics: orders checked=${orderCount}, bids placed=${bidCount}`);
  } catch (error) {
    console.error('Error incrementing bid counter:', error);
  }
}

// Function to clear monitoring intervals
function clearMonitoringIntervals() {
  if (monitoringInterval) {
    clearInterval(monitoringInterval);
    monitoringInterval = null;
  }
  if (refreshInterval) {
    clearInterval(refreshInterval);
    refreshInterval = null;
  }
}

// Function to start monitoring - faster check interval
function startMonitoring() {
  clearMonitoringIntervals(); // Clear any existing intervals

  // Check for new orders every 0.5 seconds
  monitoringInterval = setInterval(checkForNewOrders, 500);

  // Refresh the page every 7 seconds if no suitable order found
  refreshInterval = setInterval(() => {
    if (!orderEvaluated) {
      console.log('No suitable order found, refreshing page...');
      window.location.reload();
    }
  }, 7000);
}

// Update processOrder function to better handle order processing
async function processOrder() {
  console.log('Starting order processing');
  
  // Extract the order ID from the URL
  const url = window.location.href;
  const orderId = extractOrderIdFromUrl(url);
  
  if (!orderId) {
    console.error('Could not extract order ID from URL');
    // Close the tab if we can't process it
    returnToAvailableOrders();
    return;
  }
  
  console.log(`Processing order ${orderId}`);
  
  // Check if the bot is running
  const isBotRunning = await checkIfBotIsRunning();
  if (!isBotRunning) {
    console.log('Bot is not running, closing tab');
    returnToAvailableOrders();
    return;
  }
  
  // Check if order already processed
  const isProcessed = await checkIfOrderProcessed(orderId, url);
  if (isProcessed) {
    console.log(`Order ${orderId} already processed, closing tab immediately`);
    returnToAvailableOrders();
    return;
  }
  
  // Notify background script that we've started processing
  chrome.runtime.sendMessage({ action: 'processing_started' });
  
  // Wait for order info to load
  await checkForNewOrders();
}

// Function to wait for order info to appear
async function checkForNewOrders() {
  console.log('Checking for order info container');
  
  // Wait for the order info container to appear
  let retryCount = 0;
  const maxRetries = 15; // Increased from 10 to 15
  
  while (retryCount < maxRetries) {
    // For both old and new page structures - using more robust selectors
    const orderContainer = 
      document.querySelector('.order-info-container') || 
      document.querySelector('.order-details') ||
      document.querySelector('.card-body') ||
      document.querySelector('.card') ||
      document.querySelector('.status.main-info-block') || // Added based on user's HTML
      document.querySelector('.main-info-block') ||
      document.querySelector('.order-info-table__wrapper') ||
      document.querySelector('.combined-info-table-row') ||
      document.querySelector('.order-info-table');
    
    if (orderContainer) {
      console.log('Order container found, evaluating order');
      console.log('Container class:', orderContainer.className);
      console.log('Container HTML:', orderContainer.outerHTML.substring(0, 200) + '...');
      
      // Stop refresh interval before evaluating
      clearMonitoringIntervals();
      
      await evaluateOrder();
      return;
    }
    
    // Log the current page structure to help diagnose issues
    if (retryCount % 3 === 0) { // Log every 3rd retry to avoid console spam
      console.log(`Order container not found, retrying (${retryCount + 1}/${maxRetries})`);
    } else {
      console.log(`Order container not found, retrying (${retryCount + 1}/${maxRetries})`);
    }
    
    retryCount++;
    
    // Wait before trying again - increased from 1000ms to 1500ms
    await new Promise(resolve => setTimeout(resolve, 1500));
  }
  
  console.log('Order container not found after maximum retries, closing tab');
  returnToAvailableOrders();
}

// Function to apply for an order
function applyForOrder() {
  console.log('Attempting to apply for order');
  
  // Use the more robust button detection from tryApplyOrder
  tryApplyOrder().then(result => {
    if (result.success) {
      console.log('Successfully applied for order:', result.message);
      
      // Increment the bid counter
      incrementBidCounter();
      
      // Extract the order ID and URL
      const orderId = extractOrderIdFromUrl(window.location.href);
      const url = window.location.href;
      
      // Send message to background to mark as processed
      chrome.runtime.sendMessage({
        action: 'order_processed',
        orderId: orderId,
        url: url,
        details: {
          applied: true,
          success: true
        },
        notifyComplete: true
      }, () => {
        // Return to available orders page after successful apply
        console.log('Navigating back to available orders after successful apply');
        window.location.href = 'https://writedom.com/dashboard/available-orders';
      });
    } else {
      console.log('Error applying for order:', result.message);
      
      // Still mark as processed to avoid reprocessing
      const orderId = extractOrderIdFromUrl(window.location.href);
      const url = window.location.href;
      
      chrome.runtime.sendMessage({
        action: 'order_processed',
        orderId: orderId,
        url: url,
        details: {
          applied: true,
          success: false,
          error: result.message
        },
        notifyComplete: true
      }, () => {
        // Return to available orders even if there was an error
        console.log('Navigating back to available orders after apply error');
        window.location.href = 'https://writedom.com/dashboard/available-orders';
      });
    }
  });
}

// Function to extract order ID from URL
function extractOrderIdFromUrl(url) {
  if (!url) {
    console.log('URL is null or undefined');
    return null;
  }
  
  console.log('Extracting order ID from URL:', url);
  
  // Handle various URL formats
  let match = url.match(/\/dashboard\/orders\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /dashboard/orders/:', match[1]);
    return match[1];
  }
  
  match = url.match(/\/dashboard\/order\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /dashboard/order/:', match[1]);
    return match[1];
  }
  
  match = url.match(/\/order\/(\d+)/);
  if (match) {
    console.log('Found order ID using pattern /order/:', match[1]);
    return match[1];
  }
  
  // Try to find any numeric ID at the end of the URL
  match = url.match(/(\d+)(?:\?|$)/);
  if (match) {
    console.log('Found order ID at the end of URL:', match[1]);
    return match[1];
  }
  
  // Try to find ID in query parameters
  const urlObj = new URL(url);
  const idParam = urlObj.searchParams.get('id') || urlObj.searchParams.get('orderId');
  if (idParam) {
    console.log('Found order ID in query parameters:', idParam);
    return idParam;
  }
  
  console.log('Could not extract order ID from URL. URL format not recognized.');
  return null;
}

// Function to return to available orders page
function returnToAvailableOrders() {
  console.log('Processing complete, navigating back to available orders page');
  
  // Notify background that processing is complete
  chrome.runtime.sendMessage({ action: 'processing_complete' });
  
  // Get the order ID and URL
  const orderId = extractOrderIdFromUrl(window.location.href);
  const url = window.location.href;
  
  // Tell background.js this order is processed
  chrome.runtime.sendMessage({
    action: 'order_processed',
    orderId: orderId,
    url: url,
    notifyComplete: true
  }, () => {
    // Navigate back to available orders page
    console.log('Navigating back to available orders page');
    window.location.href = 'https://writedom.com/dashboard/available-orders';
  });
}

// Add a function to check if the bot is running
function checkIfBotIsRunning() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['isBidding'], function(data) {
      resolve(!!data.isBidding);
    });
  });
}

// Check if an order has already been processed
function checkIfOrderProcessed(orderId, url) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({
      action: 'check_if_processed',
      orderId: orderId,
      url: url
    }, function(response) {
      resolve(response ? response.isProcessed : false);
    });
  });
}

// Update the markOrderAsProcessed function to navigate instead of closing tab
async function markOrderAsProcessed() {
  const orderId = window.location.href.match(/\/orders\/(\d+)/)?.[1];
  const currentUrl = window.location.href;
  
  if (!orderId) {
    console.error('Could not extract order ID for marking as processed');
    return;
  }

  try {
    console.log(`Marking order ${orderId} as processed`);
    
    // Extract order details one more time to ensure we send complete data
    const orderDetails = await extractOrderDetails();
    
    // Update order count
    const data = await new Promise(resolve => 
      chrome.storage.local.get(['orderCount'], resolve)
    );
    
    const orderCount = (data.orderCount || 0) + 1;
    await new Promise(resolve => 
      chrome.storage.local.set({ orderCount }, resolve)
    );
    
    // Send message with order details for storage
    await chrome.runtime.sendMessage({
      action: 'order_processed',
      orderId: orderId,
      url: currentUrl,
      details: orderDetails.details || {}, // Include order details
      notifyComplete: true // Add flag to notify background.js processing is complete
    });

    clearMonitoringIntervals();
    orderEvaluated = true;
    
    console.log('Order processed, navigating back to main page...');
    
    // Navigate back to available orders
    window.location.href = 'https://writedom.com/dashboard/available-orders';
  } catch (error) {
    console.error('Error marking order as processed:', error);
    
    // In case of error, still try to navigate back
    try {
      console.log('Navigating back to available orders after error');
      window.location.href = 'https://writedom.com/dashboard/available-orders';
    } catch (e) {
      console.error('Error navigating back:', e);
    }
  }
}

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message in order.js:', message);
  
  if (message.action === 'extract_order_details') {
    (async () => {
      try {
        const details = await extractOrderDetails(message.settings);
        sendResponse({
          status: 'success',
          meetsCriteria: details.meetsCriteria,
          reasons: details.reasons,
          details: details.details
        });
      } catch (error) {
        sendResponse({
          status: 'error',
          message: error.message
        });
      }
    })();
    return true;
  }
  
  // Allow forced processing
  if (message.action === 'force_process_order') {
    console.log('Received force process order message', message);
    setTimeout(() => processOrder(), 500); // Process with a short delay
    if (sendResponse) sendResponse({ status: 'processing_started' });
    return true;
  }
  
  // Make sure we still handle apply_for_order
  if (message.action === 'apply_for_order') {
    console.log('Received apply for order message');
    applyForOrder();
    if (sendResponse) sendResponse({ status: 'applying' });
    return true;
  }
  
  // Make sure we still handle return_to_orders
  if (message.action === 'return_to_orders') {
    console.log('Received return to orders message');
    returnToAvailableOrders();
    if (sendResponse) sendResponse({ status: 'returning' });
    return true;
  }
  
  return true;
});

// Initialize order.js with an immediate check if we're on an order page
(function() {
  if (window.location.href.includes('/dashboard/orders/') || 
      window.location.href.includes('/dashboard/order/') ||
      window.location.href.includes('/order/')) {
    console.log('On order page, checking if should process automatically');
    checkIfBotIsRunning().then(isRunning => {
      if (isRunning) {
        console.log('Bot is running, processing order automatically');
        setTimeout(processOrder, 1000);
      } else {
        console.log('Bot is not running, not auto-processing');
      }
    });
  }
})();

// Listen for bot stop event
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'stop_bot') {
    console.log('Received stop bot message');
    // Clear monitoring intervals
    clearMonitoringIntervals();
    // Set evaluated flag to prevent further processing
    orderEvaluated = true;
    // Clear any in-progress flags
    window.orderBeingProcessed = false;
    if (sendResponse) sendResponse({ status: 'stopped' });
    return true;
  }
  return true;
});

